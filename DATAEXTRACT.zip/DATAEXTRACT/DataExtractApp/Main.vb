Imports DataExtract
Imports DataExtractClasses
Imports InternetTransfer
Imports System.IO
Imports System.Xml

Module Main
    Private ofrmDataExtract As frmDataExtract
    Private Declare Sub ExitProcess Lib "kernel32" (ByVal uExitCode As Long)

    Sub main()
        Dim dsData As DataSet
        Dim sCommand As String = Microsoft.VisualBasic.Command()
        Dim sStartTime As String


        sStartTime = Format(Now, "MM/dd/yyyy hh:mm:ss tt")
        'Changes for RADAR-13330.. Try catch block is added
        Try
            If sCommand <> "" Then
                Dim saCommand() As String = Split(sCommand, ",")
                Dim bOverideRunDate As Boolean = False
                'if we got more than one arg, the first is the filename, second is 
                'a flag telling us to override the next run date in the file
                'ie run it anyway, even if the next run date is not due or is missing
                If saCommand.GetUpperBound(0) > 0 Then
                    bOverideRunDate = CBool(saCommand(1))
                End If
                'validate that it is an appropriate filename
                If InStr(saCommand(0), ".xml") = 0 Then
                    'error
                Else
                    If File.Exists(saCommand(0)) Then                        
                        RunFile(saCommand(0), bOverideRunDate, dsData)
                    End If
                End If
            Else
                ofrmDataExtract = New frmDataExtract
                ofrmDataExtract.ShowDialog()
            End If

            fLogit(sStartTime)
        Catch ex As Exception
            fLogit(sStartTime)
            ExitProcess(5)
        End Try
    End Sub

   Private Sub fLogit(ByVal sStartTime As String)
      Dim sOutstr As String
      Dim oDataExtract As New clsDataExtract
      Dim oInternetTransfer As New clsFTP
      Dim oDataExtractClasses As New clsUtilityFunctions

      sOutstr = sStartTime & " - Start: "
      sOutstr &= "DataExtractApp.exe (" & System.Reflection.Assembly.GetExecutingAssembly().GetName().Version.ToString() & ") "
      sOutstr &= "DataExtract.dll (" & oDataExtract.fGiveVersion & ") "
      sOutstr &= "DataExtractClasses.dll (" & oDataExtractClasses.fGiveVersion & ") "
      sOutstr &= "InternetTransfer.dll (" & oInternetTransfer.fGiveVersion & ") " & vbCrLf

      sOutstr &= Format(Now, "MM/dd/yyyy hh:mm:ss tt") & " - End"

      FileOpen(1, Mid(Application.ExecutablePath(), 1, Len(Application.ExecutablePath()) - 3) & "log", OpenMode.Append)
      PrintLine(1, sOutstr)
      FileClose(1)
   End Sub


   Public Function RunFile(ByVal txtFileName As String, ByVal bOverideRunDate As Boolean, ByRef dsData As DataSet) As Boolean
      'Dim dsData As New DataSet
      Dim oDataExtract As New clsDataExtract
      Dim xmlElement As Xml.XmlElement
      Dim xmlDoc As New Xml.XmlDocument
      Dim dtNextRunDate As Date
      Dim bRun As Boolean = bOverideRunDate

      RunFile = True
      'bRun = False
      If Dir(txtFileName) = "" Then
         MsgBox(txtFileName & " not found.", MsgBoxStyle.OkOnly, "File Not Found")
         Exit Function
      End If

      xmlDoc.Load(txtFileName)

      'check to see if it is later than the next run date, only run if it is.
      xmlElement = xmlDoc.SelectSingleNode("Root//Schedule")
      If TypeName(xmlElement) <> "Nothing" Then
         'see if there is a NextRunDate attribute
         Dim attr As XmlAttribute = CType(xmlElement.Attributes.GetNamedItem("NextRunDate"), XmlAttribute)
         If TypeName(attr) <> "Nothing" Then
            dtNextRunDate = CDate(xmlElement.GetAttribute("NextRunDate"))
            If Now() > dtNextRunDate Then
               bRun = True
            Else
               'if we're not scheduled to run, don't, unless override flag is set
               bRun = bOverideRunDate
            End If
         Else
            'if there is no rundate, we definitely need to just run the file
            bRun = True
         End If
      End If
        'Changes for RADAR-13330. Try catch block is added
        Try
            If bRun Then
                'Cursor.Current = System.Windows.Forms.Cursors.WaitCursor
                'StatusBar1.Text = "Processing File " & txtFileName
                dsData = oDataExtract.ProcessFile(txtFileName)
                If TypeName(dsData) = "Nothing" Then
                    RunFile = False
                Else
                    If dsData.Tables.Count = 0 Then 'Or dsData.Tables(0).Rows.Count = 0 Then--PID 6/20/05:  Commented out this portion per Lee Rutty
                        RunFile = False
                    End If
                End If
                Cursor.Current = System.Windows.Forms.Cursors.Default
            End If
        Catch ex As Exception
            RunFile = False
            Cursor.Current = System.Windows.Forms.Cursors.Default
            Throw ex
        End Try
    End Function

End Module
