Option Strict Off
Option Explicit On 
Imports System.Data.OleDb
Imports System.Xml
Imports DataExtract
Imports DataExtractClasses
Imports System.IO

Friend Class frmDataExtract
    Inherits System.Windows.Forms.Form
    Dim mdsData As New DataSet()
#Region "Windows Form Designer generated code "
    Dim bStopLoop As Boolean
    Public Sub New()
        MyBase.New()
        If m_vb6FormDefInstance Is Nothing Then
            If m_InitializingDefInstance Then
                m_vb6FormDefInstance = Me
            Else
                Try
                    'For the start-up form, the first instance created is the default instance.
                    If System.Reflection.Assembly.GetExecutingAssembly.EntryPoint.DeclaringType Is Me.GetType Then
                        m_vb6FormDefInstance = Me
                    End If
                Catch
                End Try
            End If
        End If
        'This call is required by the Windows Form Designer.
        InitializeComponent()

        ''set up so a command line arg will allow us to just process
        ''the one file and then quit
        'Dim sCommand As String = Microsoft.VisualBasic.Command()
        'If sCommand <> "" Then
        '    Dim saCommand() = Split(sCommand, ",")
        '    Dim bOverideRunDate As Boolean = False
        '    'if we got more than one arg, the first is the filename, second is 
        '    'a flag telling us to override the next run date in the file
        '    'ie run it anyway, even if the next run date is not due or is missing
        '    If saCommand.GetUpperBound(0) > 0 Then
        '        bOverideRunDate = CBool(saCommand(1))
        '    End If
        '    'validate that it is an appropriate filename
        '    If InStr(saCommand(0), ".xml") = 0 Then
        '        'error
        '    Else
        '        If File.Exists(saCommand(0)) Then
        '            RunFile(saCommand(0), bOverideRunDate)
        '        End If
        '    End If
        '    End
        'End If

    End Sub
    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
        If Disposing Then
            If Not components Is Nothing Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(Disposing)
    End Sub
    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer
    Public ToolTip1 As System.Windows.Forms.ToolTip
    Public WithEvents cmdQuit As System.Windows.Forms.Button
   Public WithEvents cmdProcess As System.Windows.Forms.Button
   Public WithEvents txtFileName As System.Windows.Forms.TextBox
   Public WithEvents Label1 As System.Windows.Forms.Label
   'NOTE: The following procedure is required by the Windows Form Designer
   'It can be modified using the Windows Form Designer.
   'Do not modify it using the code editor.
   Friend WithEvents DataGrid2 As System.Windows.Forms.DataGrid
   Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
   Friend WithEvents cmdBrowse As System.Windows.Forms.Button
   Friend WithEvents StatusBar1 As System.Windows.Forms.StatusBar
   <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.cmdQuit = New System.Windows.Forms.Button
        Me.cmdProcess = New System.Windows.Forms.Button
        Me.txtFileName = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.DataGrid2 = New System.Windows.Forms.DataGrid
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog
        Me.cmdBrowse = New System.Windows.Forms.Button
        Me.StatusBar1 = New System.Windows.Forms.StatusBar
        CType(Me.DataGrid2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'cmdQuit
        '
        Me.cmdQuit.BackColor = System.Drawing.SystemColors.Control
        Me.cmdQuit.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdQuit.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.cmdQuit.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdQuit.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdQuit.Location = New System.Drawing.Point(560, 48)
        Me.cmdQuit.Name = "cmdQuit"
        Me.cmdQuit.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdQuit.Size = New System.Drawing.Size(137, 24)
        Me.cmdQuit.TabIndex = 4
        Me.cmdQuit.Text = "&Quit"
        Me.cmdQuit.UseVisualStyleBackColor = False
        '
        'cmdProcess
        '
        Me.cmdProcess.BackColor = System.Drawing.SystemColors.Control
        Me.cmdProcess.CausesValidation = False
        Me.cmdProcess.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdProcess.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdProcess.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdProcess.Location = New System.Drawing.Point(560, 15)
        Me.cmdProcess.Name = "cmdProcess"
        Me.cmdProcess.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdProcess.Size = New System.Drawing.Size(137, 24)
        Me.cmdProcess.TabIndex = 3
        Me.cmdProcess.Text = "&Process File"
        Me.cmdProcess.UseVisualStyleBackColor = False
        '
        'txtFileName
        '
        Me.txtFileName.AcceptsReturn = True
        Me.txtFileName.BackColor = System.Drawing.SystemColors.Window
        Me.txtFileName.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtFileName.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtFileName.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtFileName.Location = New System.Drawing.Point(72, 16)
        Me.txtFileName.MaxLength = 0
        Me.txtFileName.Name = "txtFileName"
        Me.txtFileName.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtFileName.Size = New System.Drawing.Size(368, 20)
        Me.txtFileName.TabIndex = 0
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.SystemColors.Control
        Me.Label1.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label1.Location = New System.Drawing.Point(16, 19)
        Me.Label1.Name = "Label1"
        Me.Label1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label1.Size = New System.Drawing.Size(56, 14)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "File Name:"
        '
        'DataGrid2
        '
        Me.DataGrid2.DataMember = ""
        Me.DataGrid2.HeaderForeColor = System.Drawing.SystemColors.ControlText
        Me.DataGrid2.Location = New System.Drawing.Point(17, 80)
        Me.DataGrid2.Name = "DataGrid2"
        Me.DataGrid2.Size = New System.Drawing.Size(680, 224)
        Me.DataGrid2.TabIndex = 5
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.InitialDirectory = "C:\DataExtracts\VB Projects\Data Extract"
        Me.OpenFileDialog1.Title = "Choose an Extract Definition File"
        '
        'cmdBrowse
        '
        Me.cmdBrowse.Location = New System.Drawing.Point(448, 15)
        Me.cmdBrowse.Name = "cmdBrowse"
        Me.cmdBrowse.Size = New System.Drawing.Size(75, 23)
        Me.cmdBrowse.TabIndex = 6
        Me.cmdBrowse.Text = "&Browse"
        '
        'StatusBar1
        '
        Me.StatusBar1.Location = New System.Drawing.Point(0, 311)
        Me.StatusBar1.Name = "StatusBar1"
        Me.StatusBar1.Size = New System.Drawing.Size(706, 22)
        Me.StatusBar1.TabIndex = 10
        '
        'frmDataExtract
        '
        Me.AcceptButton = Me.cmdProcess
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.CancelButton = Me.cmdQuit
        Me.ClientSize = New System.Drawing.Size(706, 333)
        Me.Controls.Add(Me.StatusBar1)
        Me.Controls.Add(Me.cmdBrowse)
        Me.Controls.Add(Me.DataGrid2)
        Me.Controls.Add(Me.cmdQuit)
        Me.Controls.Add(Me.cmdProcess)
        Me.Controls.Add(Me.txtFileName)
        Me.Controls.Add(Me.Label1)
        Me.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Location = New System.Drawing.Point(4, 23)
        Me.Name = "frmDataExtract"
        Me.Text = "Data Extract"
        CType(Me.DataGrid2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
#End Region
#Region "Upgrade Support "
   Private Shared m_vb6FormDefInstance As frmDataExtract
   Private Shared m_InitializingDefInstance As Boolean
   Public Shared Property DefInstance() As frmDataExtract
      Get
         If m_vb6FormDefInstance Is Nothing OrElse m_vb6FormDefInstance.IsDisposed Then
            m_InitializingDefInstance = True
            m_vb6FormDefInstance = New frmDataExtract()
            m_InitializingDefInstance = False
         End If
         DefInstance = m_vb6FormDefInstance
      End Get
      Set(ByVal Value As frmDataExtract)
         m_vb6FormDefInstance = Value
      End Set
   End Property
#End Region

   Private Sub cmdProcess_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdProcess.Click

      If txtFileName.Text = "" Or InStr(UCase(txtFileName.Text), ".XML") = 0 Then
         MessageBox.Show("Please choose a valid file", "Invalid File")
         Exit Sub
      End If

        'if the user is saying to run the file, override the run date entry
        Try
            Cursor = Cursors.WaitCursor
            If RunFile(txtFileName.Text, True, mdsData) Then
                If mdsData.Tables.Count > 0 Then
                    DataGrid2.SetDataBinding(mdsData, CStr(mdsData.Tables(0).TableName))
                End If
                StatusBar1.Text = ""
            Else
                StatusBar1.Text = "There were errors. Please consult the error log file for details."
            End If
            Cursor = Cursors.Default
        Catch ex As Exception
            StatusBar1.Text = "There were Exceptions. Please consult the error log file for details."
            Cursor = Cursors.Default
        End Try
    End Sub

   Private Sub cmdQuit_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdQuit.Click
      Me.Close()
   End Sub

   Private Sub cmdBrowse_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdBrowse.Click
      'OpenFileDialog1.InitialDirectory = "C:\DataExtracts\ExtractDefinitionFiles\"
      OpenFileDialog1.Filter = "xml files (*.xml)|*.xml|All files (*.*)|*.*"

      OpenFileDialog1.ShowDialog()
      If OpenFileDialog1.FileName <> "" Then
         txtFileName.Text = OpenFileDialog1.FileName
      End If
   End Sub

   Private Sub cmdCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
      bStopLoop = True
   End Sub

   Private Sub frmDataExtract_Shown(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Shown
      OpenFileDialog1.Filter = "xml files (*.xml)|*.xml|All files (*.*)|*.*"
      OpenFileDialog1.ShowDialog()
      If OpenFileDialog1.FileName <> "" Then
         txtFileName.Text = OpenFileDialog1.FileName
      End If
   End Sub

    Private Sub DataGrid2_Navigate(ByVal sender As System.Object, ByVal ne As System.Windows.Forms.NavigateEventArgs) Handles DataGrid2.Navigate

    End Sub
End Class