Option Strict On
Option Explicit On

Imports System.IO
Imports System

Public Class clsFTP
   Implements IDisposable

   Private m_sHost As String
   Private m_sUser As String
   Private m_sPassword As String
   Private m_RemoteDir As String
   Private m_sFilePath As String
   Private m_sFileName As String
   Private m_sErrorText As String
   Private m_sLogFile As String
   Private m_sFTPStartDir As String
   Private m_bDeleteOldFile As Boolean
   Private m_hOpen As Integer
   Private m_hConnection As Integer
    Public Shared strDBLog As String

   Dim ftp As Net.FtpWebRequest
    Dim ftpResponse As Net.FtpWebResponse
    'Changes Start for ftping the file to the new domain till the time the old domain is not sunset
    Private m_sNewFileName As String = ""
    'Changes for radar 13330 Start
    Dim iFtpTrial As Integer
    Private Declare Sub Sleep Lib "kernel32" (ByVal dwMilliseconds As Long)
    'Changes for radar 13330 End

    Public Function fGiveVersion() As String
        fGiveVersion = System.Reflection.Assembly.GetExecutingAssembly().GetName().Version.ToString()
    End Function

    'Changes Start for ftping the file to the new domain till the time the old domain is not sunset
    'added the last optional parameter 
    Public Function FTPSendFile(ByRef sHost As String, _
                               ByRef sUser As String, _
                               ByRef sPWD As String, _
                               ByRef sDir As String, _
                               ByRef sFile As String, _
                               Optional ByRef sLog As String = "", _
                               Optional ByRef sRemoteDir As String = "", _
                               Optional ByRef bDeleteOldFile As Boolean = False, _
                               Optional ByVal sFileNewName As String = "") As Boolean

        FTPSendFile = False
        strDBLog = ""
        Host = sHost
        User = sUser
        Password = sPWD
        FilePath = sDir
        FileName = sFile
        LogFile = sLog
        RemoteDir = sRemoteDir
        DeleteOldFile = bDeleteOldFile

        'Changes Start for ftping the file to the new domain till the time the old domain is not sunset
        NewFileName = sFileNewName        
        'Changes Start for ftping the file to the new domain till the time the old domain is not sunset

        Call WriteLog("FTP start.")
        'Changes for Radar 13330 Start
        'If MakeConnection() Then
        '    If TransferFile() Then

        '        FTPSendFile = True

        '    End If

        '    CloseConnection()
        '    Call WriteLog("FTP finish.")
        'End If

        Try
            For iFtpTrial = 1 To 3
                If MakeConnection() Then
                    If TransferFile() Then
                        FTPSendFile = True
                        CloseConnection()
                        Call WriteLog("FTP finish.")
                        Exit For
                    Else
                        CloseConnection()
                        Sleep(30000)
                    End If
                Else
                    Sleep(30000)
                End If
            Next
        Catch ex As Exception
            Call WriteLog("Error: FTP not successful.", 3)
            FTPSendFile = False
            Throw ex
        End Try

        'Changes for Radar 13330 End

    End Function

    Public Function MakeConnection() As Boolean
        Dim sPath As New Text.StringBuilder(String.Empty)

        Call WriteLog("Opening connection at " & m_sHost & " to folder " & m_RemoteDir)
        MakeConnection = True

        If (m_sHost = "" Or m_sUser = "" Or m_sPassword = "") Then
            Call WriteLog("*** Insuficient info to connect. Missing Host, User or Password", 2)
            MakeConnection = False
            Exit Function
        End If

        If m_hConnection = 0 Then
            Try
                'Changes Start for ftping the file to the new domain till the time the old domain is not sunset
                'sPath.Append("ftp://").Append(m_sHost).Append("/").Append(m_RemoteDir).Append("/").Append(m_sFileName)
                If m_sNewFileName = "" Then
                    sPath.Append("ftp://").Append(m_sHost).Append("/").Append(m_RemoteDir).Append("/").Append(m_sFileName)
                Else
                    sPath.Append("ftp://").Append(m_sHost).Append("/").Append(m_RemoteDir).Append("/").Append(m_sNewFileName)
                End If
                'Changes End for ftping the file to the new domain till the time the old domain is not sunset
                ftp = CType(Net.FtpWebRequest.Create(sPath.ToString), System.Net.FtpWebRequest)
                ftp.Credentials = New Net.NetworkCredential(m_sUser, m_sPassword)
                ftp.KeepAlive = False
                ftp.UsePassive = True

                m_hOpen = 1
                Call WriteLog("Connection opened successfully")
            Catch ex As Exception
                Call WriteLog("**** Unable to open FTP connection: " & ex.Message, 3)

                MakeConnection = False
                'Changes for Radar 13330 Start
                If iFtpTrial = 3 Then
                    Throw ex
                End If
                'Changes for Radar 13330 End
            End Try
        End If
    End Function

    Public Function TransferFile() As Boolean
        Dim bRet As Boolean
        'Change for Radar 13330
        Dim sRequest As IO.Stream

        Try
            If m_bDeleteOldFile Then
                bRet = FtpDeleteFile(ftp)
            End If

            Call WriteLog("Transfer start. File: " & m_sFilePath & m_sFileName)
            Dim stream As IO.StreamReader = New System.IO.StreamReader(m_sFilePath & m_sFileName)

            Dim bStream() As Byte = Text.Encoding.UTF8.GetBytes(stream.ReadToEnd())
            stream.Close()
            ftp.Method = Net.WebRequestMethods.Ftp.UploadFile
            ftp.ContentLength = bStream.Length
            'Changes for Radar 13330 Start
            'Dim sRequest As IO.Stream = ftp.GetRequestStream
            sRequest = ftp.GetRequestStream
            'Changes for Radar 13330 End
            sRequest.Write(bStream, 0, bStream.Length)
            sRequest.Close()
            ftpResponse = CType(ftp.GetResponse(), Net.FtpWebResponse)

            Call WriteLog("Transfer finish. Bytes: " & VB6.Format(ftp.ContentLength, "#,##0"))
            TransferFile = True

        Catch ex As Exception
            TransferFile = False
            Call WriteLog("**** File " & m_sFilePath & m_sFileName & " not transferred", 3)
            'Changes for Radar 13330 Start
            'Call WriteLog("**** Error message: " & ftpResponse.StatusDescription)
            Call WriteLog("**** Error message: " & ex.Message, 3)
            sRequest = Nothing            
            If iFtpTrial = 3 Then                
                Throw ex
            End If
            'Changes for Radar 13330 End
        End Try

    End Function

    Public Sub CloseConnection()
        Call WriteLog("Closing connection at " & m_sHost)
        'Changes for Radar 13330 Start
        'ftpResponse.Close()
        If Not ftpResponse Is Nothing Then
            ftpResponse.Close()
        End If
        ftp = Nothing
        'Changes for Radar 13330 Start
        Call WriteLog("Connection closed successfully")
    End Sub

    Public Function FtpDeleteFile(ByRef ftp As Net.FtpWebRequest) As Boolean
        Try
            ftp.Method = System.Net.WebRequestMethods.Ftp.DeleteFile
        Catch ex As Exception
            'just in case
        End Try
    End Function

    Private Sub WriteLog(ByVal sText As String, Optional ByVal SuccessFlag As Integer = 1)
        Dim szTemp As String
        Dim strPath As String

        strDBLog &= SuccessFlag & "#~" & DateTime.Now & "-" & sText & "||"

        If m_sLogFile = String.Empty Then
            Exit Sub
        End If

        strPath = Path.Combine(My.Application.Info.DirectoryPath, "\Log")
        szTemp = Dir(strPath, FileAttribute.Directory)
        If szTemp = "" Then
            MkDir(strPath)
        End If

        sText = VB6.Format(Now, "MM/dd/yyyy hh:mm:ss AMPM") & " - " & sText & vbCrLf
        IO.File.AppendAllText(m_sLogFile, sText)



    End Sub

    Public Property Host() As String
        Get
            Host = m_sHost
        End Get
        Set(ByVal Value As String)
            m_sHost = Value
        End Set
    End Property

    Public Property User() As String
        Get
            User = m_sUser
        End Get
        Set(ByVal Value As String)
            m_sUser = Value
        End Set
    End Property

    Public Property Password() As String
        Get
            Password = m_sPassword
        End Get
        Set(ByVal Value As String)
            m_sPassword = Value
        End Set
    End Property

    Public Property RemoteDir() As String
        Get
            RemoteDir = m_RemoteDir
        End Get
        Set(ByVal Value As String)
            m_RemoteDir = Value
        End Set
    End Property

    Public Property FilePath() As String
        Get
            FilePath = m_sFilePath
        End Get
        Set(ByVal Value As String)
            m_sFilePath = Value
            If Right(m_sFilePath, 1) <> "\" Then m_sFilePath = m_sFilePath & "\"
        End Set
    End Property

    Public Property FileName() As String
        Get
            FileName = m_sFileName
        End Get
        Set(ByVal Value As String)
            m_sFileName = Value
        End Set
    End Property
    'Changes Start for ftping the file to the new domain till the time the old domain is not sunset
    Public Property NewFileName() As String
        Get
            NewFileName = m_sNewFileName
        End Get
        Set(ByVal Value As String)
            m_sNewFileName = Value
        End Set
    End Property
    'Changes End for ftping the file to the new domain till the time the old domain is not sunset

    Public Property LogFile() As String
        Get
            LogFile = m_sLogFile
        End Get
        Set(ByVal Value As String)
            m_sLogFile = Value
        End Set
    End Property

    Public Property FTPStartDir() As String
        Get
            FTPStartDir = m_sFTPStartDir
        End Get
        Set(ByVal Value As String)
            m_sFTPStartDir = Value
        End Set
    End Property

    Public Property DeleteOldFile() As Boolean
        Get
            DeleteOldFile = m_bDeleteOldFile
        End Get
        Set(ByVal Value As Boolean)
            m_bDeleteOldFile = Value
        End Set
    End Property
    Public ReadOnly Property ErrorText() As String
        Get
            ErrorText = m_sErrorText
        End Get
    End Property

    Private Sub Class_Initialize_Renamed()
        m_hOpen = 0
        m_hConnection = 0
    End Sub
    Public Sub New()
        MyBase.New()
        Class_Initialize_Renamed()
    End Sub

    Private Sub Class_Terminate_Renamed()

    End Sub
    Protected Overrides Sub Finalize()
        Class_Terminate_Renamed()
        MyBase.Finalize()
    End Sub

    Private disposedValue As Boolean = False        ' To detect redundant calls

    ' IDisposable
    Protected Overridable Sub Dispose(ByVal disposing As Boolean)

        If Not Me.disposedValue Then
            If disposing Then
                ' TODO: free managed resources when explicitly called
            End If

            ' TODO: free shared unmanaged resources
        End If
        Me.disposedValue = True
    End Sub

#Region " IDisposable Support "
    ' This code added by Visual Basic to correctly implement the disposable pattern.
    Public Sub Dispose() Implements IDisposable.Dispose
        Call Class_Terminate_Renamed()
        ' Do not change this code.  Put cleanup code in Dispose(ByVal disposing As Boolean) above.
        Dispose(True)
        GC.SuppressFinalize(Me)
    End Sub
#End Region

End Class
