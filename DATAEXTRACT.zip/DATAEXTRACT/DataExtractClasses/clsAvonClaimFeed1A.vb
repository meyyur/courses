Imports System.Data.OleDb

Public Class clsAvonClaimFeed
    Enum Status
        Pend = 550496000
        Review = 550496001
        Approved = 550496002
        Cancelled = 550496003
        Complete = 550496004
        Closed = 550496005
        Denied = 550496006
    End Enum

    Public Function DeriveStatus(ByRef dsData As DataSet, ByVal sEndDate As String) As Boolean
        'This function is the main driver for the avon claim data feed.
        'The data set being passed in has all claim status data for the period being
        'extracted, and the 21-day clock flag. It will loop thru the data, 
        'deciding what the corresponding output status should be. A new dataset 
        'is built, representing the data to be output. The table in the passed dataset
        'is dropped and replaced with it. The extract engine will then output 
        'that dataset to file as instructed.

        '***NOTE that several scenarios involve discovering future-dated claims. Because the 
        'extract could be run for a period in the past, we will use the End Date for the run for these
        'comparisons, rather than the system clock. ie if it is 06/17 and we are running a file
        'for 04/01, and a claim has a 1st date of absence of 04/15, it is in the future
        'in context of that file run, even though it is now in the past. Clear as mud, eh?

        Dim sAction, sReason As String
        Dim sStatus, sSubStatus As String
        Dim sEmpID As String
        Dim sProcessFlag As String = "I"
        Dim bSkipEntry As Boolean   'flag to say don't output the row for this case
        Dim tblOutput As DataTable = New DataTable("Output")
        Dim sEffDate, sBERTW As String
        Dim bOrphans As Boolean
        Dim sOrphanData As String
        'LAR 11/23/2004 
        Dim bBadRows As Boolean
        Dim sBadRowsData As String

      Dim dtEndDate As System.DateTime
      Dim bContinue As Boolean  'bm - 10/6/2003

        If IsDate(sEndDate) Then
            dtEndDate = CDate(sEndDate)
        Else
            dtEndDate = System.DateTime.Now
        End If

        'first thing, make sure the 2 procs on which this process depends ran today
        Dim dsDataTemp As DataSet = New DataSet()
        Dim dtProcLastRun As System.DateTime

      '21day clock proc
      RunSQL("select date_parameter from s_batch_process_parameter " & _
          "where batch_process_parameter_id = 435 and batch_process_id = 6 " & _
          "and batch_parameter_id = 2", "", dsDataTemp)
      If dsDataTemp.Tables(0).Rows.Count > 0 Then
         dtProcLastRun = CDate(dsDataTemp.Tables(0).Rows(0)("date_parameter"))
            If dtProcLastRun.Date.Date <> Date.Parse(sEndDate).Date Then
                'If dtProcLastRun.Date <> Now.Date Then
                'throw a fatal exception
                Throw New System.Exception("ERROR: the 21 day proc did not run today. Extract aborted.")
                Return False
                'End If
            End If
        Else
            'throw a fatal exception
            Throw New System.Exception("ERROR: the 21 day proc did not return valid data. Extract aborted.")
            Return False
        End If

        dsDataTemp.Clear()

        'create the output table
        tblOutput.Columns.Add("file_id", Type.GetType("System.String"))
        tblOutput.Columns.Add("record_id", Type.GetType("System.String"))
        tblOutput.Columns.Add("process_flag", Type.GetType("System.String"))
        tblOutput.Columns.Add("date", Type.GetType("System.String"))
        tblOutput.Columns.Add("emp_id", Type.GetType("System.String"))
        tblOutput.Columns.Add("eff_date", Type.GetType("System.String"))
        tblOutput.Columns.Add("action", Type.GetType("System.String"))
        tblOutput.Columns.Add("reason", Type.GetType("System.String"))
        tblOutput.Columns.Add("bertw", Type.GetType("System.String"))
        tblOutput.Columns.Add("OHN_ID", Type.GetType("System.String"))

        Dim rowCurrent As DataRow
        For Each rowCurrent In dsData.Tables(0).Rows
            'initialize all variables so we don't have any leftover settings from last row
            sAction = ""
            sReason = ""
            sProcessFlag = "I"
            bSkipEntry = False
            sBERTW = ""
            sEffDate = ""
            sEmpID = ""
            'first check to see if this is an orphaned event: an event not yet
            'attached to an episode. If so, do not extract it. Save it to 
            'the error log so someone in Service Delivery can look at it.
            If Not IsDBNull(rowCurrent.Item("I_OCCASE_CHILDCASES")) Then
                'If Not IsDBNull(rowCurrent.Item("flag")) Then
                sEmpID = rowCurrent.Item("emp_id")
                Try
                    sSubStatus = rowCurrent("reason")
                    Dim dtHold As System.DateTime
                    'LAR 05/27/2003 - as per revised specs, use asd
                    'If Not IsDBNull(rowCurrent("DATEABSENCE")) Then
                    If Not IsDBNull(rowCurrent("asd")) Then
                        'dtHold = rowCurrent("DATEABSENCE")
                        dtHold = rowCurrent("asd")
                        sEffDate = String.Format("{0:MM/dd/yyyy}", dtHold)
                    Else
                        sEffDate = ""
                    End If
                    If Not IsDBNull(rowCurrent("bertw")) Then
                        dtHold = rowCurrent("bertw")
                        sBERTW = String.Format("{0:MM/dd/yyyy}", dtHold)
                    Else
                        sBERTW = ""
                    End If
                    'LAR 05/30/2003 - as per revised specs, supress ALL future-dated pends
                    'LAR 07/10/2003 - should be using the asd in the comparisons. Extensions carry
                    'the fda of the event, so will always be in the past.
                    'If System.DateTime.Compare(CDate(rowCurrent("DATEABSENCE")), dtEndDate.Date) > 0 Then

                    ' BM 9/16/2003 - added check on status = "Pend"
                    'BM - 10/16/2003 - allow LTD Pends to flow through subsequent processing even if the ASD is after the end date
                    If System.DateTime.Compare(CDate(rowCurrent("asd")), dtEndDate.Date) > 0 _
                    And rowCurrent.Item("claimstatus") = "Pend" _
                    And rowCurrent.Item("leavetype") <> "550400001" Then
                        bSkipEntry = True
                    Else
                        'if the asd is after the fda, create a synthetic LOA/UNA row
                        'to cover the interim (this will get output any time they
                        'edit an event with such a condition, but avon can handle duplicates)
                        'note that this is only for non-cancelled std events. Only the first in an episode
                        '*****1A changes this**********
                        If rowCurrent.Item("claimstatus") <> "Cancelled" Then
                            If Not IsDBNull(rowCurrent("asd")) Then
                                If IsFirstEventInEp(rowCurrent("i"), rowCurrent("I_OCCASE_CHILDCASES"), True) Then
                                    If (CaseType(rowCurrent.Item("i")) <> "Extension") And (rowCurrent.Item("leavetype") <> "550400001") And (System.DateTime.Compare(CDate(rowCurrent.Item("asd")), CDate(rowCurrent.Item("DATEABSENCE"))) > 0) Then
                                        'If (rowCurrent("I_OCCASTYP_CASES") = 2) And (rowCurrent.Item("leavetype") <> "550400001") And (System.DateTime.Compare(CDate(rowCurrent.Item("asd")), CDate(rowCurrent.Item("DATEABSENCE"))) > 0) Then
                                        Dim newRow As DataRow
                                        newRow = tblOutput.NewRow()
                                        newRow("file_id") = "STD"
                                        newRow("record_id") = "02"
                                        newRow("process_flag") = "I"
                                        'LAR 10/24/2003 - changed the date to be the 'business date' per specs ie the date window for which we are running
                                        'newRow("date") = String.Format("{0:MM/dd/yyyy}", System.DateTime.Now)
                                        newRow("date") = String.Format("{0:MM/dd/yyyy}", CDate(sEndDate))
                                        newRow("emp_id") = sEmpID
                                        dtHold = CDate(rowCurrent.Item("DATEABSENCE"))
                                        newRow("eff_date") = String.Format("{0:MM/dd/yyyy}", dtHold)
                                        newRow("action") = "LOA"
                                        newRow("reason") = "UNA"
                                        newRow("bertw") = sBERTW
                                        newRow("OHN_ID") = rowCurrent.Item("OHN_ID")
                                        tblOutput.Rows.Add(newRow)
                                        'now let the usual processing  take place...
                                    End If
                                End If
                            End If
                        End If
                        Select Case rowCurrent.Item("claimstatus")
                            '1A
                        Case "Pend"
                                'Case Status.Pend
                                'Lots of reasons to skip a pend...
                                'first, check to see if this is for a preg or surgery
                                'if so, don't send anything, it'll get picked up when appr
                                If Not IsDBNull(rowCurrent.Item("PREGNANCY")) Then
                                    If rowCurrent.Item("PREGNANCY") = "1" And System.DateTime.Compare(CDate(rowCurrent("DATEABSENCE")), dtEndDate.Date) > 0 Then
                                        bSkipEntry = True
                                    End If
                                End If
                                'LAR 07/14/2003 - add future date to surgery conditions -- don't know
                                'why they were coded differently...
                                If Not IsDBNull(rowCurrent.Item("SCHEDSURGERY")) Then
                                    'If rowCurrent.Item("SCHEDSURGERY") = "1" Then
                                    If rowCurrent.Item("SCHEDSURGERY") = "1" And System.DateTime.Compare(CDate(rowCurrent("DATEABSENCE")), dtEndDate.Date) > 0 Then
                                        bSkipEntry = True
                                    End If
                                End If
                                'LAR 05/30/2003 - as per revised specs, supress ALL future-dated pends
                                If System.DateTime.Compare(CDate(rowCurrent("DATEABSENCE")), dtEndDate.Date) > 0 Then
                                    bSkipEntry = True
                                End If
                                'if this is a pended extension, don't extract it.
                                'bm - 10/6/2003 - Skip the following if statement for LTD
                                If (rowCurrent.Item("leavetype") <> "550400001") Then
                                    'LAR 12/03/2004 2350 - Remove all the 21-day Pend logic...
                                    If CaseType(rowCurrent.Item("i")) = "Extension" Then
                                        'LAR 08/05/2003 - added this so we don't keep seeing pended extensions with Ps coming in
                                        'This caused a problem when the extensions went to denied
                                        'update this row's flag to 'S' so it doesn't get picked up again
                                        'RunSQL("update s_TCORECLAIMDATAFEED set flag = 'X' where uniqueid = " _
                                        '        & rowCurrent("uniqueid") _
                                        '        & " and claimstatus = 550496000 and flag = 'P'")
                                        bSkipEntry = True
                                    Else
                                        'if this is not the 1st non-canc event in an ep, don't extract it
                                        If Not IsFirstEventInEp(rowCurrent("I"), rowCurrent("I_OCCASE_CHILDCASES"), True) Then
                                            'LAR 08/05/2003 - added this so we don't keep seeing pended non-1st events with Ps coming in
                                            'This caused a problem when the events went to denied
                                            'update this row's flag to 'S' so it doesn't get picked up again
                                            'LAR 12/03/2004 2350 - Remove all the 21-day Pend logic
                                            'RunSQL("update s_TCORECLAIMDATAFEED set flag = 'X' where uniqueid = " _
                                            '        & rowCurrent("uniqueid") _
                                            '        & " and claimstatus = 550496000 and flag = 'P'")
                                            bSkipEntry = True
                                        End If
                                    End If
                                End If
                                    'LAR 07/11/03 - don't extract any more pend stuff for an item that 
                                    'was previously flagged with the 21 day rule
                                    'LAR 12/03/2004 2350 - Remove all the 21-day Pend logic
                                    'If (rowCurrent("flag") = "S") Or (rowCurrent("flag") = "X") Then
                                    '    bSkipEntry = True
                                    'End If
                                    If Not bSkipEntry Then
                                        'LAR 12/03/2004 2350 - Remove all the 21-day Pend logic
                                        'If rowCurrent("flag") = "P" Then
                                        '    'next, if we're pended > 21 days, they're toast
                                        '    'LAR 05/30/2003 - as per revised specs, ensure the
                                        '    '21-day thing only happens with 1st std event
                                        '    'bm - 10/6/2003 - switch order of if statement to avoid isfirsteventinep for LTD
                                        '    'If (IsFirstEventInEp(rowCurrent("I"), rowCurrent("I_OCCASE_CHILDCASES"), True) And rowCurrent.Item("leavetype") = "550400000") Then
                                        '    If (rowCurrent.Item("leavetype") = "550400000") And (IsFirstEventInEp(rowCurrent("I"), rowCurrent("I_OCCASE_CHILDCASES"), True)) Then
                                        '        sAction = "LOA"
                                        '        sReason = "UNA"
                                        '        'update this row's flag to 'S' so it doesn't get picked up again
                                        '        RunSQL("update s_TCORECLAIMDATAFEED set flag = 'S' where uniqueid = " _
                                        '                & rowCurrent("uniqueid") _
                                        '                & " and claimstatus = 'Pend' and flag = 'P'")
                                        '    Else
                                        '        'if it isn't the 1st event we won't extract it
                                        '        bSkipEntry = True
                                        '        'update this row's flag to 'X' so it doesn't get picked up again
                                        '        'and the denied won't be suppressed
                                        '        RunSQL("update s_TCORECLAIMDATAFEED set flag = 'X' where uniqueid = " _
                                        '                & rowCurrent("uniqueid") _
                                        '                & " and claimstatus = 'Pend' and flag = 'P'")
                                        '    End If
                                        'ElseIf sSubStatus = "Appeal" Or sSubStatus = "In Appeal" Or sSubStatus = "Per Appeal" Then
                                        If sSubStatus = "Appeal" Or sSubStatus = "In Appeal" Or sSubStatus = "Per Appeal" Then
                                            'if a new event is created as pended for appeal, don't send it
                                            bSkipEntry = True
                                        ElseIf sSubStatus = "Part Time" Then 'PT RTW w/Mods
                                            'sEffDate = String.Format("{0:MM/dd/yyyy}", rowCurrent("last_update"))
                                            sAction = "STD"
                                            sReason = "MRW"
                                        ElseIf rowCurrent.Item("leavetype") = "550400001" Then    'ltd
                                            'since we have a new ltd claim for this ee, we
                                            'won't want to send a row when the std expires.
                                            'set the flag to T so when processing the std exp
                                            'we know not to extract a row.
                                            'btw, we are setting ALL std rows for this employee
                                            'NOTE this is replicated below during ltd approved,
                                            'just in case they create and approve it same day with no pend
                                            RunSQL("update s_TCORECLAIMDATAFEED set flag = 'T' where uniqueid = " _
                                                    & rowCurrent("uniqueid") _
                                                    & " and leavetype != 550400001")
                                            'have to also do it in the current recordset in case 
                                            'the std claim is in it.
                                            Dim dvDataView As New DataView(dsData.Tables(0))
                                            dvDataView.RowFilter = "uniqueid = " & rowCurrent("uniqueid") _
                                                    & " and leavetype <> 550400001"
                                            Dim drv As DataRowView
                                            For Each drv In dvDataView
                                                drv("flag") = "T"
                                            Next
                                            dsData.AcceptChanges()
                                            'don't extract the ltd pnd
                                            bSkipEntry = True
                                        Else
                                            'if there is no specific processing for this pend reason, use the default
                                            sAction = "STD"
                                            sReason = "PND"
                                        End If
                                    End If
                            Case "Approved"
                                    If sSubStatus = "Part Time" Then 'PT RTW w/Mods
                                        sAction = "STO"
                                        sReason = "MRW"
                                    Else
                                        Select Case rowCurrent.Item("leavetype")
                                            Case "550400001"    'ltd
                                                'is it workers comp?
                                                If rowCurrent("workinjury") = 1 Then
                                                    sAction = "LTO"
                                                    sReason = "WKC"
                                                Else
                                                    sAction = "LTO"
                                                    sReason = "LTD"
                                                End If
                                                'since we have a new ltd claim for this ee, we
                                                'won't want to send a row when the std expires.
                                                'set the flag to T so when processing the std exp
                                                'we know not to extract a row.
                                                'btw, we are setting ALL std rows for this employee
                                                RunSQL("update s_TCORECLAIMDATAFEED set flag = 'T' where uniqueid = " _
                                                        & rowCurrent("uniqueid") _
                                                        & " and leavetype != 550400001")
                                                'have to also do it in the current recordset in case 
                                                'the std claim is in it.
                                                Dim dvDataView As New DataView(dsData.Tables(0))
                                                dvDataView.RowFilter = "uniqueid = " & rowCurrent("uniqueid") _
                                                        & " and leavetype <> 550400001"
                                                Dim drv As DataRowView
                                                For Each drv In dvDataView
                                                    drv("flag") = "T"
                                                Next
                                                dsData.AcceptChanges()
                                            Case "550400000"    'std
                                                'is it workers comp?
                                                If rowCurrent("workinjury") = 1 Then
                                                    sAction = "STD"
                                                    sReason = "WKC"
                                                Else
                                                    'otherwise default
                                                    sAction = "STD"
                                                    sReason = "STD"
                                                End If
                                            Case "550400003"        'States Disability
                                                sAction = "STO"
                                                sReason = "MND"
                                            Case "550400002"        'explicit workers comp
                                                sAction = "STD"
                                                sReason = "WKC"
                                        End Select
                                    End If
                            Case "Denied"
                                    'LAR 12/03/2004 2350 - Remove all the 21-day Pend logic
                                    'if the 21 day flag is already set to P, we sent the LOA/UNA
                                    'already when it went past 21 days pend, so don't send another
                                    'LAR 05/30/2003 - this should be 'S'...
                                    'If rowCurrent.Item("flag") = "P" Then
                                    'BM - 10/17/2003 - Suppress if T"
                                    'If rowCurrent.Item("flag") = "P" Or rowCurrent.Item("flag") = "S" Or rowCurrent.Item("flag") = "T" Then
                                    '    bSkipEntry = True
                                    'Else
                                    'otherwise every denial gens the default
                                    sAction = "LOA"
                                    sReason = "UNA"
                                    'bm - 10/6/2003 - set effective date for LTD based upon closure reason
                                    Select Case rowCurrent.Item("leavetype")
                                        Case "550400001"    'ltd
                                            Dim strParms As String
                                            strParms = sEmpID
                                            Dim strFlag As String
                                            If RunSQL("PK_feeds.sp_get_avon_std_claim", strParms, dsDataTemp, "WKAB") Then
                                                strFlag = dsDataTemp.Tables(0).Rows(0).Item("flag")
                                                Select Case dsDataTemp.Tables(0).Rows(0).Item("claimstatus")
                                                    Case "Approved"
                                                        RunSQL("update s_TCORECLAIMDATAFEED set flag = 'A' where uniqueid = " _
                                                            & dsDataTemp.Tables(0).Rows(0).Item("uniqueid") _
                                                            & " and claimstatus = 'Approved' and flag = 'T'")
                                                        bSkipEntry = True
                                                    Case "Pend"
                                                        RunSQL("update s_TCORECLAIMDATAFEED set flag = 'P' where uniqueid = " _
                                                            & dsDataTemp.Tables(0).Rows(0).Item("uniqueid") _
                                                            & " and claimstatus = 'Pend' and flag = 'T'")
                                                        bSkipEntry = True
                                                    Case "Cancelled"
                                                        RunSQL("update s_TCORECLAIMDATAFEED set flag = 'X' where uniqueid = " _
                                                            & dsDataTemp.Tables(0).Rows(0).Item("uniqueid") _
                                                            & " and claimstatus = 'Cancelled' and flag = 'T'")
                                                        bSkipEntry = True
                                                    Case "Denied"
                                                        RunSQL("update s_TCORECLAIMDATAFEED set flag = 'D' where uniqueid = " _
                                                            & dsDataTemp.Tables(0).Rows(0).Item("uniqueid") _
                                                            & " and claimstatus = 'Denied' and flag = 'T'")
                                                        'LOA/UNA
                                                        sAction = "LOA"
                                                        sReason = "UNA"
                                                        'LAR 07/22/03 - check for nulls (I keep getting bit by missing data)
                                                        If Not IsDBNull(dsDataTemp.Tables(0).Rows(0).Item("asd")) Then
                                                            Dim dtTemp As System.DateTime = dsDataTemp.Tables(0).Rows(0).Item("asd")
                                                            sEffDate = String.Format("{0:MM/dd/yyyy}", dtTemp)
                                                        End If
                                                    Case "Closed"
                                                        'If IsLastNonCancEventExtInEp(dsDataTemp.Tables(0).Rows(0).Item("I"), dsDataTemp.Tables(0).Rows(0).Item("I_OCCASE_CHILDCASES")) Then
                                                        If dsDataTemp.Tables(0).Rows(0).Item("Reason") = "Return to Work" Then    'Return to Work
                                                            sAction = "RFL"
                                                            sReason = "RFL"
                                                            sBERTW = ""
                                                            If Not IsDBNull(dsDataTemp.Tables(0).Rows(0).Item("actualrtw")) Then
                                                                Dim dtTemp As System.DateTime = dsDataTemp.Tables(0).Rows(0).Item("actualrtw")
                                                                sEffDate = String.Format("{0:MM/dd/yyyy}", dtTemp)
                                                            Else
                                                                If Not IsDBNull(dsDataTemp.Tables(0).Rows(0).Item("atd")) Then
                                                                    Dim dtTemp As System.DateTime = dsDataTemp.Tables(0).Rows(0).Item("atd")
                                                                    dtTemp = dtTemp.AddDays(1).ToString
                                                                    sEffDate = String.Format("{0:MM/dd/yyyy}", dtTemp)
                                                                End If
                                                            End If
                                                        ElseIf dsDataTemp.Tables(0).Rows(0).Item("Reason") = "Benefit Expired" Then    'Benefit Expired
                                                            sAction = "LOA"
                                                            sReason = "END"
                                                            'LAR 07/22/03 - check for nulls (I keep getting bit by missing data)
                                                            If Not IsDBNull(dsDataTemp.Tables(0).Rows(0).Item("atd")) Then
                                                                Dim dtTemp As System.DateTime = dsDataTemp.Tables(0).Rows(0).Item("atd")
                                                                dtTemp = dtTemp.AddDays(1).ToString
                                                                sEffDate = String.Format("{0:MM/dd/yyyy}", dtTemp)
                                                            End If
                                                        End If
                                                        RunSQL("update s_TCORECLAIMDATAFEED set flag = 'C' where uniqueid = " _
                                                            & dsDataTemp.Tables(0).Rows(0).Item("uniqueid") _
                                                            & " and claimstatus = 'Closed' and flag = 'T'")
                                                End Select
                                                If Not bSkipEntry Then
                                                    Dim newRow As DataRow
                                                    newRow = tblOutput.NewRow()
                                                    newRow("file_id") = "STD"
                                                    newRow("record_id") = "02"
                                                    newRow("process_flag") = "I"
                                                    'LAR 10/24/2003 - changed the date to be the 'business date' per specs ie the date window for which we are running
                                                    'newRow("date") = String.Format("{0:MM/dd/yyyy}", System.DateTime.Now)
                                                    newRow("date") = String.Format("{0:MM/dd/yyyy}", CDate(sEndDate))
                                                    newRow("emp_id") = sEmpID
                                                    dtHold = dsDataTemp.Tables(0).Rows(0).Item("asd") '?????????
                                                    newRow("eff_date") = String.Format("{0:MM/dd/yyyy}", sEffDate)
                                                    newRow("action") = sAction
                                                    newRow("reason") = sReason
                                                    newRow("bertw") = sBERTW
                                                    newRow("OHN_ID") = rowCurrent.Item("OHN_ID")
                                                    tblOutput.Rows.Add(newRow)
                                                    bSkipEntry = True
                                                End If
                                                dsDataTemp.Clear()
                                            End If
                                        Case Else
                                            'if this is a denied extension, use its start date as eff date,
                                            'not the dateabsence of the parent event
                                            '
                                            If CaseType(rowCurrent.Item("i")) = "Extension" Then
                                                'LAR 07/22/03 - check for nulls (I keep getting bit by missing data)
                                                If Not IsDBNull(rowCurrent("asd")) Then
                                                    dtHold = rowCurrent("asd")
                                                    sEffDate = String.Format("{0:MM/dd/yyyy}", dtHold)
                                                End If
                                            End If

                                    End Select
                                    'End If
                            Case "Closed"
                                    'only report on a closed event/ext if it is the last non-canc one in the episode
                                    'bm - 10/6/2003 - bypass check for lastnoncancevent if LTD
                                    If rowCurrent.Item("leavetype") = "550400001" Then
                                        bContinue = True
                                    Else
                                        bContinue = IsLastNonCancEventExtInEp(rowCurrent("I"), rowCurrent("I_OCCASE_CHILDCASES"))
                                    End If
                                    If bContinue Then
                                        Select Case rowCurrent.Item("leavetype")
                                            Case "550400001"    'ltd
                                                Select Case sSubStatus
                                                    Case "RTW"
                                                        sAction = "RFL"
                                                        sReason = "RFL"
                                                        sBERTW = ""
                                                        If Not IsDBNull(rowCurrent("actualrtw")) Then
                                                            Dim dtTemp As System.DateTime = rowCurrent("actualrtw")
                                                            sEffDate = String.Format("{0:MM/dd/yyyy}", dtTemp)
                                                        Else
                                                            If Not IsDBNull(rowCurrent("atd")) Then
                                                                Dim dtTemp As System.DateTime = rowCurrent.Item("atd")
                                                                dtTemp = dtTemp.AddDays(1).ToString
                                                                sEffDate = String.Format("{0:MM/dd/yyyy}", dtTemp)
                                                            End If
                                                        End If
                                                    Case "Partial earnings exceed cap"
                                                        sAction = "RFL"
                                                        sReason = "RFL"
                                                        sBERTW = ""
                                                        If Not IsDBNull(rowCurrent("LIABILITYENDDATE")) Then
                                                            Dim dtTemp As System.DateTime = rowCurrent.Item("LIABILITYENDDATE")
                                                            sEffDate = String.Format("{0:MM/dd/yyyy}", dtTemp)
                                                        End If
                                                    Case "Max Duration" 'same as benefit expired from Fineos
                                                        sAction = "LOA"
                                                        sReason = "END"
                                                        If Not IsDBNull(rowCurrent("LIABILITYENDDATE")) Then
                                                            Dim dtTemp As System.DateTime = rowCurrent.Item("LIABILITYENDDATE")
                                                            sEffDate = String.Format("{0:MM/dd/yyyy}", dtTemp)
                                                        End If
                                                    Case "Employer's Request"
                                                        sAction = "LOA"
                                                        sReason = "END"
                                                        If Not IsDBNull(rowCurrent("LIABILITYENDDATE")) Then
                                                            Dim dtTemp As System.DateTime = rowCurrent.Item("LIABILITYENDDATE")
                                                            sEffDate = String.Format("{0:MM/dd/yyyy}", dtTemp)
                                                        End If
                                                    Case "Settled"
                                                        sAction = "LOA"
                                                        sReason = "END"
                                                        If Not IsDBNull(rowCurrent("LIABILITYENDDATE")) Then
                                                            Dim dtTemp As System.DateTime = rowCurrent.Item("LIABILITYENDDATE")
                                                            sEffDate = String.Format("{0:MM/dd/yyyy}", dtTemp)
                                                        End If
                                                    Case "End of rehab period"
                                                        sAction = "LOA"
                                                        sReason = "UNA"
                                                        If Not IsDBNull(rowCurrent("LIABILITYENDDATE")) Then
                                                            Dim dtTemp As System.DateTime = rowCurrent.Item("LIABILITYENDDATE")
                                                            sEffDate = String.Format("{0:MM/dd/yyyy}", dtTemp)
                                                        End If
                                                    Case "Other"
                                                        sAction = "LOA"
                                                        sReason = "END"
                                                        If Not IsDBNull(rowCurrent("LIABILITYENDDATE")) Then
                                                            Dim dtTemp As System.DateTime = rowCurrent.Item("LIABILITYENDDATE")
                                                            sEffDate = String.Format("{0:MM/dd/yyyy}", dtTemp)
                                                        End If
                                                    Case "M/N / D&A limit"
                                                        sAction = "LOA"
                                                        sReason = "END"
                                                        If Not IsDBNull(rowCurrent("LIABILITYENDDATE")) Then
                                                            Dim dtTemp As System.DateTime = rowCurrent.Item("LIABILITYENDDATE")
                                                            sEffDate = String.Format("{0:MM/dd/yyyy}", dtTemp)
                                                        End If
                                                    Case "Pregnancy"
                                                        sAction = "LOA"
                                                        sReason = "END"
                                                        If Not IsDBNull(rowCurrent("LIABILITYENDDATE")) Then
                                                            Dim dtTemp As System.DateTime = rowCurrent.Item("LIABILITYENDDATE")
                                                            sEffDate = String.Format("{0:MM/dd/yyyy}", dtTemp)
                                                        End If
                                                    Case "Workers Comp. Approved"
                                                        sAction = "LOA"
                                                        sReason = "END"
                                                        If Not IsDBNull(rowCurrent("LIABILITYENDDATE")) Then
                                                            Dim dtTemp As System.DateTime = rowCurrent.Item("LIABILITYENDDATE")
                                                            sEffDate = String.Format("{0:MM/dd/yyyy}", dtTemp)
                                                        End If
                                                    Case "Retirement"
                                                        sAction = "LOA"
                                                        sReason = "END"
                                                        If Not IsDBNull(rowCurrent("LIABILITYENDDATE")) Then
                                                            Dim dtTemp As System.DateTime = rowCurrent.Item("LIABILITYENDDATE")
                                                            sEffDate = String.Format("{0:MM/dd/yyyy}", dtTemp)
                                                        End If
                                                    Case "Pre-ex Limit"
                                                        sAction = "LOA"
                                                        sReason = "END"
                                                        If Not IsDBNull(rowCurrent("LIABILITYENDDATE")) Then
                                                            Dim dtTemp As System.DateTime = rowCurrent.Item("LIABILITYENDDATE")
                                                            sEffDate = String.Format("{0:MM/dd/yyyy}", dtTemp)
                                                        End If
                                                    Case "Known Liability Settlements"
                                                        sAction = "LOA"
                                                        sReason = "END"
                                                        If Not IsDBNull(rowCurrent("LIABILITYENDDATE")) Then
                                                            Dim dtTemp As System.DateTime = rowCurrent.Item("LIABILITYENDDATE")
                                                            sEffDate = String.Format("{0:MM/dd/yyyy}", dtTemp)
                                                        End If
                                                    Case "Own Occ Settlements"
                                                        sAction = "LOA"
                                                        sReason = "END"
                                                        If Not IsDBNull(rowCurrent("LIABILITYENDDATE")) Then
                                                            Dim dtTemp As System.DateTime = rowCurrent.Item("LIABILITYENDDATE")
                                                            sEffDate = String.Format("{0:MM/dd/yyyy}", dtTemp)
                                                        End If
                                                    Case "AP&C-Maternity"
                                                        sAction = "LOA"
                                                        sReason = "END"
                                                        If Not IsDBNull(rowCurrent("LIABILITYENDDATE")) Then
                                                            Dim dtTemp As System.DateTime = rowCurrent.Item("LIABILITYENDDATE")
                                                            sEffDate = String.Format("{0:MM/dd/yyyy}", dtTemp)
                                                        End If
                                                    Case "AP&C-Other"
                                                        sAction = "LOA"
                                                        sReason = "END"
                                                        If Not IsDBNull(rowCurrent("LIABILITYENDDATE")) Then
                                                            Dim dtTemp As System.DateTime = rowCurrent.Item("LIABILITYENDDATE")
                                                            sEffDate = String.Format("{0:MM/dd/yyyy}", dtTemp)
                                                        End If
                                                    Case "Subsequent Disability"
                                                        sAction = "LOA"
                                                        sReason = "END"
                                                        If Not IsDBNull(rowCurrent("LIABILITYENDDATE")) Then
                                                            Dim dtTemp As System.DateTime = rowCurrent.Item("LIABILITYENDDATE")
                                                            sEffDate = String.Format("{0:MM/dd/yyyy}", dtTemp)
                                                        End If
                                                    Case Else
                                                        dtHold = rowCurrent("asd")
                                                        sEffDate = String.Format("{0:MM/dd/yyyy}", dtHold)
                                                End Select
                                            Case Else
                                                Select Case sSubStatus
                                                    Case "Return to Work"
                                                        'BM - 10/17/2003 - Suppress if "T"
                                                        If rowCurrent.Item("flag") = "T" Then
                                                            bSkipEntry = True
                                                        Else
                                                            sAction = "RFL"
                                                            sReason = "RFL"
                                                            sBERTW = ""
                                                            If Not IsDBNull(rowCurrent("actualrtw")) Then
                                                                Dim dtTemp As System.DateTime = rowCurrent.Item("actualrtw")
                                                                sEffDate = String.Format("{0:MM/dd/yyyy}", dtTemp)
                                                            Else
                                                                'LAR 05/27/2003 - as per revised specs, use atd + 1
                                                                'sEffDate = ""
                                                                'LAR 07/22/03 - check for nulls (I keep getting bit by missing data)
                                                                If Not IsDBNull(rowCurrent("atd")) Then
                                                                    Dim dtTemp As System.DateTime = rowCurrent.Item("atd")
                                                                    dtTemp = dtTemp.AddDays(1).ToString
                                                                    sEffDate = String.Format("{0:MM/dd/yyyy}", dtTemp)
                                                                End If
                                                            End If
                                                        End If
                                                    Case "Benefit Expired"
                                                        'need to know if it is transitioning to ltd
                                                        'check the flag for 'T', which would have been set on the std
                                                        'claim when the ltd claim was opened
                                                        If rowCurrent.Item("flag") = "T" Then
                                                            bSkipEntry = True
                                                        Else
                                                            sAction = "LOA"
                                                            sReason = "END"
                                                            'LAR 07/22/03 - check for nulls (I keep getting bit by missing data)
                                                            If Not IsDBNull(rowCurrent("atd")) Then
                                                                Dim dtTemp As System.DateTime = rowCurrent.Item("atd")
                                                                dtTemp = dtTemp.AddDays(1).ToString
                                                                sEffDate = String.Format("{0:MM/dd/yyyy}", dtTemp)
                                                            End If
                                                        End If
                                                    Case Else
                                                        ' no action
                                                End Select
                                        End Select
                                    Else
                                        bSkipEntry = True
                                    End If
                                    '1A
                            Case "Cancelled"
                                    'Case Status.Cancelled
                                    'for cancelleds, decide if it is the 1st event in ep,
                                    'and if it was ever pended overnight. If so, we sent 
                                    'an std/pnd on it, so we have to synthesize
                                    'a duplicate of the original pend, with the delete flag set
                                    'update: per revised reqs, we will send the log delete of std/pnd
                                    'for any event that was pend or appr overnight.
                                    'and any ext appr overnight.
                                    'If IsFirstEventInEp(rowCurrent("I"), rowCurrent("I_OCCASE_CHILDCASES"), False) Then
                                    ' bm - 10/7/2003 - bypass logical delete processing for LTD.  For LTD, reset the flag on the
                                    '                  STD claim.  Send a dummy STD close if the last status was closed on the STD claim.
                                    Select Case rowCurrent.Item("leavetype")
                                        Case "550400001"    'ltd
                                            Dim strParms As String
                                            strParms = sEmpID
                                            Dim strFlag As String
                                            If RunSQL("PK_feeds.sp_get_avon_std_claim", strParms, dsDataTemp, "WKAB") Then
                                                strFlag = dsDataTemp.Tables(0).Rows(0).Item("flag")
                                                Select Case dsDataTemp.Tables(0).Rows(0).Item("claimstatus")
                                                    Case "Approved"
                                                        RunSQL("update s_TCORECLAIMDATAFEED set flag = 'A' where uniqueid = " _
                                                           & dsDataTemp.Tables(0).Rows(0).Item("uniqueid") _
                                                           & " and claimstatus = 'Approved' and flag = 'T'")
                                                        bSkipEntry = True
                                                    Case "Pend"
                                                        RunSQL("update s_TCORECLAIMDATAFEED set flag = 'P' where uniqueid = " _
                                                           & dsDataTemp.Tables(0).Rows(0).Item("uniqueid") _
                                                           & " and claimstatus = 'Pend' and flag = 'T'")
                                                        bSkipEntry = True
                                                    Case "Cancelled"
                                                        RunSQL("update s_TCORECLAIMDATAFEED set flag = 'X' where uniqueid = " _
                                                           & dsDataTemp.Tables(0).Rows(0).Item("uniqueid") _
                                                           & " and claimstatus = 'Cancelled' and flag = 'T'")
                                                        bSkipEntry = True
                                                    Case "Denied"
                                                        RunSQL("update s_TCORECLAIMDATAFEED set flag = 'D' where uniqueid = " _
                                                           & dsDataTemp.Tables(0).Rows(0).Item("uniqueid") _
                                                           & " and claimstatus = 'Denied' and flag = 'T'")
                                                        'LOA/UNA
                                                        sAction = "LOA"
                                                        sReason = "UNA"
                                                        'LAR 07/22/03 - check for nulls (I keep getting bit by missing data)
                                                        If Not IsDBNull(dsDataTemp.Tables(0).Rows(0).Item("asd")) Then
                                                            Dim dtTemp As System.DateTime = dsDataTemp.Tables(0).Rows(0).Item("asd")
                                                            sEffDate = String.Format("{0:MM/dd/yyyy}", dtTemp)
                                                        End If
                                                    Case "Closed"
                                                        'If IsLastNonCancEventExtInEp(dsDataTemp.Tables(0).Rows(0).Item("I"), dsDataTemp.Tables(0).Rows(0).Item("I_OCCASE_CHILDCASES")) Then
                                                        If dsDataTemp.Tables(0).Rows(0).Item("Reason") = "Return to Work" Then    'Return to Work
                                                            sAction = "RFL"
                                                            sReason = "RFL"
                                                            sBERTW = ""
                                                            If Not IsDBNull(dsDataTemp.Tables(0).Rows(0).Item("actualrtw")) Then
                                                                Dim dtTemp As System.DateTime = dsDataTemp.Tables(0).Rows(0).Item("actualrtw")
                                                                sEffDate = String.Format("{0:MM/dd/yyyy}", dtTemp)
                                                            Else
                                                                If Not IsDBNull(dsDataTemp.Tables(0).Rows(0).Item("atd")) Then
                                                                    Dim dtTemp As System.DateTime = dsDataTemp.Tables(0).Rows(0).Item("atd")
                                                                    dtTemp = dtTemp.AddDays(1).ToString
                                                                    sEffDate = String.Format("{0:MM/dd/yyyy}", dtTemp)
                                                                End If
                                                            End If
                                                        ElseIf dsDataTemp.Tables(0).Rows(0).Item("Reason") = "Benefit Expired" Then    'Benefit Expired
                                                            sAction = "LOA"
                                                            sReason = "END"
                                                            'LAR 07/22/03 - check for nulls (I keep getting bit by missing data)
                                                            If Not IsDBNull(dsDataTemp.Tables(0).Rows(0).Item("atd")) Then
                                                                Dim dtTemp As System.DateTime = dsDataTemp.Tables(0).Rows(0).Item("atd")
                                                                dtTemp = dtTemp.AddDays(1).ToString
                                                                sEffDate = String.Format("{0:MM/dd/yyyy}", dtTemp)
                                                            End If
                                                        End If
                                                        RunSQL("update s_TCORECLAIMDATAFEED set flag = 'C' where uniqueid = " _
                                                           & dsDataTemp.Tables(0).Rows(0).Item("uniqueid") _
                                                           & " and claimstatus = 'Closed' and flag = 'T'")
                                                End Select
                                                If Not bSkipEntry Then
                                                    Dim newRow As DataRow
                                                    newRow = tblOutput.NewRow()
                                                    newRow("file_id") = "STD"
                                                    newRow("record_id") = "02"
                                                    newRow("process_flag") = "I"
                                                    'LAR 10/24/2003 - changed the date to be the 'business date' per specs ie the date window for which we are running
                                                    'newRow("date") = String.Format("{0:MM/dd/yyyy}", System.DateTime.Now)
                                                    newRow("date") = String.Format("{0:MM/dd/yyyy}", CDate(sEndDate))
                                                    newRow("emp_id") = sEmpID
                                                    dtHold = dsDataTemp.Tables(0).Rows(0).Item("asd") '?????????
                                                    newRow("eff_date") = String.Format("{0:MM/dd/yyyy}", sEffDate)
                                                    newRow("action") = sAction
                                                    newRow("reason") = sReason
                                                    newRow("bertw") = sBERTW
                                                    newRow("OHN_ID") = rowCurrent.Item("OHN_ID")
                                                    tblOutput.Rows.Add(newRow)
                                                    bSkipEntry = True
                                                End If
                                                dsDataTemp.Clear()
                                            End If
                                        Case Else
                                            Dim bLogicalDelete As Boolean = False
                                            Select Case CaseType(rowCurrent("I"))
                                                Case "Event"
                                                    If WasPendedOvernight(rowCurrent("I")) Or WasApprovedOvernight(rowCurrent("I")) Then
                                                        bLogicalDelete = True
                                                    End If
                                                Case "Extension"
                                                    If WasApprovedOvernight(rowCurrent("I")) Then
                                                        bLogicalDelete = True
                                                    End If
                                            End Select
                                            If bLogicalDelete Then
                                                Dim newRow As DataRow
                                                newRow = tblOutput.NewRow()
                                                newRow("file_id") = "STD"
                                                newRow("record_id") = "02"
                                                newRow("process_flag") = "D"
                                                'LAR 10/24/2003 - changed the date to be the 'business date' per specs ie the date window for which we are running
                                                'newRow("date") = String.Format("{0:MM/dd/yyyy}", System.DateTime.Now)
                                                newRow("date") = String.Format("{0:MM/dd/yyyy}", CDate(sEndDate))
                                                newRow("emp_id") = sEmpID
                                                dtHold = rowCurrent("asd")
                                                newRow("eff_date") = String.Format("{0:MM/dd/yyyy}", dtHold)
                                                newRow("action") = "STD"
                                                newRow("reason") = "PND"
                                                newRow("bertw") = sBERTW
                                                newRow("OHN_ID") = rowCurrent.Item("OHN_ID")
                                                tblOutput.Rows.Add(newRow)
                                            End If
                                            bLogicalDelete = False
                                            'don't send the actual cancelled entry
                                            bSkipEntry = True
                                    End Select
                            Case Else
                                    'ERROR: NOT A HANDLED STATUS
                                    bSkipEntry = True
                        End Select
                    End If
                    'Suppress anything from the Aetna world - they will be input if the ee
                    'relapses and we need it for historical purposes
                    'LAR 07/22/03 - check for nulls (I keep getting bit by missing data)
                    If Not bSkipEntry Then
                        Dim sEpisodeI As String = ""
                        If CaseType(rowCurrent("i")) = "Extension" Then
                            RunSQL("select I_OCCASE_CHILDCASES from s_toccase where i = " & _
                               rowCurrent("i_occase_childcases"), "", dsDataTemp)
                            Try
                                sEpisodeI = dsDataTemp.Tables(0).Rows(0)("I_OCCASE_CHILDCASES")
                            Catch ex As System.Exception
                                'throw an exception 
                                bSkipEntry = True
                                Throw New System.Exception("Could not walk up to episode for extension " & rowCurrent("i") & _
                                   " with I_OCCASE_CHILDCASES = " & rowCurrent("i_occase_childcases") & _
                                   " " & ex.Message & " " & ex.InnerException.Message)
                                Return False
                            End Try
                            dsDataTemp.Clear()
                        Else        'event
                            sEpisodeI = rowCurrent("i_occase_childcases")
                        End If
                        If Not IsDBNull(rowCurrent("asd")) Then
                            'LAR 07/22/03 - check for nulls (I keep getting bit by missing data)
                            If IsDate(sEffDate) Then
                                ' bm - 10/13/2003 - add logic to get the earliest ASD for this episode
                                'if earliest asd is before 4/1/2003, then skip the transaction
                                Dim dtEarliestASD As System.DateTime = System.DateTime.Now
                                RunSQL("select min(asd) as earliestasd " & _
                                " from s_toccase, s_tocprocessinstance, s_tocprocessstep " & _
                                " where s_toccase.I_OCCASE_CHILDCASES = " & sEpisodeI & _
                                " AND s_toccase.i_ocactvty_resultingacti = s_tocprocessinstance.i " & _
                                " AND s_tocprocessinstance.i_ocprostp_currentstepof = s_tocprocessstep.i " & _
                                " and s_tocprocessstep.GUISTEPNAME not in ('Cancelled', 'Denied', 'Pend')", "", dsDataTemp)
                                'RunSQL("select min(asd) as earliestasd from s_toccase " & _
                                '       "where s_toccase.i = " & sEpisodeI & _
                                '       " and s_toccase.claimstatus not in ('Pend', 'Cancelled')", "", dsDataTemp)
                                If dsDataTemp.Tables(0).Rows.Count > 0 Then
                                    If Not IsDBNull(dsDataTemp.Tables(0).Rows(0).Item("earliestasd")) Then
                                        dtEarliestASD = dsDataTemp.Tables(0).Rows(0).Item("earliestasd")
                                    End If
                                    dsDataTemp.Clear()
                                    Dim dtStart As System.DateTime = System.DateTime.Parse("04/01/2003")
                                    Dim dtEff As System.DateTime = System.DateTime.Parse(sEffDate)
                                    Dim dtASD As System.DateTime = System.DateTime.Parse(rowCurrent("asd"))
                                    If (dtStart > dtEff) Or (dtStart > dtASD) Or (dtEarliestASD < dtStart) Then
                                        bSkipEntry = True
                                    End If
                                End If
                            End If
                        End If
                    End If
                Catch
                    'LAR 11/23/2004 - if there was a data problem with this record then just log it and go on to the next.
                    'Service Delivery will have to fix the claim tomorrow.
                    Dim i As Integer = 0
                    'save off the details of the offending row
                    For i = 0 To rowCurrent.Table.Columns.Count - 1
                        sBadRowsData &= rowCurrent(i) & ";"
                    Next
                    'removing trailing delimiter & add linefeed
                    sBadRowsData = Left(sBadRowsData, Len(sBadRowsData) - 1) & vbCr & vbLf
                    bBadRows = True
                    bSkipEntry = True
                End Try

                If Not bSkipEntry Then
                    'now add the data to the work table
                    Dim newRow As DataRow
                    newRow = tblOutput.NewRow()
                    newRow("file_id") = "STD"
                    newRow("record_id") = "02"
                    newRow("process_flag") = sProcessFlag
                    'LAR 10/24/2003 - changed the date to be the 'business date' per specs ie the date window for which we are running
                    'newRow("date") = String.Format("{0:MM/dd/yyyy}", System.DateTime.Now)
                    newRow("date") = String.Format("{0:MM/dd/yyyy}", CDate(sEndDate))
                    newRow("emp_id") = sEmpID
                    sEffDate = String.Format("{0:MM/dd/yyyy}", sEffDate)
                    newRow("eff_date") = sEffDate
                    newRow("action") = sAction
                    newRow("reason") = sReason
                    newRow("bertw") = sBERTW
                    newRow("OHN_ID") = rowCurrent.Item("OHN_ID")
                    tblOutput.Rows.Add(newRow)
                End If
                bSkipEntry = False
                'End If
            Else
                'we have an orphaned event. Log it and go on.
                bOrphans = True
                Dim i As Integer = 0
                'save off the details of the offending row
                For i = 0 To rowCurrent.Table.Columns.Count - 1
                    sOrphanData &= rowCurrent(i) & ";"
                Next
                'removing trailing delimiter & add linefeed
                sOrphanData = Left(sOrphanData, Len(sOrphanData) - 1) & vbCr & vbLf
            End If
        Next

        'drop the original table out of the dataset
        dsData.Tables.Remove(dsData.Tables(0))
        'add the new one
        dsData.Tables.Add(tblOutput)

        'LAR 11/23/2004 - added bad rows to the non-fatal output
        If bOrphans Or bBadRows Then
            'throw a non-fatal exception
            Dim sErrorText As String = "NON-FATAL ERROR: "
            If bOrphans Then
                sErrorText &= "Found orphaned events. All such rows were deleted from the feed. Here is a list of the raw data:" & vbCr & vbLf & sOrphanData & vbCr & vbLf
            End If
            If bBadRows Then
                sErrorText &= "Found rows with bad data. All such rows were deleted from the feed. Here is a list of the raw data:" & vbCr & vbLf & sBadRowsData & vbCr & vbLf
            End If
            Throw New System.Exception(sErrorText)
        End If

        Return True

    End Function

    'LAR 11/13/2003 - made this public so I can use it from clsUtilityFunctions
    Public Function RunSQL(ByVal sSQL As String, Optional ByVal sParamsInput As String = "", Optional ByRef dsData As DataSet = Nothing, Optional ByVal strDbaseSource As String = "") As Boolean
        'Take the passed sql and params, run them and populate the passed dataset
        Dim sParams() As String
        Dim strTemp As String
        Dim intIndex As Short

        'added code to set the UDL based upon a passed argument.  If argument is not passed, default to the wkab UDL.
        'If the passed argument is DRMS, use the DRMS UDL, otherwise, use the Wkab UDL.
        Dim strUDLName As String
        If strDbaseSource = "" Then
            strUDLName = "File Name=c:\WKABOLEDB.UDL;"
        ElseIf strDbaseSource = "DRMS" Then
            strUDLName = "File Name=c:\DRMSOLEDB.UDL;"
        ElseIf strDbaseSource.ToLower.EndsWith(".udl") Then
            strUDLName = "File Name=" & strDbaseSource
        Else
            strUDLName = "File Name=c:\WKABOLEDB.UDL;"
        End If

        Dim objCon As OleDbConnection = New OleDbConnection(strUDLName)
        Dim objCommand As OleDbCommand = New OleDbCommand("Lee", objCon)
        Dim daData As OleDbDataAdapter = New OleDbDataAdapter(objCommand)
        Dim iRowsAffected As Integer

        RunSQL = True
        daData.SelectCommand = objCommand
        Try
            objCon.Open()
        Catch objExAlreadyOpen As InvalidOperationException
            'connection is already open, use it
        Catch objException As Exception
            'can't make a connection, fail out
            LogError(objException, "RunSQL")
            RunSQL = False
            Exit Function
        End Try
        'if it is a stored proc, then we have to collect the params and process them as well
        If UCase(Left(sSQL, 2)) = "PK" Or UCase(Left(sSQL, 2)) = "SP" Then
            If sParamsInput <> "" Then
                sParams = Split(sParamsInput, ",")
                'loop thru all params in the file and construct the param list
                For intIndex = 0 To UBound(sParams)
                    strTemp = strTemp + IIf(Len(strTemp) = 0, "'" & Trim(sParams(intIndex)) & "'", ", '" & Trim(sParams(intIndex)) & "'")
                Next intIndex
            End If
            'build the oracle command string
            objCommand.CommandText = "{CALL " & sSQL & "(" & strTemp & ")}"
        Else
            'if it is just a simple sql statement, execute it directly
            objCommand.CommandText = sSQL
        End If

        'Execute statement
        'if we got a dataset, fill it
        If TypeName(dsData) <> "Nothing" Then
            Try
                daData.Fill(dsData)
            Catch objException As Exception
                LogError(objException, "RunSQL")
                RunSQL = False
                Exit Function
            End Try
        Else
            'otherwise, it must be just an insert or update, so just execute it
            Try
                Dim objTrans As OleDbTransaction
                ' Start a local transaction
                objTrans = objCon.BeginTransaction()
                ' Assign transaction object for a pending local transaction
                objCommand.Connection = objCon
                objCommand.Transaction = objTrans
                iRowsAffected = objCommand.ExecuteNonQuery()
                objTrans.Commit()
            Catch objException As Exception
                LogError(objException, "RunSQL")
                RunSQL = False
                Exit Function
            End Try
        End If

        objCommand = Nothing

        Try
            objCon.Close()
        Catch objException As Exception
            'don't worry, it'll go out of scope anyway
        End Try

    End Function

    Private Function IsFirstEventInEp(ByVal sI As String, ByVal sParentI As String, ByVal bNonCanc As Boolean) As Boolean
        'this fn determines if the event under consideration is the first
        'one in its episode; param says whether we need only non-cancelled ones

        Dim sSQL As String
        Dim dsData As New DataSet()
        IsFirstEventInEp = False

        'see if we need to filter on non-cancelled
        If bNonCanc Then
            sSQL = "select i from s_toccase where I_OCCASE_CHILDCASES = " & sParentI & " and datecreated = ("
            sSQL &= " SELECT min(s_toccase.datecreated) "
            sSQL &= " FROM s_toccase, s_tocprocessinstance, s_tocprocessstep, s_tocreasonforchange "
            sSQL &= " WHERE s_toccase.i_ocactvty_resultingacti = s_tocprocessinstance.i "
            sSQL &= " AND s_tocprocessinstance.i_ocprostp_currentstepof = s_tocprocessstep.i "
            sSQL &= " AND s_tocprocessinstance.i_ocreasch_currentreason = s_tocreasonforchange.i "
            sSQL &= " and guistepname != 'Cancelled' "
            sSQL &= " and s_toccase.I_OCCASE_CHILDCASES = " & sParentI & ")"
        Else
            sSQL = "select i from s_toccase where I_OCCASE_CHILDCASES = " & _
            sParentI & " and datecreated = (select min(datecreated) from s_toccase " & _
            "where I_OCCASE_CHILDCASES = " & sParentI & ")"
        End If

        RunSQL(sSQL, "", dsData)

        Try
            If dsData.Tables(0).Rows(0)("i") = sI Then
                IsFirstEventInEp = True
            Else
                IsFirstEventInEp = False
            End If
        Catch ex As System.Exception
            Throw New System.Exception("Could not establish first event for episode with i of " & sParentI & " " & ex.Message & " " & ex.InnerException.Message)
        End Try

    End Function

    Private Function IsLastNonCancEventExtInEp(ByVal sI As String, ByVal sParentI As String) As Boolean
        'this fn determines if the event/ext under consideration is the last
        'non-cancelled one in its episode
        'this is virtually identical to IsFirstNonCancEventInEp except it looks
        'for MAX and it includes processing for extensions
        Dim sSQL As String
        Dim dsData As New DataSet
        Dim sEpisodeI As String

        IsLastNonCancEventExtInEp = False

        If CaseType(sI) = "Extension" Then
            'get the episode by stepping up from the event
            sSQL = "select I_OCCASE_CHILDCASES from s_toccase where i = " & sParentI
            RunSQL(sSQL, "", dsData)
            Try
                sEpisodeI = dsData.Tables(0).Rows(0)("I_OCCASE_CHILDCASES")
            Catch ex As System.Exception
                'throw an exception 
                Throw New System.Exception("Could not walk up to episode for extension " & sI & " with I_OCCASE_CHILDCASES = " & sParentI & " " & ex.Message & " " & ex.InnerException.Message)
                Return False
            End Try
        Else        'event
            sEpisodeI = sParentI
        End If

        'now that we know we have the episode's i, we can figure out if we are at
        'the last non-canc event/ext in it
        sSQL = " select s_toccase.i, atd, guistepname, i_occastyp_cases "
        sSQL &= " from s_toccase, s_tocprocessinstance, s_tocprocessstep "
        sSQL &= " where s_toccase.i_ocactvty_resultingacti = s_tocprocessinstance.i "
        sSQL &= " AND s_tocprocessinstance.i_ocprostp_currentstepof = s_tocprocessstep.i "
        sSQL &= " and guistepname != 'Cancelled' "
        sSQL &= " and atd is not null "
        sSQL &= " and (I_OCCASE_CHILDCASES = " & sEpisodeI
        sSQL &= " or (I_OCCASE_CHILDCASES in (select i from s_toccase where I_OCCASE_CHILDCASES = " & sEpisodeI & "))) "
        sSQL &= " order by atd desc"
        RunSQL(sSQL, "", dsData)

        'this gives us the i and atd of all non-canc events & ext of this episode,
        'sorted with the latest atd first, so we want the i of the first row
        'if it is the same as the one we are looking at, then we've got the latest one
        Try
            Dim sTemp As String
            'don't know why I have to do this, but sometimes the 1st row (row 0)
            'has the first data in it, sometimes it's null and the 2nd row
            '(row 1) has the first row of data. Go figure
            If Not IsDBNull(dsData.Tables(0).Rows(0).Item("i")) Then
                sTemp = dsData.Tables(0).Rows(0).Item("i")
            Else
                sTemp = dsData.Tables(0).Rows(1).Item("i")
            End If
            If sTemp = sI Then
                IsLastNonCancEventExtInEp = True
            Else
                IsLastNonCancEventExtInEp = False
            End If
        Catch ex As System.Exception
            Throw New System.Exception("Could not establish latest event/extension for episode with i of " & sParentI & " " & ex.Message & " " & ex.InnerException.Message)
        End Try

    End Function


    Public Function BuildHistorySQL(ByVal sI As String) As String
        'this just contains some common sql building used by wasapprovedovernight
        'and waspendedovernight
        Dim sSQL As String

        sSQL = "SELECT s_toccase.i, s_tocprocessinstance.I, s_tocprocessstep.guistepname as status, "
        sSQL &= " s_tocreasonforchange.reason, s_tocprocessinstance.LASTUPDATEDATE "
        sSQL &= " FROM s_toccase, s_tocprocessinstance, "
        sSQL &= " s_tocprocessstep, s_tocreasonforchange "
        sSQL &= " WHERE s_toccase.i = " & sI & " "
        sSQL &= " AND s_toccase.i_ocactvty_resultingacti = s_tocprocessinstance.i "
        sSQL &= " AND s_tocprocessinstance.i_ocprostp_currentstepof = s_tocprocessstep.i "
        sSQL &= " AND s_tocprocessinstance.i_ocreasch_currentreason = s_tocreasonforchange.i "
        sSQL &= " union "
        sSQL &= " select s_toccase.i, s_tocprocessinstance.I, s_tocstagechange.STAGE as status,  "
        sSQL &= " s_tocstagechange.REASON, s_tocstagechange.LASTUPDATEDATE "
        sSQL &= " from s_tocstagechange, s_toccase, s_tocprocessinstance "
        sSQL &= " where s_tocstagechange.i_ocactvty_changes = s_tocprocessinstance.i "
        sSQL &= " and s_toccase.i = " & sI & " "
        sSQL &= " AND s_toccase.i_ocactvty_resultingacti = s_tocprocessinstance.i "
        sSQL &= " order by LASTUPDATEDATE"

        Return sSQL

    End Function
    Private Function WasPendedOvernight(ByVal sI As String) As Boolean
        'this function will determine if an event/extension was ever pended overnight
        'this is used to infer that an std/pnd record was sent on it.
        Dim dsData As New DataSet

        WasPendedOvernight = False

        Dim sSQL As String = BuildHistorySQL(sI)

        RunSQL(sSQL, "", dsData)

        Try
            Dim rowCurrent As DataRow
            Dim dtPriorDate As System.DateTime
            Dim sPriorStatus As String
            Dim dtCompare As System.DateTime

            For Each rowCurrent In dsData.Tables(0).Rows
                'if we're on the first row, save values and go on
                '(I can't find a better way to check if is uninitialized or not)
                If dtPriorDate = dtCompare Then
                    dtPriorDate = rowCurrent("lastupdatedate")
                    If Not IsDBNull(rowCurrent("status")) Then
                        If Not IsDBNull(rowCurrent("status")) Then
                            sPriorStatus = rowCurrent("status")
                        End If
                    End If
                Else
                    'if the prior row was pended, and the prior row is 
                    'more than a day old, then it was pended overnight
                    '(note, since the dataset is sorted, we know each one is LATER
                    'than the one prior, we just have to know if by >= 1 day)
                    If (sPriorStatus = "Pend") And (CDate(rowCurrent("lastupdatedate")).Date > dtPriorDate.Date) Then
                        Return True
                    Else
                        'if not, save off the values and go to the next row
                        dtPriorDate = rowCurrent("lastupdatedate")
                        If Not IsDBNull(rowCurrent("status")) Then
                            If Not IsDBNull(rowCurrent("status")) Then
                                sPriorStatus = rowCurrent("status")
                            End If
                        End If
                    End If
                End If
            Next
        Catch ex As System.Exception
            Throw New System.Exception("WasPendedOvernight: Could not establish whether event/extension with i of " & sI & " was pended overnight. " & ex.Message & " " & ex.InnerException.Message)
        End Try

    End Function


    Private Function WasApprovedOvernight(ByVal sI As String) As Boolean
        'this function will determine if an event/extension was ever appr overnight
        'this is used to infer that an std/std record was sent on it.
        Dim dsData As New DataSet

        WasApprovedOvernight = False

        Dim sSQL As String = BuildHistorySQL(sI)

        RunSQL(sSQL, "", dsData)

        Try
            Dim rowCurrent As DataRow
            Dim dtPriorDate As System.DateTime
            Dim sPriorStatus As String
            Dim dtCompare As System.DateTime

            For Each rowCurrent In dsData.Tables(0).Rows
                'if we're on the first row, save values and go on
                '(I can't find a better way to check if is uninitialized or not)
                If dtPriorDate = dtCompare Then
                    dtPriorDate = rowCurrent("lastupdatedate")
                    If Not IsDBNull(rowCurrent("status")) Then
                        sPriorStatus = rowCurrent("status")
                    End If
                Else
                    'if the prior row was pended, and the prior row is 
                    'more than a day old, then it was appr overnight
                    '(note, since the dataset is sorted, we know each one is LATER
                    'than the one prior, we just have to know if by >= 1 day)
                    If (sPriorStatus = "Approved") And (CDate(rowCurrent("lastupdatedate")).Date > dtPriorDate.Date) Then
                        Return True
                    Else
                        'if not, save off the values and go to the next row
                        dtPriorDate = rowCurrent("lastupdatedate")
                        If Not IsDBNull(rowCurrent("status")) Then
                            sPriorStatus = rowCurrent("status")
                        End If
                    End If
                End If
            Next
        Catch ex As System.Exception
            Throw New System.Exception("WasApprovedOvernight: Could not establish whether event/extension with i of " & sI & " was pended overnight. " & ex.Message & " " & ex.InnerException.Message)
        End Try

    End Function

    Private Function CaseType(ByVal sI As String) As String
        'this function will determine whether a given toccase record is an event or extension.
        'This fn uses the parent/child relationship to 
        'make the determination. Essentially, if my parent has a parent, I am an extension;
        'otherwise I am an event.
        Dim sSQL As String
        Dim dsData As New DataSet

        sSQL = "select I_OCCASE_CHILDCASES from s_toccase "
        sSQL &= "where i = (select I_OCCASE_CHILDCASES from s_toccase where i = " & sI & ")"

        RunSQL(sSQL, "", dsData)

        Try
            'if there is any return data, we're an ext
            If Not IsDBNull(dsData.Tables(0).Rows(0).Item("I_OCCASE_CHILDCASES")) Then
                CaseType = "Extension"
            Else
                CaseType = "Event"
            End If
        Catch ex As System.Exception
            'no data returned: assume we're an event
            CaseType = "Event"
        End Try

    End Function

    Public Function GetLTDClaimsFromDRMS(ByRef dsData As DataSet, ByVal sStartDate As String, ByVal sEndDate As String, ByVal sCaseID As String, ByVal sProductID As String, ByVal sDivisionTitle As String) As Boolean
        'This function is the main driver for getting the LTD claims from DRMS.
        'For each row returned from the DRMS stored procedure, it will execute one or more queries to get information from the STD
        'claim in Fineos and then append the row to the end of the dataset created by the main query. 

        Dim strParms As String
        Dim sEmpID As String
        Dim tblOutput As DataTable = New DataTable("Output")
        Dim dtEndDate As System.DateTime
        Dim bSkip As Boolean = False

        'create output table that mirrors the original dataset
        tblOutput.Columns.Add("I_OCCASTYP_CASES", Type.GetType("System.String"))
        tblOutput.Columns.Add("emp_id", Type.GetType("System.String"))
        tblOutput.Columns.Add("i", Type.GetType("System.String"))
        tblOutput.Columns.Add("last_update", Type.GetType("System.String"))
        tblOutput.Columns.Add("asd", Type.GetType("System.String"))
        tblOutput.Columns.Add("atd", Type.GetType("System.String"))
        tblOutput.Columns.Add("claimstatus", Type.GetType("System.String"))
        tblOutput.Columns.Add("actualrtw", Type.GetType("System.String"))
        tblOutput.Columns.Add("bertw", Type.GetType("System.String"))
        tblOutput.Columns.Add("workinjury", Type.GetType("System.String"))
        tblOutput.Columns.Add("leavetype", Type.GetType("System.String"))
        tblOutput.Columns.Add("dateabsence", Type.GetType("System.String"))
        tblOutput.Columns.Add("uniqueid", Type.GetType("System.String"))
        tblOutput.Columns.Add("casenumber", Type.GetType("System.String"))
        tblOutput.Columns.Add("Group_id", Type.GetType("System.String"))
        tblOutput.Columns.Add("PREGNANCY", Type.GetType("System.String"))
        tblOutput.Columns.Add("SCHEDSURGERY", Type.GetType("System.String"))
        tblOutput.Columns.Add("Union_5", Type.GetType("System.String"))
        tblOutput.Columns.Add("Supervisor_id", Type.GetType("System.String"))
        tblOutput.Columns.Add("OHN_ID", Type.GetType("System.String"))
        tblOutput.Columns.Add("I_OCCASE_CHILDCASES", Type.GetType("System.String"))
        tblOutput.Columns.Add("Reason", Type.GetType("System.String"))
        tblOutput.Columns.Add("flag", Type.GetType("System.String"))
        tblOutput.Columns.Add("LIABILITYENDDATE", Type.GetType("System.String"))

        'check for valid values
        If IsDate(sEndDate) Then
            dtEndDate = CDate(sEndDate)
        Else
            dtEndDate = System.DateTime.Now
        End If

        If IsDate(sStartDate) Then
        Else
            Throw New System.Exception("ERROR: Start Date not provided. Extract aborted.")
            Return False
        End If

        If (sCaseID = "0" _
        Or sCaseID = "") Then
            Throw New System.Exception("ERROR: CaseID not provided.  Can not extract LTD claims from DRMS.  Extract aborted.")
            Return False
        End If

        If sProductID = "" Then
            Throw New System.Exception("ERROR: ProductID not provided.  Can not extract LTD claims from DRMS.  Extract aborted.")
            Return False
        End If


        If sDivisionTitle = "" Then
            Throw New System.Exception("ERROR: Division Title not provided.  Can not extract LTD claims from DRMS.  Extract aborted.")
            Return False
        End If

        strParms = sStartDate & "," & sEndDate & "," & sCaseID & "," & sProductID & "," & sDivisionTitle

        Dim dsDataTemp As DataSet = New DataSet

        'pull all ltd claims for the reporting period
        If RunSQL("spFineosAvonLTDClaimsReverseFeed", strParms, dsDataTemp, "DRMS") Then

            Dim rowDRMSCurrent As DataRow
            'for each ltd claim found, process it and add it to the new dataset
            For Each rowDRMSCurrent In dsDataTemp.Tables(0).Rows

                Dim newRow As DataRow
                newRow = tblOutput.NewRow()
                bSkip = False

                strParms = rowDRMSCurrent.Item("episode_id")

                Dim dsDataTemp2 As DataSet = New DataSet

                If RunSQL("PK_feeds.sp_avon_ltd_claim", strParms, dsDataTemp2, "WKAB") Then
                    If dsDataTemp2.Tables(0).Rows.Count > 0 Then
                        newRow("emp_id") = dsDataTemp2.Tables(0).Rows(0).Item("emp_id")
                        newRow("Union_5") = dsDataTemp2.Tables(0).Rows(0).Item("union_5")
                        newRow("Supervisor_id") = dsDataTemp2.Tables(0).Rows(0).Item("supervisor_id")
                        newRow("uniqueid") = dsDataTemp2.Tables(0).Rows(0).Item("uniqueid")
                        newRow("Group_id") = dsDataTemp2.Tables(0).Rows(0).Item("group_id")
                        newRow("I_OCCASE_CHILDCASES") = dsDataTemp2.Tables(0).Rows(0).Item("I_OCCASE_CHILDCASES")
                        'LAR 09/09/2004 - added the event id to the proc
                        newRow("i") = dsDataTemp2.Tables(0).Rows(0).Item("event_id")
                    Else
                    End If
                Else
                End If

                newRow("I_OCCASTYP_CASES") = rowDRMSCurrent.Item("I_OCCASTYP_CASES")
                'LAR 09/09/2004 - this is wrong: the drms casenumber is the drms tblClaim.ClaimID and is not the fineos i value
                'I added it into the proc above
                'newRow("i") = rowDRMSCurrent.Item("casenumber")
                newRow("last_update") = rowDRMSCurrent.Item("last_update")
                newRow("asd") = rowDRMSCurrent.Item("asd")
                newRow("atd") = rowDRMSCurrent.Item("atd")
                newRow("actualrtw") = rowDRMSCurrent.Item("actualrtw")

                newRow("bertw") = rowDRMSCurrent.Item("bertw")
                newRow("workinjury") = rowDRMSCurrent.Item("workinjury")
                newRow("leavetype") = "550400001"
                If Not IsDBNull(rowDRMSCurrent.Item("dateabsence")) Then
                    newRow("dateabsence") = rowDRMSCurrent.Item("dateabsence")
                Else
                    If Not IsDBNull(rowDRMSCurrent.Item("disabilitydate")) Then
                        newRow("dateabsence") = rowDRMSCurrent.Item("disabilitydate")
                    Else
                        bSkip = True
                    End If
                End If
                newRow("flag") = rowDRMSCurrent.Item("flag")
                newRow("casenumber") = rowDRMSCurrent.Item("casenumber")
                newRow("PREGNANCY") = rowDRMSCurrent.Item("PREGNANCY")
                newRow("SCHEDSURGERY") = rowDRMSCurrent.Item("SCHEDSURGERY")
                newRow("OHN_ID") = rowDRMSCurrent.Item("OHN_ID")
                If Not IsDBNull(rowDRMSCurrent.Item("LIABILITYENDDATE")) Then
                    newRow("LIABILITYENDDATE") = rowDRMSCurrent.Item("LIABILITYENDDATE")
                Else
                    newRow("LIABILITYENDDATE") = rowDRMSCurrent.Item("atd")
                End If
                newRow("Reason") = rowDRMSCurrent.Item("claimreason")
                Select _
                   Case rowDRMSCurrent.Item("claimstatus")
                    Case "PENDING"
                        newRow("claimstatus") = "Pend"
                    Case "PENDING/WC"
                        newRow("claimstatus") = "Pend"
                    Case "APPROVED/WC PENDING"
                        newRow("claimstatus") = "Pend"
                    Case "PENDING PREGNANCY"
                        newRow("claimstatus") = "Pend"
                    Case "PENDING SURGICAL"
                        newRow("claimstatus") = "Pend"
                    Case "PENDING MEDICAL"
                        newRow("claimstatus") = "Pend"
                    Case "Pending MD to MD"
                        newRow("claimstatus") = "Pend"
                    Case "Pending Packet Info"
                        newRow("claimstatus") = "Pend"
                    Case "Pending No Response"
                        newRow("claimstatus") = "Pend"
                    Case "APPROVED"
                        newRow("claimstatus") = "Approved"
                    Case "CLOSED"
                        newRow("claimstatus") = "Closed"    'LAR 07/20/2004 generic case, including if reason is null
                        If Not IsDBNull(rowDRMSCurrent.Item("claimreason")) Then
                            Select Case rowDRMSCurrent.Item("claimreason")
                                Case "Ineligible"
                                    newRow("claimstatus") = "Denied"
                                Case "Denial by Employer"
                                    newRow("claimstatus") = "Denied"
                                Case "Not TD own occ"
                                    newRow("claimstatus") = "Denied"
                                Case "Not TD any occ"
                                    newRow("claimstatus") = "Denied"
                                Case "Pre-x"
                                    newRow("claimstatus") = "Denied"
                                Case "FML-Not TD own occ"
                                    newRow("claimstatus") = "Denied"
                                Case "Denied - Job Mods"
                                    newRow("claimstatus") = "Denied"
                                Case "Non-Compliance"
                                    newRow("claimstatus") = "Denied"
                                Case "Added in Error"
                                    newRow("claimstatus") = "Cancelled"
                                Case "Old Claim"
                                    newRow("claimstatus") = "Cancelled"
                                Case "Unresolved"
                                    newRow("claimstatus") = "Cancelled"
                                Case "No lost time"
                                    newRow("claimstatus") = "Cancelled"
                                Case "Claim withdrawn"
                                    newRow("claimstatus") = "Cancelled"
                                Case "Failure to provide proof"
                                    newRow("claimstatus") = "Cancelled"
                                Case "Max Duration"
                                    newRow("claimstatus") = "Closed"
                                Case "RTW"
                                    newRow("claimstatus") = "Closed"
                                Case Else
                                    newRow("claimstatus") = "Closed"
                            End Select
                        End If
                    Case Else
                        bSkip = True
                End Select

                If Not bSkip Then
                    tblOutput.Rows.Add(newRow)
                End If

            Next

            'LAR 01/23/2004 - moved this section down from the top of the function so that the ltd claims
            'will be sorted first in the new dataset. That way if there is an ltd pend/approve and std close
            'for the same claim in the dataset the ltd will be processed first and the std closure will be suppressed.
            Dim rowCurrent As DataRow
            'copy the rows from the original dataset into the new one.
            For Each rowCurrent In dsData.Tables(0).Rows

                Dim newRow As DataRow
                newRow = tblOutput.NewRow()

                newRow("I_OCCASTYP_CASES") = rowCurrent.Item("I_OCCASTYP_CASES")
                newRow("emp_id") = rowCurrent.Item("emp_id")
                newRow("i") = rowCurrent.Item("i")
                newRow("last_update") = rowCurrent.Item("last_update")
                newRow("asd") = rowCurrent.Item("asd")
                newRow("atd") = rowCurrent.Item("atd")
                newRow("claimstatus") = rowCurrent.Item("claimstatus")
                newRow("actualrtw") = rowCurrent.Item("actualrtw")
                newRow("Reason") = rowCurrent.Item("reason")
                newRow("bertw") = rowCurrent.Item("bertw")
                newRow("workinjury") = rowCurrent.Item("workinjury")
                newRow("leavetype") = rowCurrent.Item("leavetype")
                newRow("dateabsence") = rowCurrent.Item("dateabsence")
                newRow("flag") = rowCurrent.Item("flag")
                newRow("uniqueid") = rowCurrent.Item("uniqueid")
                newRow("casenumber") = rowCurrent.Item("casenumber")
                newRow("Group_id") = rowCurrent.Item("Group_id")
                newRow("PREGNANCY") = rowCurrent.Item("PREGNANCY")
                newRow("SCHEDSURGERY") = rowCurrent.Item("SCHEDSURGERY")
                newRow("Union_5") = rowCurrent.Item("Union_5")
                newRow("Supervisor_id") = rowCurrent.Item("Supervisor_id")
                newRow("OHN_ID") = rowCurrent.Item("OHN_ID")
                newRow("I_OCCASE_CHILDCASES") = rowCurrent.Item("I_OCCASE_CHILDCASES")
                newRow("LIABILITYENDDATE") = ""
                tblOutput.Rows.Add(newRow)

            Next

            'drop the original table out of the dataset
            dsData.Tables.Remove(dsData.Tables(0))
            'add the new one
            dsData.Tables.Add(tblOutput)
        Else
            'LAR 01/23/2004 - raise an error if the drms connection can't be made
            Throw New System.Exception("ERROR: DRMS Database connection or procedure call failed.  Can not extract LTD claims from DRMS.  Extract aborted.")
            Return False
        End If

        Return True

    End Function
    Private Function LogError(ByVal objException As Exception, ByVal sFunction As String)
        'get the exception text and write it to the log file
        'note that we don't have access to the extract engine's log file so we can't write the error out.
        'this function serves instead as a debugging tool so we can step into here and esily see the
        'exception messages...
        Dim sErrorMsg As String
        sErrorMsg = "Error in " & sFunction & ". "
        sErrorMsg &= objException.Message
        If TypeName(objException.InnerException) <> "Nothing" Then
            sErrorMsg &= " " & objException.InnerException.Message
        End If

    End Function
    Private Function WriteFile(ByRef strInput As String) As Object

        FileOpen(1, "C:\DataExtracts\ExtractDefinitionFiles\log\GoddamFuckingAvon.log", OpenMode.Append)
        PrintLine(1, strInput)
        FileClose(1)

    End Function


End Class
