Imports System.Data.OleDb

Public Class clsBoeingHRMSFeed

    Enum CLAIM_STATUS As Integer
        Open = 53001
        Closed = 53002
        Cancelled = 53003
    End Enum

    Enum CLAIM_SUB_STATUS As Integer
        PendingRelapse = 138011
        NoMissedTime = 138012
        AbsenceCancelled = 138013
        '4_04_05Transition=138014
        RTW = 138001
        ExhaustionOfLeave = 138002
        NoFurtherServicesRequired = 138003
        Cancelled = 138004
        TakeoverClaimClosed = 138005
        TransferToNewCarrier = 138006
        Deceased = 138007
        Resigned = 138008
        Denied = 138009
        CertificationExpired = 138010
        ReleasedNoRTW = 138015
    End Enum

    Enum ACTION
        NA = 0
        APPROVED = 1
        DENIED = 2
        PENDED = 3
        CANCELLED = 4
        CLOSED = 5
        ADMINISTRATIVE_CANCEL = 6
        Inactive = 7
    End Enum

    Dim m_dtStartDate As Date
    Dim m_bIsDiscretionaryLeave As Boolean
    Dim lSkipLeaveIDs(0) As Long
    Dim m_sUDL As String

    Public Function ProcessDataSet(ByRef dsData As DataSet, ByVal sStartDate As String, ByVal sUDL As String) As Boolean
        Dim drNew As DataRow
        Dim colColumn As DataColumn
        Dim bProcessRow, bSkip As Boolean
        Dim dtReqActionStartDate As Date
        Dim iRowIndex, iMaxIndex As Integer
        Dim bRemoveOccStatus As Boolean
        Dim iReportableStatus(0) As Integer

        m_dtStartDate = Date.Parse(sStartDate)
        Dim dtOutputTable As DataTable = dsData.Tables(0).Clone
        dtOutputTable.TableName = "OutPutTable"
        bProcessRow = True
        m_sUDL = sUDL

        Try
            If dsData.Tables(0).Rows.Count = 0 Then Return True 'no data, nothing to do

            dtReqActionStartDate = dsData.Tables(0).Rows(0)("start_date")
            iMaxIndex = dsData.Tables(0).Rows.Count - 1
            For iRowIndex = 0 To iMaxIndex

                m_bIsDiscretionaryLeave = IsDiscretionary(dsData.Tables(0).Rows(iRowIndex)("leave_type"))
                ReDim iReportableStatus(0)
                iReportableStatus(0) = 1
                If Not m_bIsDiscretionaryLeave Then
                    ReDim Preserve iReportableStatus(1)
                    iReportableStatus(1) = 3
                End If

                'if we're on the last row, process it, otherwise check values to decide
                If (iRowIndex <> iMaxIndex) Then
                    'if any of these values in the next row are different than this one, we'll process this one
                    If ((dsData.Tables(0).Rows(iRowIndex + 1)("action_id") = dsData.Tables(0).Rows(iRowIndex)("action_id")) And _
                     (dsData.Tables(0).Rows(iRowIndex + 1)("leave_id") = dsData.Tables(0).Rows(iRowIndex)("leave_id")) And _
                     (dsData.Tables(0).Rows(iRowIndex + 1)("leave_type") = dsData.Tables(0).Rows(iRowIndex)("leave_type"))) Then
                        bProcessRow = False
                        'save off start date and go to next row
                        If dtReqActionStartDate = Date.MinValue Then dtReqActionStartDate = dsData.Tables(0).Rows(iRowIndex)("start_date")
                    Else
                        'if we got here because the status (action_id) changed but it is still reportable then don't process
                        'If Array.IndexOf(iReportableStatus, dsData.Tables(0).Rows(iRowIndex + 1)("action_id")) <> -1 Then
                        If dsData.Tables(0).Rows(iRowIndex + 1)("leave_id") = dsData.Tables(0).Rows(iRowIndex)("leave_id") And _
                            dsData.Tables(0).Rows(iRowIndex + 1)("leave_type") = dsData.Tables(0).Rows(iRowIndex)("leave_type") And _
                            Array.IndexOf(iReportableStatus, Integer.Parse(dsData.Tables(0).Rows(iRowIndex + 1)("action_id"))) <> -1 Then
                            bProcessRow = False
                            'per reqs, null out the occ status in this case
                            bRemoveOccStatus = True
                            'save off start date and go to next row
                            If dtReqActionStartDate = Date.MinValue Then dtReqActionStartDate = dsData.Tables(0).Rows(iRowIndex)("start_date")
                        End If
                    End If
                End If

                'debug
                'If dsData.Tables(0).Rows(iRowIndex)("leave_id") <> 433302 Then bProcessRow = False

                If bProcessRow Then

                    'set values and process this row for inclusion
                    If dtReqActionStartDate <> Date.MinValue Then dsData.Tables(0).Rows(iRowIndex)("start_date") = dtReqActionStartDate

                    bSkip = CheckSkip(dsData.Tables(0).Rows(iRowIndex))

                    If Not bSkip Then

                        ValidateRowData(dsData.Tables(0).Rows(iRowIndex))

                        bSkip = CheckClosedCancelled(dsData.Tables(0).Rows(iRowIndex), dsData)

                        If Not bSkip Then bSkip = CheckNonReportable(dsData.Tables(0).Rows(iRowIndex))

                        If Not bSkip Then

                            '"after the fact rtw": Boeing can't accept an N row with rtw date so if they've opened a claim 
                            'with an rtw already in it, fabricate a 'New' row w/no rtw date
                            If dsData.Tables(0).Rows(iRowIndex)("record_status") = "N" And Not IsDBNull(dsData.Tables(0).Rows(iRowIndex)("confirmed_rtw")) Then
                                AddRow(dsData, dtOutputTable, iRowIndex, True)
                            End If

                            If bRemoveOccStatus Then dsData.Tables(0).Rows(iRowIndex)("action_id") = Convert.DBNull
                            AddRow(dsData, dtOutputTable, iRowIndex, False)
                        End If
                    End If
                    dtReqActionStartDate = Date.MinValue
                End If
                bSkip = False
                bProcessRow = True
                bRemoveOccStatus = False
            Next

            'use a dataview to filter the deletes and sort
            Dim dvData As DataView = dtOutputTable.DefaultView
            dvData.Sort = "WWID desc, leave_id asc, record_status desc"

            'drop the original table out of the dataset & add the new one
            dsData.Tables.Remove(dsData.Tables(0))
            dsData.Tables.Add(dtOutputTable)

        Catch ex As Exception
            Throw ex
            Return False
        End Try

    End Function

    Sub AddRow(ByRef dsData As DataSet, ByRef dtOutputTable As DataTable, ByVal iRowIndex As Integer, ByVal bATFRTW As Boolean)
        Dim drNew As DataRow
        Dim colColumn As DataColumn
        'add the row to the output table
        drNew = dtOutputTable.NewRow()
        dtOutputTable.Rows.Add(drNew)
        For Each colColumn In dsData.Tables(0).Columns
            drNew.Item(colColumn.ColumnName) = dsData.Tables(0).Rows(iRowIndex).Item(colColumn.ColumnName)
        Next

        'if we have an "after the fact rtw" set row as N w/no rtw date
        If bATFRTW Then
            drNew("confirmed_rtw") = Convert.DBNull 'new record keeps the 'N' & gets null conf rtw
            dsData.Tables(0).Rows(iRowIndex)("record_status") = "C" 'original keeps conf rtw & becomes a 'C'
        End If

    End Sub
    Function CheckClosedCancelled(ByRef row As DataRow, ByRef dsdata As DataSet) As Boolean
        Dim dsDataTemp As New DataSet
        Dim oAvon As New clsAvonClaimFeed

        'if the claim is closed or cancelled, output a single row for the whole thing
        If row("status_id") = CLAIM_STATUS.Cancelled Or row("status_id") = CLAIM_STATUS.Closed Then
            'LAR 09/19/2006 - don't output it if it's a cancelled EFC if there's an FML in the wings (they cancel all the 
            'req actions in adjudication so we'll get a bunch of them here, sometimes the EFC is first; if the
            'FML had come first we wouldn't be here as the skip flag would have been set then)
            If row("regulation_type_id") = 132 Then

                Dim dvDataView As New DataView(dsData.Tables(0))
                dvDataView.RowFilter = "leave_id = " & row("leave_id") & " and regulation_type_id = 135"
                If dvDataView.Count > 0 Then Return True

                'Dim sSQL As String = "select count(*) as count from a_request_action where action_id in (1, 2, 3) "
                'sSQL &= " and request_id = " & row("request_id") & " and regulation_type_id = 132 "
                'If oAvon.RunSQL(sSQL, "", dsDataTemp, m_sUDL) Then
                '    If dsDataTemp.Tables(0).Rows.Count > 0 Then
                '        If Not IsDBNull(dsDataTemp.Tables(0).Rows(0).Item("count")) Then
                '            If dsDataTemp.Tables(0).Rows(0).Item("count") = 0 Then
                '                'was never in reportable status so skip it; 
                '                'the FML one is prob the next row, let it pick that one up
                '                Return True
                '            End If
                '        End If
                '    End If
                'End If

            End If
            'skip any subsequent rows for this leave
            ReDim Preserve lSkipLeaveIDs(UBound(lSkipLeaveIDs) + 1)
            lSkipLeaveIDs(UBound(lSkipLeaveIDs)) = row("leave_id")
            'set occurance status and dates to the leave ones (Boeing will ignore anyway)
            If row("status_id") = CLAIM_STATUS.Cancelled Then
                row("action_id") = ACTION.CANCELLED
            Else
                row("action_id") = ACTION.CLOSED
            End If
            row("start_date") = row("FDA")
            row("end_date") = row("LDA")
        End If

    End Function

    Private Function CheckNonReportable(ByRef row As DataRow) As Boolean

        'if we have a chunk in reportable status (app for discr, app/pend for non-disc) and some non-reportable 
        'time then set the ertw to the first sched work day past the reportable period. 
        'only send the up to last reportable chunk before non-reportable; suppress all subsequent chunks
        'Process should prevent this situation ever happening, I am doing this just as a fall-back
        'This fn will return a flag telling the calling code whether to suppress this row
        Dim dsDataTemp As New DataSet
        Dim oAvon As New clsAvonClaimFeed
        Dim sReportableStatus As String = "1"
        If Not m_bIsDiscretionaryLeave Then sReportableStatus &= ",3"

        'are there any non-reportables in this leave?
        '06/27/2006 - don't consider cancels/inactive as non-reportable (as far as this is concerned they don't exist, we're
        'really looking for denied (or pend if discr)
        Dim sSQL As String = "select count(*) as count from s_request_action where request_id in (select request_id from s_request where leave_id = " _
            & row("leave_id") & ") and action_id not in (" & sReportableStatus & ", 4, 6, 7) and regulation_type_id = " _
                            & row("regulation_type_id")

        If oAvon.RunSQL(sSQL, "", dsDataTemp, m_sUDL) Then
            If dsDataTemp.Tables(0).Rows.Count > 0 Then
                If Not IsDBNull(dsDataTemp.Tables(0).Rows(0).Item("count")) Then
                    If dsDataTemp.Tables(0).Rows(0).Item("count") <> 0 Then
                        'is it before or after the one we're on?
                        If oAvon.RunSQL(sSQL & " and start_date > to_date('" & row("start_date") & "', 'mm/dd/yyyy HH:MI:SS AM')", "", dsDataTemp, m_sUDL) Then
                            If dsDataTemp.Tables(0).Rows.Count > 0 Then
                                If dsDataTemp.Tables(0).Rows(0).Item("count") <> 0 Then
                                    'it's after. Adjust the ertw date; new ertw should be the 1st sched work dt 
                                    'after the last reportable end date before the 1st 
                                    'non-reportable start date (say that three times fast)
                                    sSQL = "select max(end_date) as end_date from s_request_action where request_id in (select request_id from s_request " _
                                        & " where leave_id = " & row("leave_id") & ") and regulation_type_id = " & row("regulation_type_id") & " and start_date < " _
                                        & " (select min(start_date) from s_request_action where request_id in (select request_id from s_request  " _
                                        & " where leave_id = " & row("leave_id") & ") and action_id not in (1) and regulation_type_id = " & row("regulation_type_id") & ")"
                                    If oAvon.RunSQL(sSQL, "", dsDataTemp, m_sUDL) Then
                                        If dsDataTemp.Tables(0).Rows.Count > 0 Then
                                            If Not IsDBNull(dsDataTemp.Tables(0).Rows(0).Item("end_date")) Then
                                                row("expected_rtw") = GetNextSchedWorkDate(dsDataTemp.Tables(0).Rows(0).Item("end_date"), row("employee_id"))
                                            End If
                                        End If
                                    End If
                                    Return False
                                Else
                                    'is it before?
                                    If oAvon.RunSQL(sSQL & " and start_date < to_date('" & row("start_date") & "', 'mm/dd/yyyy HH:MI:SS AM')", "", dsDataTemp, m_sUDL) Then
                                        If dsDataTemp.Tables(0).Rows.Count > 0 Then
                                            If dsDataTemp.Tables(0).Rows(0).Item("count") <> 0 Then
                                                'it's before; supress the current one (unless we're on EFC, then it's ok
                                                'to have inactive before it
                                                If row("regulation_type_id") = 132 Then
                                                    Return False
                                                Else
                                                    Return True
                                                End If
                                            Else
                                                'if it ain't before or after it must be equal, which means we fouind the one we're on, so let it go
                                                Return False
                                            End If
                                        End If
                                    End If
                                End If
                            End If
                        End If
                    End If
                End If
            End If
        End If

        Return False

    End Function

    Function GetNextSchedWorkDate(ByVal dtStartDate As Date, ByVal sEmployeeID As String) As Date
        Dim dsDataTemp As New DataSet
        Dim oUtility As New clsUtilityFunctions
        Dim dtDate As Date = dtStartDate
        Dim iNumHours As Integer = 0
        Dim iCount As Integer

        Do
            dtDate = dtDate.AddDays(1)
            iCount += 1
            iNumHours = oUtility.GetScheduledWorkHours(Long.Parse(sEmployeeID), Format(dtDate, "MM/dd/yyyy 00:00:01"), Format(dtDate, "MM/dd/yyyy 11:59:59"))
        Loop While iNumHours = 0 And iCount < 100

        Return dtDate

    End Function

    Function DetermineType(ByVal rowCurrent As DataRow) As String
        'derive whether the row is new or changed.
        Dim dsDataTemp As New DataSet
        Dim oAvon As New clsAvonClaimFeed
        '**Try to trap Ns masquerading as Cs: rows that are 'new to the feed' but look like changes because
        'they were created and changed since last file run, etc
        'if discretionary and it became approved since m_dtStartDate then new (providing was never approved before)
        'non-discretionary it's appr or pend
        'thank Gord for audit tables. Although a_request_action is so gorddammed HUGE it'll slow this pig down to a crawl

        'looking for any req actions for this leave that were in reportable status before this run of the file. If we 
        'find any, then we probably sent info on this leave before, so it is a change.
        Dim sSQL As String = "select count(*) as count, min (create_date) as min_date from a_request_action where action_id in (1"
        If Not m_bIsDiscretionaryLeave Then sSQL &= ",3"
        sSQL &= " ) and request_id in (select request_id from s_request where leave_id = " & rowCurrent("leave_id") & ")"

        If oAvon.RunSQL(sSQL, "", dsDataTemp, m_sUDL) Then
            If dsDataTemp.Tables(0).Rows.Count > 0 Then
                If Not IsDBNull(dsDataTemp.Tables(0).Rows(0).Item("count")) Then
                    If Not IsDBNull(dsDataTemp.Tables(0).Rows(0).Item("min_date")) Then
                        If dsDataTemp.Tables(0).Rows(0).Item("count") <> 0 Then
                            If dsDataTemp.Tables(0).Rows(0).Item("min_date") > m_dtStartDate Then
                                'check and double-check; if we're on an EFC that's been determined N because it's
                                'Discretionary, look for a corresponding FML non-disc that might have already been sent
                                '(if a fml went pend -> cancelled, it still went over, then they activate and approve
                                'efc for the period, this fn would identify the efc as New when it should be Change)
                                If (rowCurrent("leave_type") = "EFC") And m_bIsDiscretionaryLeave Then

                                    dsDataTemp = New DataSet
                                    sSQL = "select count(*) as count, min (create_date) as min_date from a_request_action where action_id in (1"
                                    sSQL &= ",3 ) and regulation_type_id = 135 "
                                    sSQL &= " and request_id in (select request_id from s_request where leave_id = " & rowCurrent("leave_id") & ")"
                                    If oAvon.RunSQL(sSQL, "", dsDataTemp, m_sUDL) Then
                                        If dsDataTemp.Tables(0).Rows.Count > 0 Then
                                            If Not IsDBNull(dsDataTemp.Tables(0).Rows(0).Item("count")) Then
                                                If Not IsDBNull(dsDataTemp.Tables(0).Rows(0).Item("min_date")) Then
                                                    If dsDataTemp.Tables(0).Rows(0).Item("count") <> 0 Then
                                                        If dsDataTemp.Tables(0).Rows(0).Item("min_date") > m_dtStartDate Then
                                                            Return "N"
                                                        Else
                                                            Return "C"
                                                        End If
                                                    End If
                                                End If
                                            End If
                                        End If
                                    End If
                                Else
                                    Return "N"
                                End If
                            Else
                                Return "C"
                            End If
                        Else
                            Return "N"
                        End If
                    Else
                        Return "N"
                    End If
                End If
            End If
        End If

        'placeholder for now...
        Return rowCurrent("record_status")
        oAvon = Nothing

    End Function

    Private Function CheckSkip(ByRef rowCurrent As DataRow) As Boolean
        'certain things in the row will make us not output it

        'definitely skip any in the skip list
        'If Not lSkipLeaveIDs Is Nothing Then
        If Array.IndexOf(lSkipLeaveIDs, Long.Parse(rowCurrent("leave_id"))) > 0 Then Return True
        'End If

        'skip claim cancels and req action admin cancels if they're created in this run, cos Boeing never got the original
        'If (rowCurrent("action_id") = ACTION.ADMINISTRATIVE_CANCEL Or rowCurrent("status_id") = CLAIM_STATUS.Cancelled) And _
        '    rowCurrent("create_date") > m_dtStartDate Then Return True

        'SKIP CANCELS THAT WERE CREATED BEFORE THE RUN BUT WERE NEVER IN REPORTABLE STATUS
        'If (rowCurrent("action_id") = ACTION.ADMINISTRATIVE_CANCEL Or rowCurrent("status_id") = CLAIM_STATUS.Cancelled) Then
        'just look at cancelled claims here, not req actions, they'll get filtered down below
        If (rowCurrent("status_id") = CLAIM_STATUS.Cancelled) Then
            If rowCurrent("create_date") > m_dtStartDate Then
                'skip if they're created in this run, cos Boeing never got the original
                Return True
            Else
                'if they were created before this run, skip them if they never made it into reportable status
                Dim dsDataTemp As New DataSet
                Dim oAvon As New clsAvonClaimFeed

                Dim sSQL As String = "select count(*) as count from a_request_action where action_id in (1"
                If Not m_bIsDiscretionaryLeave Then sSQL &= ",3"
                sSQL &= ") and request_id = " & rowCurrent("request_id")
                '06/29/2006 - removed the date criteria as it filters things it oughtn't to...
                'sSQL &= " and start_date = to_date('" & rowCurrent("start_date") & "', 'mm/dd/yyyy HH:MI:SS AM')"
                'sSQL &= " and end_date = to_date('" & rowCurrent("end_date") & "', 'mm/dd/yyyy HH:MI:SS AM')"
                sSQL &= " and regulation_type_id = " & rowCurrent("regulation_type_id")

                If oAvon.RunSQL(sSQL, "", dsDataTemp, m_sUDL) Then
                    If dsDataTemp.Tables(0).Rows.Count > 0 Then
                        If Not IsDBNull(dsDataTemp.Tables(0).Rows(0).Item("count")) Then
                            If dsDataTemp.Tables(0).Rows(0).Item("count") = 0 Then
                                'was never in reportable status so skip it
                                Return True
                            End If
                        End If
                    End If
                End If
                oAvon = Nothing
            End If
        End If

        'always output leave closure
        '06/28/2006 - if the cancelled leave made it thru the trap above then definitely don't filter it, let the 
        'ClosedCancelled function deal with it.
        If rowCurrent("status_id") = CLAIM_STATUS.Closed Or rowCurrent("status_id") = CLAIM_STATUS.Cancelled Then Return False

        'skip anything other than cls/canc if it hasn't been triaged
        If rowCurrent("triaged") = 0 Then Return True

        'only output appr if discretionary, pend & appr if non-disc
        'Added canc/admin canc here, because if they got thru the cancel trap above then they need to go in the file
        '06/25/2006 - took it out again because I can't remember why I did this and it screws something else up.
        If m_bIsDiscretionaryLeave Then
            If (rowCurrent("action_id") <> ACTION.APPROVED) Then
                Return True
            End If
        Else
            If (rowCurrent("action_id") <> ACTION.APPROVED And rowCurrent("action_id") <> ACTION.PENDED) Then
                Return True
            End If
        End If

    End Function

    Private Sub ValidateRowData(ByRef rowCurrent As DataRow)
        'some data validation/cleanup...

        'if they said no to wp pay then zero out the fields 
        If IsDBNull(rowCurrent("WPPay_Salary")) Then rowCurrent("WPPay_Salary") = "N"

        If rowCurrent("WPPay_Salary") = "Y" Then
            If Not IsDBNull(rowCurrent("WP_SL_Amount_Salary")) Then
                If CType(rowCurrent("WP_SL_Amount_Salary"), String).ToLower <> "all" Then
                    If Not IsNumeric(rowCurrent("WP_SL_Amount_Salary")) Then rowCurrent("WP_SL_Amount_Salary") = 0
                End If
            End If
        Else
            rowCurrent("WP_SL_Priority_Salary") = 0
            rowCurrent("WP_SL_Amount_Salary") = 0
            rowCurrent("WP_V_Priority_Salary") = 0
            rowCurrent("WP_V_Amount_Salary") = 0
            rowCurrent("WP_FSP_Priority_Salary") = 0
            rowCurrent("WP_FSP_Amount_Salary") = 0
        End If

        'if they said no to suppl pay then zero out the fields 
        'LAR 06/25/2007 9794 - this question was removed from the script so it's ALWAYS null so the 
        'other fields ALWAYS get blanked out. Look at the individual fields instead and blank them if null
        'If IsDBNull(rowCurrent("Suppl_LMTD_Pay_Salary")) Then rowCurrent("Suppl_LMTD_Pay_Salary") = "N"
        'If rowCurrent("Suppl_LMTD_Pay_Salary") = "N" Then
        If IsDBNull(rowCurrent("LMTD_Pay_From")) Then rowCurrent("LMTD_Pay_From") = ""
        If IsDBNull(rowCurrent("LMTD_Pay_To")) Then rowCurrent("LMTD_Pay_To") = ""
        If IsDBNull(rowCurrent("LMTD_SL_Priority_Salary")) Then rowCurrent("LMTD_SL_Priority_Salary") = 0
        If IsDBNull(rowCurrent("LMTD_SL_Amount_Salary")) Then rowCurrent("LMTD_SL_Amount_Salary") = 0
        If IsDBNull(rowCurrent("LMTD_V_Priority_Salary")) Then rowCurrent("LMTD_V_Priority_Salary") = 0
        If IsDBNull(rowCurrent("LMTD_V_Amount_Salary")) Then rowCurrent("LMTD_V_Amount_Salary") = 0
        If IsDBNull(rowCurrent("LMTD_FSP_Priority_Salary")) Then rowCurrent("LMTD_FSP_Priority_Salary") = 0
        If IsDBNull(rowCurrent("LMTD_FSP_Amount_Salary")) Then rowCurrent("LMTD_FSP_Amount_Salary") = 0
        'End If

        'if they said no to suppl pay then zero out the fields 
        If IsDBNull(rowCurrent("WPPay_Hourly")) Then rowCurrent("WPPay_Hourly") = "N"
        If rowCurrent("WPPay_Hourly") = "N" Then
            rowCurrent("WP_SL_Priority_Hourly") = 0
            rowCurrent("WP_SL_Amount_Hourly") = 0
            rowCurrent("WP_V_Priority_Hourly") = 0
            rowCurrent("WP_V_Amount_Hourly") = 0
            rowCurrent("WP_FSP_Priority_Hourly") = 0
            rowCurrent("WP_FSP_Amount_Hourly") = 0
        End If

        If rowCurrent("PerEduPre_V") = "N" Then
            rowCurrent("PerEduPre_V_Amount") = 0
        End If

        rowCurrent("WP_SL_Amount_Salary") = ConvertAmounts(rowCurrent("WP_SL_Amount_Salary"))
        rowCurrent("WP_V_Amount_Salary") = ConvertAmounts(rowCurrent("WP_V_Amount_Salary"))
        rowCurrent("WP_FSP_Amount_Salary") = ConvertAmounts(rowCurrent("WP_FSP_Amount_Salary"))
        rowCurrent("LMTD_SL_Amount_Salary") = ConvertAmounts(rowCurrent("LMTD_SL_Amount_Salary"))
        rowCurrent("LMTD_V_Amount_Salary") = ConvertAmounts(rowCurrent("LMTD_V_Amount_Salary"))
        rowCurrent("LMTD_FSP_Amount_Salary") = ConvertAmounts(rowCurrent("LMTD_FSP_Amount_Salary"))
        rowCurrent("WP_SL_Amount_Hourly") = ConvertAmounts(rowCurrent("WP_SL_Amount_Hourly"))
        rowCurrent("WP_V_Amount_Hourly") = ConvertAmounts(rowCurrent("WP_V_Amount_Hourly"))
        rowCurrent("WP_FSP_Amount_Hourly") = ConvertAmounts(rowCurrent("WP_FSP_Amount_Hourly"))
        rowCurrent("PerEduPre_V_Amount") = ConvertAmounts(rowCurrent("PerEduPre_V_Amount"))
        rowCurrent("Suppl_SL_Amount_Salary") = ConvertAmounts(rowCurrent("Suppl_SL_Amount_Salary"))
        rowCurrent("Suppl_V_Amount_Salary") = ConvertAmounts(rowCurrent("Suppl_V_Amount_Salary"))
        rowCurrent("Suppl_FSP_Amount_Salary") = ConvertAmounts(rowCurrent("Suppl_FSP_Amount_Salary"))
        rowCurrent("Suppl_SL_Amount_Hourly") = ConvertAmounts(rowCurrent("Suppl_SL_Amount_Hourly"))
        rowCurrent("Suppl_V_Amount_Hourly") = ConvertAmounts(rowCurrent("Suppl_V_Amount_Hourly"))
        rowCurrent("Suppl_FSP_Amount_Hourly") = ConvertAmounts(rowCurrent("Suppl_FSP_Amount_Hourly"))
        rowCurrent("NEOINP_SL_Amount") = ConvertAmounts(rowCurrent("NEOINP_SL_Amount"))
        rowCurrent("NEOINP_V_Amount") = ConvertAmounts(rowCurrent("NEOINP_V_Amount"))
        rowCurrent("NEOINP_FSP_Amount") = ConvertAmounts(rowCurrent("NEOINP_FSP_Amount"))

        'RTW...For Pre-Retirement or Pilot's Early Leaves, use the estimated_retirement_date.
        'For all others, derive it based on a hierarchy of the various rtw dates they could have chosen from
        'LAR 06/27/2007 9118 - activity on the Pre-Retirement and Pilot's Early Leaves now 
        'automatically updates the various rtw dates so we don't have to override it anymore
        Dim dtExpectedRTW As Date = System.DateTime.MinValue
        'If rowCurrent("regulation_type_id") = 130 Or rowCurrent("regulation_type_id") = 124 Then
        '    dtExpectedRTW = rowCurrent("estimated_retirement_date")
        'Else
            'use rtw dates in this order: actual, expected, estimated, then fda + 30 if all 3 are null 
            If Not IsDBNull(rowCurrent("actual_rtw")) Then
                dtExpectedRTW = rowCurrent("actual_rtw")
            Else
                If Not IsDBNull(rowCurrent("expected_rtw")) Then
                    dtExpectedRTW = rowCurrent("expected_rtw")
                Else
                    If Not IsDBNull(rowCurrent("estimated_rtw")) Then
                        dtExpectedRTW = rowCurrent("estimated_rtw")
                    Else
                        If Not IsDBNull(rowCurrent("FDA")) Then
                            dtExpectedRTW = Date.Parse(rowCurrent("FDA")).AddDays(30)
                        Else
                            dtExpectedRTW = Date.Now.AddDays(30)
                        End If
                    End If
                End If
            End If
        'End If
        'last chance default
        If dtExpectedRTW = System.DateTime.MinValue Then dtExpectedRTW = Date.Parse(rowCurrent("FDA")).AddDays(30)

        rowCurrent("expected_rtw") = dtExpectedRTW

        'if record status isn't obviously new, derive it based on status and dates
        Dim dtTriaged As Date = Date.Now
        If Not IsDBNull(rowCurrent("triage_date")) Then dtTriaged = rowCurrent("triage_date")
        If rowCurrent("create_date") > m_dtStartDate Or dtTriaged > m_dtStartDate Then
            rowCurrent("record_status") = "N"
        Else
            rowCurrent("record_status") = DetermineType(rowCurrent)
        End If

        'a changed record that is new this run should be N 
        If rowCurrent("record_status") = "C" And rowCurrent("CREATE_DATE") > m_dtStartDate Then
            rowCurrent("record_status") = "N"
        End If

        'null out rtw date if clsd/released no rtw
        If Not IsDBNull(rowCurrent("SUB_STATUS_ID")) Then
            If rowCurrent("STATUS_ID") = CLAIM_STATUS.Closed And _
                rowCurrent("SUB_STATUS_ID") = CLAIM_SUB_STATUS.ReleasedNoRTW Then rowCurrent("confirmed_rtw") = Convert.DBNull
        End If

        Dim dsDataTemp As New DataSet
        Dim oAvon As New clsAvonClaimFeed
        Dim sSQL As String
        '6/30/2006 - null out the conf rtw date if we're in a fml/efc conversion situation and we're not on the last record.
        'first the fml
        If rowCurrent("leave_type") = "FML" Then
            'look for an approved efc on this leave with start date later than mine
            sSQL = "select min(start_date) as start_date from s_request_action ra, s_request r where ra.request_id = r.request_id"
            sSQL &= " and r.leave_id = " & rowCurrent("leave_id") & " and ra.regulation_type_id = 132 and action_id in (1,3)"
            If oAvon.RunSQL(sSQL, "", dsDataTemp, m_sUDL) Then
                If dsDataTemp.Tables(0).Rows.Count > 0 Then
                    If Not IsDBNull(dsDataTemp.Tables(0).Rows(0)("start_date")) Then
                        If dsDataTemp.Tables(0).Rows(0)("start_date") > rowCurrent("start_date") Then
                            rowCurrent("confirmed_rtw") = System.DBNull.Value
                        End If
                    End If
                End If
            End If
        End If

        'now efc
        dsDataTemp = New DataSet
        If rowCurrent("leave_type") = "EFC" Then
            'look for an approved fml on this leave with start date later than mine
            sSQL = "select min(start_date) as start_date from s_request_action ra, s_request r where ra.request_id = r.request_id"
            sSQL &= " and r.leave_id = " & rowCurrent("leave_id") & " and ra.regulation_type_id = 135 and action_id in (1,3)"
            If oAvon.RunSQL(sSQL, "", dsDataTemp, m_sUDL) Then
                If dsDataTemp.Tables(0).Rows.Count > 0 Then
                    If Not IsDBNull(dsDataTemp.Tables(0).Rows(0)("start_date")) Then
                        If dsDataTemp.Tables(0).Rows(0)("start_date") > rowCurrent("start_date") Then
                            rowCurrent("confirmed_rtw") = System.DBNull.Value
                        End If
                    End If
                End If
            End If
        End If

        '06/28/2006 - bulk up the occurence dates to be the full range of reportable dates
        'this might be necessary if we've only got one request in hand because that's all that changed since the last file, 
        'we don't want to just report those dates, we want the whole range

        sSQL = "select min(start_date) as start_date, max(end_date) as end_date from s_request_action ra, s_request r where ra.request_id = r.request_id and leave_id ="
        sSQL &= rowCurrent("leave_id") & " and action_id in (1"
        If Not m_bIsDiscretionaryLeave Then sSQL &= ",3"
        sSQL &= ") and regulation_type_id = " & rowCurrent("regulation_type_id")

        dsDataTemp = New DataSet

        If oAvon.RunSQL(sSQL, "", dsDataTemp, m_sUDL) Then
            If dsDataTemp.Tables(0).Rows.Count > 0 Then
                rowCurrent("start_date") = dsDataTemp.Tables(0).Rows(0)("start_date")
                rowCurrent("end_date") = dsDataTemp.Tables(0).Rows(0)("end_date")
            End If
        End If
        oAvon = Nothing

    End Sub

    Private Function ConvertAmounts(ByVal oInput As Object) As Object
        'convert amount fields input in script if they aren't appropriate values

        If IsDBNull(oInput) Then Return "0"

        If Not IsNumeric(oInput) Then
            If CType(oInput, String).ToLower = "all" Then
                Return "9999.99"
            Else
                Return "0"
            End If
        End If

        Return oInput

    End Function
    Private Function IsDiscretionary(ByVal sRegulation As String) As Boolean
        'determine if the regulation is a Boeing discretionary or non-discretionary leave
        'There are 2 EFCs, 166 (DPL) and 133 (straight EFC). As of now both are non-disc
        'but this will probably change with some other requirements being worked on.
        Select Case sRegulation
            Case "PER", "PRE", "EDU", "PEL", "UNB REL", "UNB NRL"
                Return True
            Case "MIL", "JUR", "FML", "NOD", "OCC", "PRG", "EFC"
                Return False
                'Case "EFC"
                '    'approved/Employer Accepted, denied/Employer Denied and pended/Awaiting Employer Determination
                '    'are discretionary, everything else is non.
                '    If (iActionID = 1 And iActionReasonID = 94) Or (iActionID = 2 And iActionReasonID = 95) _
                '        Or (iActionID = 3 And iActionReasonID = 90) Then
                '        Return True
                '    Else
                '        Return False
                '    End If
        End Select
    End Function

    Public Function WriteLog(ByRef strInput As String)

        FileOpen(1, "C:\DataExtracts\ExtractDefinitionFiles\log\boeing_hrms.log", OpenMode.Append)
        PrintLine(1, CStr(Now) & " - " & strInput)
        FileClose(1)

    End Function

End Class
