
Imports System.Data.OleDb

Public Enum WKABProductType
    LOA = 6001
    STD = 6002
    LTD = 6003
    PFL = 6005
End Enum

Public Enum ClaimStatusList
    NULL                'This indicates the previous state is unknown
    STD_STOSTO
    LOA_STU          'ITL Radar 20598 Dt: 10/20/2014
    STD_STDSTD
    STD_PLAPTD
    STD_POSPTD          'ITL Radar 20598 Dt: 10/20/2014
    STD_RFLSTO
    STD_RFLSTU          'ITL Radar 20598 Dt: 10/20/2014
    STD_RFLSTD
    STD_RFLRPD
    STD_POSRPD          'ITL Radar 20598 Dt: 10/27/2014
    STD_RFL             'The person has returned from work. Need to determine his previous Not At Work status
    'Changes for 12466 Start
    STD_LOAMOD
    STD_RFLRND
    'Changes for 12466 End
    FML_LOAFML
    FML_PLAFLI
    FML_POSFLI          'ITL Radar 20598 Dt: 10/20/2014
    FML_RFLFML
    FML_RFLFLI
    FML_RFL
    'Changes as per Epic 828496 - NY PFL Claims Addition - Start
    PFL_LOAPFL
    PFL_PFLPFL
    PFL_RFLPFU
    PFL_RFLPFL
    'Changes as per Epic 828496 - NY PFL Claims Addition - End
End Enum


'RTW_Status	RTW_Reason	Work_Status	Work_Status_Desc
Public Enum RTWStatus
    Approved
    Pend
    Denied
    Terminated
    Cancelled
    Suspended
End Enum

Public Enum RTWReason
    Administrative = 43001
    ClaimWithdrawn = 43002
    ClientRequest = 43003
    Death = 43004
    DisNotSupported = 43005
    DisabilitySupported = 43006
    Employee = 43007
    Employer = 43008
    Maintenance = 43009
    MaxBenefits = 43010
    Medical = 43011
    NewClaim = 43012
    NoLongerEmployByComp = 43013
    NoMedsReceived = 43014
    Noncompliance = 43015
    NotEligible = 43016
    PreExistingCondition = 43017
    Relapse = 43018
    Retired = 43019
    ReturnToWork = 43020
    Settlement = 43021
    StableAndMature = 43022
    Reinstated = 43023
    Certification = 43024
    Certified = 43025
    Bonding = 43026
    NoRequirements = 43027
    NoCert = 43028
    Takeover = 43035
    MedicalMngt = 43036
    Conversion = 43037
End Enum

Public Enum WorkStatus
    ATWORK = 38001
    NOTATWORK = 38002
    RELEASEDTORTW = 38003
End Enum

Public Enum ClaimStatus
    Pend = 32001
    Open = 32002
    Closed = 32003
    Cancelled = 32004
End Enum


Public Enum WorkStatusDesc
    FULLDUTY
    PARTIALDUTY
    'Changes for 12466 Start
    MODJOBABILITY
    'Changes for 12466 End
    NULL
End Enum


Public Class clsFedExGroundFeed

    'This is the new data feed table
    Private goTable As DataTable
    ' Private goFMLTable As DataTable
    Private gsPackageName As String
    Private gsSequenceNumber As String
    Private gsRunType As String
    Private gsIsParallel As String 'ITL Radar 20598 Dt: 10/21/2014

    'This class contains functions that can be called from the DataExtract
    'engine to do custom work on the FedEx Ground extract data. They are called by 
    'placing a reference to them in the SubQueries section of the extract
    'definition xml file like so:
    '<SubQueries>
    '   <FedEXFeed assembly="DataExtractClasses" object="DataExtractClasses.clsFedExGroundFeed" function="GenerateFedEXFeed" Param="m_dsData" />
    '</SubQueries>    

    Public Function GenerateFedEXFeed(ByRef dsData As DataSet, ByVal dtRundate As String, ByVal dtLastRunDate As String, ByVal sUDL As String, ByVal sPackageName As String, ByVal sSequenceNumber As String, ByVal sRunType As String, Optional ByVal sIsParallel As String = "FALSE")

        Dim oTable As DataTable
        Dim oRow As DataRow
        Dim lPreviousClaimID As Long
        Dim lCurrentClaimID As Long

        Try

            'Store the package name and RunType locally
            gsPackageName = sPackageName
            gsRunType = sRunType       ' 1 is a normal scheduled run  -  else sql looks for additional activity - see Proc
            gsIsParallel = sIsParallel 'ITL Radar 20598 Dt: 10/21/2014

            'Store the Sequence Number
            If IsNumeric(sSequenceNumber) = True Then
                gsSequenceNumber = sSequenceNumber
            End If

            'Create the new datafeed table
            CreateDataFeedTable()

            ' ITL Radar 20598 Check for Parallel Start 

            ' ITL Radar 20598 Check for Parallel End 

            'Make sure there is data in the dataset object
            If Not (dsData Is Nothing) Then
                If dsData.Tables.Count > 0 Then

                    'Set variables
                    oTable = dsData.Tables(0)
                    lPreviousClaimID = -9999999  'Initiate to a negative null value

                    'Loop through the dataset for processing
                    For Each oRow In oTable.Rows

                        'Has the FDA + 7 condition been met? 
                        '** This is done in the stored procedure now **
                        'If FDA7ConditionMet(oRow, dtRundate) = True Then

                        If isSTDRecord(oRow) Then 'Is this an STD Record?
                            lCurrentClaimID = CType(oRow("Claim_ID"), Long)

                            'Process an STD Record  but process each claim only once
                            If lCurrentClaimID <> lPreviousClaimID Then

                                ProcessSTDRecord(oRow, lCurrentClaimID, dtRundate, dtLastRunDate, sUDL)

                                lPreviousClaimID = lCurrentClaimID   'Update the Previous Claim ID

                            End If
                        End If
                    Next
                End If
            End If

            'Process the PFL Records
            ProcessPFLClaims(dtRundate, dtLastRunDate, sUDL)

            'Process the FML Records
            ProcessFMLClaims(dtRundate, dtLastRunDate, sUDL)

            'drop the original table out of the dataset
            dsData.Tables.Remove(dsData.Tables(0))
            'add the new one
            dsData.Tables.Add(goTable)

        Catch ex As Exception
        End Try
    End Function


    'Changes as per Epic 828496 - NY PFL Claims Addition - Start
    'Is this a PFL Record?
    Public Function isPFLRecord(ByRef oRow As DataRow) As Boolean
        Dim bValid As Boolean = False

        Try

            'Is this an PFL claim 
            If oRow("Product_ID") = WKABProductType.PFL Then
                bValid = True
            End If
        Catch ex As Exception
        End Try

        Return bValid
    End Function
    'Changes as per Epic 828496 - NY PFL Claims Addition - End

    'Is this an STD Record?
    Public Function isSTDRecord(ByRef oRow As DataRow) As Boolean
        Dim bValid As Boolean = False

        Try

            'Is this an STD claim 
            If oRow("Product_ID") = WKABProductType.STD Then
                bValid = True
            End If
        Catch ex As Exception
        End Try

        Return bValid
    End Function


    'Process an STD Record
    Public Function ProcessSTDRecord(ByRef oRow As DataRow, ByRef lPreviousClaimID As Long, ByVal dtRundate As Date, ByVal dtLastRunDate As Date, ByVal sUDL As String)
        Dim oSTDPreviousStatus As ClaimStatusList
        Dim oSTDStatus As ClaimStatusList
        Dim iRecType As Integer
        Dim sClaimID As String
        Dim sRecType As String
        Dim sRundate As String
        Dim sLastRundate As String


        Try

            'Store the record type
            iRecType = CType(oRow("RecType"), Long)
            sClaimID = CType(oRow("Claim_ID"), String)
            sRundate = dtRundate.ToShortDateString
            sLastRundate = dtLastRunDate.ToShortDateString


            'What is the state of the current claim?
            'Get the previous status for this record
            oSTDPreviousStatus = GetPreviousStatus(sClaimID, dtRundate, dtLastRunDate, sUDL)

            If oSTDPreviousStatus = ClaimStatusList.NULL Then
                sRecType = "1"      'Claim is new  -  no history
            Else
                sRecType = "2"      ' Claim is not new - has history
            End If

            'Determine the Claim's current Status 
            oSTDStatus = DetermineSTDStatus(oRow, oSTDPreviousStatus, sRundate, sLastRundate, sUDL, sRecType)

        Catch ex As Exception

        End Try
    End Function

    'Get the previously status for this record
    Public Function GetPreviousStatus(ByVal sIndexID As String, ByVal dtRundate As String, ByVal dtLastRunDate As String, ByVal sUDL As String) As ClaimStatusList

        Dim oPreviousState As ClaimStatusList
        Dim sGetFeedHistory As String
        Dim oPreviousHistory As New DataSet
        Dim sParam As String
        Dim sPreviousCode As String
        Dim sClaimID As String

        Try

            'Set the stored procedure name
            sGetFeedHistory = gsPackageName & ".sp_FedExG_Get_Feed_History"

            'Set the parameter list
            sParam = sIndexID

            'Call the stored procedure to get the history list
            RunSQL(sUDL, oPreviousHistory, sGetFeedHistory, sParam)

            'Is there any data?
            If oPreviousHistory.Tables(0).Rows.Count > 0 Then

                'Store the transaction Code
                sPreviousCode = oPreviousHistory.Tables(0).Rows(0).Item("TRANS_CODE")
                oPreviousState = SetActionCodes(sPreviousCode)
            Else

                'There is no previous state
                oPreviousState = ClaimStatusList.NULL
            End If

        Catch ex As Exception
        End Try

        Return oPreviousState
    End Function

    'Determine the Claim's current Status 
    Public Function DetermineSTDStatus(ByRef oRow As DataRow, ByVal oSTDPreviousStatus As ClaimStatusList, ByVal dtRundate As Date, ByVal dtLastRundate As Date, ByVal sUDL As String, ByVal sRecType As String) As ClaimStatusList

        Dim oRTWHistory As New DataSet
        Dim oClaimStatusList As ClaimStatusList
        Dim oClaimStatusListTmp As ClaimStatusList 'ITL Radar 20598 Dt: 10/22/2014 - To be removed 
        Dim lClaimID As Long
        Dim oClaimStatus As ClaimStatus
        Dim oRTWStatus As RTWStatus
        Dim oRTWReason As RTWReason
        Dim oWorkStatus As WorkStatus
        Dim oWorkStatusDesc As WorkStatusDesc
        Dim oRTWRow As DataRow
        Dim sParam As String
        Dim sRunDate As String
        Dim sLastRunDate As String
        Dim sProductID As String
        Dim oTempRow As DataRow
        Dim bNoSaveStoSto As Boolean = False 'don't save the STOSTO record, if there is a STDSTD record
        Dim iRowLastRFL As Integer = -1 'the row number of the last RFP record (should be first record in output)
        Dim iRowCounter As Integer = 0 'current row number 
        Dim bPackageHandler As Boolean = False 'Epic 1015206

        Try

            'Load the RTW Records
            lClaimID = CType(oRow("Claim_ID"), Long)
            'sRunDate = dtRundate.ToString
            'sLastRunDate = dtLastRundate.ToString
            sRunDate = dtRundate.ToShortDateString
            sLastRunDate = dtLastRundate.ToShortDateString
            sProductID = oRow("Product_ID")

            'i_claimid       IN  s_dis_claim.claim_id%TYPE,
            'i_RunDate	IN  VARCHAR2,
            'i_LastRunDate	IN  VARCHAR2,
            sParam = lClaimID.ToString & "," & sRunDate & "," & sLastRunDate & "," & sRecType

            RunSQL(sUDL, oRTWHistory, gsPackageName & ".sp_FedExG_Get_STD_Activity", sParam)

            'Is there any RTW History?
            If oRTWHistory.Tables(0).Rows.Count > 0 Then

                'loop through all the rows
                For Each oRTWRow In oRTWHistory.Tables(0).Rows

                    'Store the work status 

                    SetVariables(oRTWRow, oRTWStatus, oRTWReason, oWorkStatus, oWorkStatusDesc, bPackageHandler) ' Epic 1015206 04/05/2019 Added Package Handle parameter

                    Select Case oRTWStatus
                        Case RTWStatus.Pend
                            If Not bPackageHandler Then  'Epic 1015206 04/05/2019
                                'If the claim is pending then most likely it is STOSTO
                                Select Case oRTWReason
                                    Case RTWReason.Employee, RTWReason.Employer, RTWReason.Medical, RTWReason.Relapse, RTWReason.NewClaim
                                        'oClaimStatusList = ClaimStatusList.STD_STOSTO
                                        'ITL Radar 20598 Dt: 10/20/2014 STOSTO to become LOASTU - For Parallel Start
                                        If gsIsParallel = "TRUE" Then
                                            oClaimStatusList = ClaimStatusList.LOA_STU
                                        Else
                                            oClaimStatusList = ClaimStatusList.STD_STOSTO
                                        End If
                                        'ITL Radar 20598 Dt: 10/20/2014 STOSTO to become LOASTU - For Parallel End
                                    Case Else
                                        oClaimStatusList = ClaimStatusList.NULL
                                End Select
                            End If
                            'Changes for IM1652023
                            'Case RTWStatus.Approved
                        Case RTWStatus.Approved, RTWStatus.Terminated
                            'Is the claimant at work?
                            If oWorkStatus = WorkStatus.ATWORK Then
                                If Not bPackageHandler Then 'Epic 1015206 04/05/2019

                                    If oWorkStatusDesc = WorkStatusDesc.FULLDUTY Then
                                        'Claimant is approved and at work on full duty - PLAPTD
                                        oClaimStatusList = ClaimStatusList.STD_RFL
                                        iRowLastRFL = iRowCounter
                                        'Changes for 12466 Start
                                    ElseIf oWorkStatusDesc = WorkStatusDesc.MODJOBABILITY Then
                                        oClaimStatusList = ClaimStatusList.STD_LOAMOD
                                        'Changes for 12466 End
                                    ElseIf oWorkStatusDesc = WorkStatusDesc.PARTIALDUTY Then
                                        'Claimant is approved and at work on partial duty - PLAPTD
                                        'ITL Radar 20598 Dt: 10/20/2014 PLA to become POS - For Parallel Start
                                        If gsIsParallel = "TRUE" Then
                                            oClaimStatusList = ClaimStatusList.STD_POSPTD
                                        Else
                                            oClaimStatusList = ClaimStatusList.STD_PLAPTD
                                        End If
                                        bNoSaveStoSto = True
                                    End If
                                End If
                            ElseIf oWorkStatus = WorkStatus.NOTATWORK Then
                                'Claimant is approved and at not work - STDSTD
                                oClaimStatusList = ClaimStatusList.STD_STDSTD
                                bNoSaveStoSto = True
                            End If
                        Case RTWStatus.Cancelled
                            'If RTW is cancelled then ignore
                            oClaimStatusList = ClaimStatusList.NULL

                        Case RTWStatus.Denied
                            'If RTW is Denied then ignore
                            oClaimStatusList = ClaimStatusList.NULL
                            'Changes for IM1652023
                            'Case RTWStatus.Terminated
                            '    'If the record is terminated then the user returned to work
                            '    oClaimStatusList = ClaimStatusList.STD_RFL
                            '    iRowLastRFL = iRowCounter
                    End Select

                    'Should we add this record to the data feed?
                    'ITL Radar 20598 Dt: 10/27/2014 AddToParallel function for Parallel and PROD Start
                    If gsIsParallel = "TRUE" Then
                        If AddToDataFeedParallel(oSTDPreviousStatus, oClaimStatusList, isSTDRecord(oRow)) = True Then
                            oRTWRow("TransCode") = oClaimStatusList
                            oRTWRow("SaveFlag") = 1
                            oSTDPreviousStatus = oClaimStatusList
                        End If
                    Else
                        If AddToDataFeed(oSTDPreviousStatus, oClaimStatusList) = True Then
                            oRTWRow("TransCode") = oClaimStatusList
                            oRTWRow("SaveFlag") = 1
                            oSTDPreviousStatus = oClaimStatusList
                        End If
                    End If
                    'Original Code Start
                    'If AddToDataFeed(oSTDPreviousStatus, oClaimStatusList) = True Then
                    '    oRTWRow("TransCode") = oClaimStatusList
                    '    oRTWRow("SaveFlag") = 1
                    '    oSTDPreviousStatus = oClaimStatusList
                    'End If
                    'Original Code End
                    'ITL Radar 20598 Dt: 10/27/2014 AddToParallel function for Parallel and PROD End
                    iRowCounter += 1

                Next

                ' Check to see if this code with this date has already been sent
                For Each oRTWRow In oRTWHistory.Tables(0).Rows
                    If TransactionAlreadySent(oRTWRow, sUDL) Then
                        oRTWRow("SaveFlag") = 0
                    End If
                Next

                'Save the data
                Dim iSequence As Integer
                'save the last RFL record 
                If iRowLastRFL > 0 Then
                    oRTWRow = oRTWHistory.Tables(0).Rows(iRowLastRFL)
                    If oRTWRow("SaveFlag") = 1 Then
                        oRTWRow("SeqNbr") = iSequence
                        'If TRUE then add to the datafeed
                        AddRowToDataFeed(oRTWRow)
                        'Add this status to the history table and update the previous status
                        AddRowToHistoryTable(oRTWRow, sUDL, sProductID)
                        oRTWRow("SaveFlag") = 0
                        iSequence += 1
                    End If
                End If

                'loop through again to save the data
                For Each oRTWRow In oRTWHistory.Tables(0).Rows
                    If oRTWRow("SaveFlag") = 1 Then
                        'ITL Radar 20598 Dt: 10/22/2014  Commenting the following original line and checking TransCode for Parallel
                        'If bNoSaveStoSto And oRTWRow("TransCode") = ClaimStatusList.STD_STOSTO Then
                        If gsIsParallel = "TRUE" Then
                            oClaimStatusListTmp = ClaimStatusList.LOA_STU
                        Else
                            oClaimStatusListTmp = ClaimStatusList.STD_STOSTO
                        End If
                        If bNoSaveStoSto And oRTWRow("TransCode") = oClaimStatusListTmp Then
                            'skip a STOSTO if there is a STDSTD
                        Else
                            oRTWRow("SeqNbr") = iSequence
                            'If TRUE then add to the datafeed
                            AddRowToDataFeed(oRTWRow)
                            'Add this status to the history table and update the previous status
                            AddRowToHistoryTable(oRTWRow, sUDL, sProductID)
                            iSequence += 1
                        End If
                    End If

                Next

            End If

        Catch ex As Exception

        End Try

        Return oClaimStatus
    End Function



    'Private Sub AddSTDToHistoryTable(ByVal oRow As DataRow, ByVal sUDL As String, ByVal sProductID As String)
    '    Dim sStoredProcedure As String
    '    Dim oHistory As New DataSet
    '    Dim sParam As String
    '    Dim sAction As String
    '    Dim sActionReason As String
    '    Dim dTempDate As Date

    '    'Parameter values
    '    Dim I_RUN_ID As String
    '    Dim I_COMPANY_ID As String
    '    Dim I_EMP_ID As String
    '    Dim I_CLAIM_ID As String
    '    Dim I_PRODUCT_ID As String
    '    Dim I_TRANS_SEQ As String
    '    Dim I_TRANS_DATE As String
    '    Dim I_TRANS_CODE As String

    '    Try
    '        'Translate the reason to text
    '        GetActionCodes(sAction, sActionReason, CType(oRow("TransCode"), Integer))

    '        'Set the stored procedure name
    '        sStoredProcedure = gsPackageName & ".sp_FedExG_Insert_Feed_History"

    '        'Set the parameter list
    '        I_RUN_ID = gsSequenceNumber
    '        I_COMPANY_ID = oRow("COMPANY_ID")
    '        I_EMP_ID = oRow("EMP_ID")
    '        I_CLAIM_ID = oRow("CLAIM_ID")
    '        I_PRODUCT_ID = sProductID
    '        I_TRANS_SEQ = CType(oRow("SeqNbr"), String)

    '        dTempDate = oRow("RTW_START_DATE")
    '        I_TRANS_DATE = dTempDate.Month.ToString & "/" & dTempDate.Day & "/" & dTempDate.Year
    '        I_TRANS_CODE = sAction & sActionReason

    '        'PROCEDURE sp_FedExG_Insert_Feed_History (
    '        '  I_RUN_ID          IN INTEGER,
    '        '  I_CREATE_DATE	 IN DATE,
    '        '  I_COMPANY_ID		 IN INTEGER,
    '        '  I_EMP_ID			 IN VARCHAR2,
    '        '  I_CLAIM_ID		 IN NUMBER,
    '        '  I_PRODUCT_ID		 IN NUMBER,
    '        '  I_TRANS_SEQ		 IN INTEGER,
    '        '  I_TRANS_DATE		 IN DATE,
    '        '  I_TRANS_CODE		 IN VARCHAR2,
    '        '  Result_out 		 OUT NUMBER
    '        ') 

    '        'Create the parameter variable
    '        sParam = I_RUN_ID & "," & I_COMPANY_ID & "," & I_EMP_ID & "," & I_CLAIM_ID
    '        sParam = sParam & "," & I_PRODUCT_ID & "," & I_TRANS_SEQ & "," & I_TRANS_DATE & "," & I_TRANS_CODE

    '        'Call the stored procedure to store the history list
    '        RunSQL(sUDL, oHistory, sStoredProcedure, sParam)

    '    Catch ex As Exception
    '    End Try
    'End Sub

    'Private Sub AddFMLToHistoryTable(ByVal oRow As DataRow, ByVal oClaimStatusList As ClaimStatusList, ByVal sUDL As String, ByVal sProductID As String)
    '    Dim sStoredProcedure As String
    '    Dim oHistory As New DataSet
    '    Dim sParam As String
    '    Dim sAction As String
    '    Dim sActionReason As String
    '    Dim dTempDate As Date

    '    'Parameter values
    '    Dim I_RUN_ID As String
    '    Dim I_COMPANY_ID As String
    '    Dim I_EMP_ID As String
    '    Dim I_CLAIM_ID As String
    '    Dim I_PRODUCT_ID As String
    '    Dim I_TRANS_SEQ As String
    '    Dim I_TRANS_DATE As String
    '    Dim I_TRANS_CODE As String

    '    Try
    '        'Translate the reason to text
    '        GetActionCodes(sAction, sActionReason, oClaimStatusList)

    '        'Set the stored procedure name
    '        sStoredProcedure = gsPackageName & ".sp_FedExG_Insert_Feed_History"

    '        'Set the parameter list
    '        I_RUN_ID = gsSequenceNumber
    '        I_COMPANY_ID = oRow("COMPANY_ID")
    '        I_EMP_ID = oRow("EMP_ID")
    '        I_CLAIM_ID = oRow("CLAIM_ID")
    '        I_PRODUCT_ID = sProductID
    '        I_TRANS_SEQ = 0 'fix this

    '        dTempDate = oRow("Effective_date")
    '        I_TRANS_DATE = dTempDate.Month.ToString & "/" & dTempDate.Day & "/" & dTempDate.Year
    '        I_TRANS_CODE = sAction & sActionReason

    '        'PROCEDURE sp_FedExG_Insert_Feed_History (
    '        '  I_RUN_ID          IN INTEGER,
    '        '  I_CREATE_DATE	 IN DATE,
    '        '  I_COMPANY_ID		 IN INTEGER,
    '        '  I_EMP_ID			 IN VARCHAR2,
    '        '  I_CLAIM_ID		 IN NUMBER,
    '        '  I_PRODUCT_ID		 IN NUMBER,
    '        '  I_TRANS_SEQ		 IN INTEGER,
    '        '  I_TRANS_DATE		 IN DATE,
    '        '  I_TRANS_CODE		 IN VARCHAR2,
    '        '  Result_out 		 OUT NUMBER
    '        ') 

    '        'Create the parameter variable
    '        sParam = I_RUN_ID & "," & I_COMPANY_ID & "," & I_EMP_ID & "," & I_CLAIM_ID
    '        sParam = sParam & "," & I_PRODUCT_ID & "," & I_TRANS_SEQ & "," & I_TRANS_DATE & "," & I_TRANS_CODE

    '        'Call the stored procedure to store the history list
    '        RunSQL(sUDL, oHistory, sStoredProcedure, sParam)

    '    Catch ex As Exception
    '    End Try
    'End Sub

    Private Sub AddRowToHistoryTable(ByVal oRow As DataRow, ByVal sUDL As String, ByVal sProductID As String)
        Dim sStoredProcedure As String
        Dim oHistory As New DataSet
        Dim sParam As String
        Dim sAction As String
        Dim sActionReason As String
        Dim dTempDate As Date

        'Parameter values
        Dim I_RUN_ID As String
        Dim I_COMPANY_ID As String
        Dim I_EMP_ID As String
        Dim I_CLAIM_ID As String
        Dim I_PRODUCT_ID As String
        Dim I_TRANS_SEQ As String
        Dim I_TRANS_DATE As String
        Dim I_TRANS_CODE As String

        Try
            'Translate the reason to text
            GetActionCodes(sAction, sActionReason, CType(oRow("TransCode"), Integer))

            'Set the stored procedure name
            sStoredProcedure = gsPackageName & ".sp_FedExG_Insert_Feed_History"

            'Set the parameter list
            I_RUN_ID = gsSequenceNumber
            I_COMPANY_ID = oRow("COMPANY_ID")
            I_EMP_ID = oRow("EMP_ID")
            I_CLAIM_ID = oRow("CLAIM_ID")
            I_PRODUCT_ID = sProductID
            I_TRANS_SEQ = CType(oRow("SeqNbr"), String)

            dTempDate = oRow("EFFECTIVE_DATE")
            I_TRANS_DATE = dTempDate.Month.ToString & "/" & dTempDate.Day & "/" & dTempDate.Year
            I_TRANS_CODE = sAction & sActionReason

            'Create the parameter variable
            sParam = I_RUN_ID & "," & I_COMPANY_ID & "," & I_EMP_ID & "," & I_CLAIM_ID
            sParam = sParam & "," & I_PRODUCT_ID & "," & I_TRANS_SEQ & "," & I_TRANS_DATE & "," & I_TRANS_CODE

            'Call the stored procedure to store the history list
            RunSQL(sUDL, oHistory, sStoredProcedure, sParam)

        Catch ex As Exception
        End Try
    End Sub


    'Add a new row to the datafeed
    'Private Sub AddSTDRowToDataFeed(ByVal oRow As DataRow)
    '    Dim oDataRow As DataRow
    '    Dim sAction As String
    '    Dim sActionReason As String

    '    Try
    '        GetActionCodes(sAction, sActionReason, CType(oRow("TransCode"), Integer))

    '        'Only add the record if the codes are valid
    '        If sAction.Length > 0 And sActionReason.Length > 0 Then
    '            oDataRow = goTable.NewRow()
    '            oDataRow("DetailRecID") = "D" & Space(14)
    '            oDataRow("EmployeeID") = CType(oRow("EMP_ID"), String).Replace("-", "").PadLeft(15, "0")
    '            'oDataRow("AbsenceIndicator") = "000000000000000"
    '            oDataRow("TransSeq") = CType(oRow("SeqNbr"), String).PadLeft(15, "0")
    '            oDataRow("filler") = " " 'filler

    '            'This value needs to be calculated based on the action code and action reason
    '            oDataRow("TransDate") = CType(oRow("RTW_START_DATE"), Date).ToShortDateString  'First Day Absent


    '            oDataRow("blank") = Space(24) '24 Spaces
    '            oDataRow("Action") = sAction
    '            oDataRow("ActionReason") = sActionReason

    '            'Add a new row to the dataset
    '            goTable.Rows.Add(oDataRow)
    '        End If

    '    Catch ex As Exception

    '    End Try
    'End Sub

    'Add a new row to the datafeed
    Private Sub AddRowToDataFeed(ByVal oRow As DataRow)
        Dim oDataRow As DataRow
        Dim sAction As String
        Dim sActionReason As String

        Try
            GetActionCodes(sAction, sActionReason, CType(oRow("TransCode"), Integer))

            'Only add the record if the codes are valid
            If sAction.Length > 0 And sActionReason.Length > 0 Then
                oDataRow = goTable.NewRow()
                oDataRow("DetailRecID") = "D" & Space(14)
                oDataRow("EmployeeID") = CType(oRow("EMP_ID"), String).Replace("-", "").PadLeft(15, "0")
                oDataRow("TransSeq") = CType(oRow("SeqNbr"), String).PadLeft(15, "0")
                oDataRow("filler") = " "
                oDataRow("TransDate") = CType(oRow("EFFECTIVE_DATE"), Date).ToShortDateString
                oDataRow("blank") = Space(24)
                oDataRow("Action") = sAction
                oDataRow("ActionReason") = sActionReason

                'Add a new row to the dataset
                goTable.Rows.Add(oDataRow)
            End If

        Catch ex As Exception

        End Try
    End Sub


    Private Sub AddNewRow(ByVal oRow As DataRow)
        Try

            'Add a new row to the dataset
            goTable.Rows.Add(oRow)
        Catch ex As Exception

        End Try
    End Sub

    Private Sub GetActionCodes(ByRef sAction As String, ByRef sActionReason As String, ByVal oClaimStatusList As ClaimStatusList)
        Try
            Select Case oClaimStatusList
                'ITL Dt: 10/20/2014 Radar 20598 Adding case for LOASTU
                Case ClaimStatusList.LOA_STU
                    sAction = "LOA"
                    sActionReason = "STU"
                Case ClaimStatusList.FML_LOAFML
                    sAction = "LOA"
                    sActionReason = "FML"
                Case ClaimStatusList.FML_PLAFLI
                    sAction = "PLA"
                    sActionReason = "FLI"
                    'ITL radar 20598 Dt: 10/22/2014 PLA to be POS for Parallel
                Case ClaimStatusList.FML_POSFLI
                    sAction = "POS"
                    sActionReason = "FLI"
                Case ClaimStatusList.FML_RFLFML
                    sAction = "RFL"
                    sActionReason = "FML"
                Case ClaimStatusList.FML_RFLFLI
                    sAction = "RFL"
                    sActionReason = "FLI"
                Case ClaimStatusList.STD_PLAPTD
                    sAction = "PLA"
                    sActionReason = "PTD"
                    'ITL radar 20598 Dt: 10/22/2014 PLA to be POS for Parallel
                Case ClaimStatusList.STD_POSPTD
                    sAction = "POS"
                    sActionReason = "PTD"
                Case ClaimStatusList.STD_RFLRPD
                    sAction = "RFL"
                    sActionReason = "RPD"
                    'ITL radar 20598 Dt: 10/27/2014 RFLRPD to be POSRPD for Parallel
                Case ClaimStatusList.STD_POSRPD
                    sAction = "POS"
                    sActionReason = "RPD"
                Case ClaimStatusList.STD_RFLSTD
                    sAction = "RFL"
                    sActionReason = "STD"
                Case ClaimStatusList.STD_RFLSTO
                    sAction = "RFL"
                    sActionReason = "STO"
                    'ITL radar 20598 Dt: 10/22/2014 STO to be STU for Parallel
                Case ClaimStatusList.STD_RFLSTU
                    sAction = "RFL"
                    sActionReason = "STU"
                Case ClaimStatusList.STD_STDSTD
                    sAction = "STD"
                    sActionReason = "STD"
                Case ClaimStatusList.STD_STOSTO
                    sAction = "STO"
                    sActionReason = "STO"
                    'Changes for 12466
                Case ClaimStatusList.STD_LOAMOD
                    sAction = "LOA"
                    sActionReason = "MOD"
                Case ClaimStatusList.STD_RFLRND
                    sAction = "RFL"
                    sActionReason = "RND"
                    'Changes as per Epic 828496 - NY PFL Claims Addition - Start	
                Case ClaimStatusList.PFL_LOAPFL
                    sAction = "LOA"
                    sActionReason = "PFL"
                Case ClaimStatusList.PFL_PFLPFL
                    sAction = "PFL"
                    sActionReason = "PFL"
                Case ClaimStatusList.PFL_RFLPFU
                    sAction = "RFL"
                    sActionReason = "PFU"
                Case ClaimStatusList.PFL_RFLPFL
                    sAction = "RFL"
                    sActionReason = "PFL"
                    'Changes as per Epic 828496 - NY PFL Claims Addition - End
                Case ClaimStatusList.NULL
                    sAction = ""
                    sActionReason = ""
            End Select
        Catch ex As Exception
        End Try
    End Sub

    Private Function SetActionCodes(ByRef sActionCode As String) As ClaimStatusList
        Dim oReturnCode As ClaimStatusList

        Try
            'Translate the transaction Code to an internal code
            Select Case sActionCode
                'ITL Dt: 10/20/2014 Radar 20598 Adding case for LOASTU
                Case "LOASTU"
                    oReturnCode = ClaimStatusList.LOA_STU
                Case "LOAFML"
                    oReturnCode = ClaimStatusList.FML_LOAFML
                Case "PLAFLI"
                    oReturnCode = ClaimStatusList.FML_PLAFLI
                    'ITL Dt: 10/20/2014 Radar 20598 Adding case for POSFLI - All PLA will become POS
                Case "POSFLI"
                    oReturnCode = ClaimStatusList.FML_POSFLI
                Case "RFLFML"
                    oReturnCode = ClaimStatusList.FML_RFLFML
                Case "RFLFLI"
                    oReturnCode = ClaimStatusList.FML_RFLFLI
                Case "PLAPTD"
                    oReturnCode = ClaimStatusList.STD_PLAPTD
                    'ITL Dt: 10/20/2014 Radar 20598 Adding case for POSPTD - All PLA will become POS
                Case "POSPTD"
                    oReturnCode = ClaimStatusList.STD_POSPTD
                Case "RFLRPD"
                    oReturnCode = ClaimStatusList.STD_RFLRPD
                    'ITL Dt: 10/27/2014 Radar 20598 Adding case for POSRPD
                Case "POSRPD"
                    oReturnCode = ClaimStatusList.STD_POSRPD
                Case "RFLSTD"
                    oReturnCode = ClaimStatusList.STD_RFLSTD
                Case "RFLSTO"
                    oReturnCode = ClaimStatusList.STD_RFLSTO
                    'ITL Dt: 10/20/2014 Radar 20598 Adding case for RFLSTU - All STO will become STU
                Case "RFLSTU"
                    oReturnCode = ClaimStatusList.STD_RFLSTU
                Case "STDSTD"
                    oReturnCode = ClaimStatusList.STD_STDSTD
                Case "STOSTO"
                    oReturnCode = ClaimStatusList.STD_STOSTO
                    'Changes for 12466 Start
                Case "LOAMOD"
                    oReturnCode = ClaimStatusList.STD_LOAMOD
                Case "RFLRND"
                    oReturnCode = ClaimStatusList.STD_RFLRND
                    'Changes for 12466 End
                    'Changes as per Epic 828496 - NY PFL Claims Addition - Start
                Case "LOAPFL"
                    oReturnCode = ClaimStatusList.PFL_LOAPFL
                Case "PFLPFL"
                    oReturnCode = ClaimStatusList.PFL_PFLPFL
                Case "RFLPFU"
                    oReturnCode = ClaimStatusList.PFL_RFLPFU
                Case "RFLPFL"
                    oReturnCode = ClaimStatusList.PFL_RFLPFL
                    'Changes as per Epic 828496 - NY PFL Claims Addition - End
                Case Else
                    oReturnCode = ClaimStatusList.NULL
            End Select

            Return oReturnCode
        Catch ex As Exception
        End Try
    End Function

    'Determine if we should add the status to the data feed based on the 
    'current and the previous status
    Public Function AddToDataFeed(ByVal oSTDPreviousStatus As DataExtractClasses.ClaimStatusList, ByRef oClaimStatusList As DataExtractClasses.ClaimStatusList) As Boolean
        Dim bAddToFeed As Boolean

        Try

            'What is the previous status?
            Select Case oSTDPreviousStatus
                Case ClaimStatusList.STD_STOSTO 'Not at work/Not Approved

                    'What is the current claim status?
                    Select Case oClaimStatusList
                        Case ClaimStatusList.STD_STDSTD, ClaimStatusList.STD_PLAPTD, ClaimStatusList.STD_RFLSTO, ClaimStatusList.STD_LOAMOD 'Changes for 12466
                            bAddToFeed = True
                        Case ClaimStatusList.STD_RFL
                            'RTW from Not at work/Not Approved
                            oClaimStatusList = ClaimStatusList.STD_RFLSTO
                            bAddToFeed = True
                        Case Else
                            'Ignore this status change
                            bAddToFeed = False
                    End Select
                Case ClaimStatusList.STD_STDSTD 'Not at work/Approved

                    'What is the current claim status?
                    Select Case oClaimStatusList
                        Case ClaimStatusList.STD_STOSTO, ClaimStatusList.STD_PLAPTD, ClaimStatusList.STD_RFLSTD, ClaimStatusList.STD_LOAMOD 'Changes for 12466
                            bAddToFeed = True
                        Case ClaimStatusList.STD_RFL
                            'RTW from Not at work/Approved
                            oClaimStatusList = ClaimStatusList.STD_RFLSTD
                            bAddToFeed = True
                        Case Else
                            'Ignore this status change
                            bAddToFeed = False
                    End Select
                Case ClaimStatusList.STD_PLAPTD 'At Work/Restricted

                    'What is the current claim status?
                    Select Case oClaimStatusList
                        'Raise issue 
                        Case ClaimStatusList.STD_STOSTO, ClaimStatusList.STD_STDSTD, ClaimStatusList.STD_RFLRPD, ClaimStatusList.STD_LOAMOD 'Changes for 12466
                            bAddToFeed = True
                        Case ClaimStatusList.STD_RFL
                            'RTW from Not at work/Not Approved
                            oClaimStatusList = ClaimStatusList.STD_RFLRPD
                            bAddToFeed = True
                        Case Else
                            'Ignore this status change
                            bAddToFeed = False
                    End Select
                    'Changes for 12466 Start
                Case ClaimStatusList.STD_LOAMOD  'At Work/Mod Abilities

                    'What is the current claim status?
                    Select Case oClaimStatusList
                        Case ClaimStatusList.STD_STOSTO, ClaimStatusList.STD_STDSTD, ClaimStatusList.STD_RFLRND, ClaimStatusList.STD_PLAPTD
                            bAddToFeed = True
                        Case ClaimStatusList.STD_RFL
                            'RTW from Not at work/Not Approved
                            oClaimStatusList = ClaimStatusList.STD_RFLRND
                            bAddToFeed = True
                        Case Else
                            'Ignore this status change
                            bAddToFeed = False
                    End Select
                    'Changes for 12466 End
                Case ClaimStatusList.STD_RFLSTO 'RTW from Unapproved Leave

                    'What is the current claim status?
                    Select Case oClaimStatusList
                        Case ClaimStatusList.STD_STOSTO, ClaimStatusList.STD_STDSTD, ClaimStatusList.STD_PLAPTD, ClaimStatusList.STD_LOAMOD 'Changes for 12466
                            bAddToFeed = True
                        Case Else
                            'Ignore this status change
                            bAddToFeed = False
                    End Select


                Case ClaimStatusList.STD_RFLSTD 'RTW from Approved Leave

                    'What is the current claim status?
                    Select Case oClaimStatusList
                        Case ClaimStatusList.STD_STOSTO, ClaimStatusList.STD_STDSTD, ClaimStatusList.STD_PLAPTD, ClaimStatusList.STD_LOAMOD 'Changes for 12466
                            bAddToFeed = True
                        Case Else
                            'Ignore this status change
                            bAddToFeed = False
                    End Select

                Case ClaimStatusList.STD_RFLRPD 'RTW from Partial Leave

                    'What is the current claim status?
                    Select Case oClaimStatusList
                        Case ClaimStatusList.STD_STOSTO, ClaimStatusList.STD_STDSTD, ClaimStatusList.STD_PLAPTD, ClaimStatusList.STD_LOAMOD 'Changes for 12466
                            bAddToFeed = True
                        Case Else
                            'Ignore this status change
                            bAddToFeed = False
                    End Select
                    'Changes for 12466 Start
                Case ClaimStatusList.STD_RFLRND 'RTW from LOA/MOD

                    'What is the current claim status?
                    Select Case oClaimStatusList
                        Case ClaimStatusList.STD_STOSTO, ClaimStatusList.STD_STDSTD, ClaimStatusList.STD_LOAMOD, ClaimStatusList.STD_PLAPTD
                            bAddToFeed = True
                        Case Else
                            'Ignore this status change
                            bAddToFeed = False
                    End Select
                    'Changes for 12466 Start
                Case ClaimStatusList.NULL

                    'What is the current claim status?
                    Select Case oClaimStatusList
                        'ITL Dt: 10/20/2014 Radar 20598 Adding LOASTU in case list
                        Case ClaimStatusList.STD_STOSTO, ClaimStatusList.STD_STDSTD, ClaimStatusList.STD_PLAPTD, ClaimStatusList.FML_LOAFML, ClaimStatusList.FML_PLAFLI, ClaimStatusList.STD_LOAMOD 'Changes for 12466
                            bAddToFeed = True
                        Case Else
                            bAddToFeed = False
                    End Select

                    ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                    '
                    '   FML CODES
                    '
                    ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

                Case ClaimStatusList.FML_LOAFML

                    'What is the current claim status?
                    Select Case oClaimStatusList
                        Case ClaimStatusList.FML_RFLFML, ClaimStatusList.FML_PLAFLI
                            bAddToFeed = True 'Radar 21219 - for RFLFML, records should be written to File
                        Case ClaimStatusList.FML_RFL
                            'RTW from Not at work/Not Approved
                            oClaimStatusList = ClaimStatusList.FML_RFLFML
                            bAddToFeed = True
                        Case Else
                            bAddToFeed = False
                    End Select


                Case ClaimStatusList.FML_PLAFLI

                    'What is the current claim status?
                    Select Case oClaimStatusList
                        Case ClaimStatusList.FML_LOAFML, ClaimStatusList.FML_RFLFLI
                            bAddToFeed = True
                        Case ClaimStatusList.FML_RFL
                            'RTW from Not at work/Not Approved
                            oClaimStatusList = ClaimStatusList.FML_RFLFLI
                            bAddToFeed = True
                        Case Else
                            bAddToFeed = False
                    End Select

                Case ClaimStatusList.FML_RFLFML

                    'What is the current claim status?
                    Select Case oClaimStatusList
                        Case ClaimStatusList.FML_LOAFML, ClaimStatusList.FML_PLAFLI
                            bAddToFeed = True
                        Case Else
                            bAddToFeed = False
                    End Select

                Case ClaimStatusList.FML_RFLFLI

                    'What is the current claim status?
                    Select Case oClaimStatusList
                        Case ClaimStatusList.FML_LOAFML, ClaimStatusList.FML_PLAFLI
                            bAddToFeed = True
                        Case Else
                            bAddToFeed = False
                    End Select

                    ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                    '
                    '   PFL CODES
                    '
                    ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                    'Changes as per Epic 828496 - NY PFL Claims Addition - Start
                Case ClaimStatusList.PFL_LOAPFL
                    'What is the current claim status?
                    Select Case oClaimStatusList
                        Case ClaimStatusList.PFL_RFLPFU
                            bAddToFeed = True
                        Case Else
                            bAddToFeed = False
                    End Select

                Case ClaimStatusList.PFL_PFLPFL
                    'What is the current claim status?
                    Select Case oClaimStatusList
                        Case ClaimStatusList.PFL_RFLPFL
                            bAddToFeed = True
                        Case Else
                            bAddToFeed = False
                    End Select
                Case Else
                    Select Case oClaimStatusList
                        Case ClaimStatusList.PFL_LOAPFL
                            bAddToFeed = True
                        Case ClaimStatusList.PFL_PFLPFL
                            bAddToFeed = True
                        Case Else
                            bAddToFeed = False
                    End Select
                    'Changes as per Epic 828496 - NY PFL Claims Addition - End
            End Select

        Catch ex As Exception
            'Logging may be added in a later iteration.

        End Try

        Return bAddToFeed
    End Function

    'Determine if we should add the status to the data feed based on the 
    'current and the previous status
    Public Function AddToDataFeedParallel(ByVal oSTDPreviousStatus As DataExtractClasses.ClaimStatusList, ByRef oClaimStatusList As DataExtractClasses.ClaimStatusList, Optional ByVal bIsSTD As Boolean = False) As Boolean
        Dim bAddToFeed As Boolean

        Try

            'What is the previous status?
            Select Case oSTDPreviousStatus
                Case ClaimStatusList.STD_STOSTO 'Not at work/Not Approved
                        'What is the current claim status?
                        Select Case oClaimStatusList
                            Case ClaimStatusList.STD_STDSTD, ClaimStatusList.STD_POSPTD, ClaimStatusList.STD_RFLSTU, ClaimStatusList.STD_LOAMOD 'Changes for 12466
                                bAddToFeed = True
                            Case ClaimStatusList.STD_RFL
                                'RTW from Not at work/Not Approved
                                oClaimStatusList = ClaimStatusList.STD_RFLSTU
                                bAddToFeed = True
                            Case Else
                                'Ignore this status change
                                bAddToFeed = False
                        End Select
                Case ClaimStatusList.LOA_STU 'STD/LOA Pend - Parallel Only
                    'If STD Claim
                    If bIsSTD Then
                        'What is the current claim status?
                        Select Case oClaimStatusList
                            Case ClaimStatusList.STD_STDSTD, ClaimStatusList.STD_POSPTD, ClaimStatusList.STD_RFLSTU, ClaimStatusList.STD_LOAMOD 'Changes for 12466
                                bAddToFeed = True
                            Case ClaimStatusList.STD_RFL
                                'RTW from Not at work/Not Approved
                                oClaimStatusList = ClaimStatusList.STD_RFLSTU
                                bAddToFeed = True
                            Case Else
                                'Ignore this status change
                                bAddToFeed = False
                        End Select
                    Else
                        'LOA Claim
                        'What is the current claim status?
                        Select Case oClaimStatusList
                            Case ClaimStatusList.FML_LOAFML
                                bAddToFeed = True
                            Case Else
                                'Ignore this status change
                                bAddToFeed = False
                        End Select
                    End If
                    'ITL Radar 20598 Dt: 10/27/2014 End
                Case ClaimStatusList.STD_STDSTD 'Not at work/Approved
                        Select Case oClaimStatusList
                            Case ClaimStatusList.LOA_STU, ClaimStatusList.STD_POSPTD, ClaimStatusList.STD_RFLSTD, ClaimStatusList.STD_LOAMOD
                                bAddToFeed = True
                            Case ClaimStatusList.STD_RFL
                                'RTW from Not at work/Approved
                                oClaimStatusList = ClaimStatusList.STD_RFLSTD
                                bAddToFeed = True
                            Case Else
                                'Ignore this status change
                                bAddToFeed = False
                    End Select
                    ' ITL Radar 20598 Dt: 11/13/2014 Adding case for POSPTD
                Case ClaimStatusList.STD_PLAPTD, ClaimStatusList.STD_POSPTD 'At Work/Restricted
                    Select Case oClaimStatusList
                        'Raise issue 
                        Case ClaimStatusList.LOA_STU, ClaimStatusList.STD_STDSTD, ClaimStatusList.STD_POSRPD, ClaimStatusList.STD_LOAMOD 'Changes for 12466
                            bAddToFeed = True
                        Case ClaimStatusList.STD_RFL
                            'RTW from Not at work/Not Approved
                            oClaimStatusList = ClaimStatusList.STD_POSRPD
                            bAddToFeed = True
                        Case Else
                            'Ignore this status change
                            bAddToFeed = False
                    End Select
                Case ClaimStatusList.STD_LOAMOD  'At Work/Mod Abilities
                        Select Case oClaimStatusList
                            Case ClaimStatusList.LOA_STU, ClaimStatusList.STD_STDSTD, ClaimStatusList.STD_RFLRND, ClaimStatusList.STD_POSPTD
                                bAddToFeed = True
                            Case ClaimStatusList.STD_RFL
                                'RTW from Not at work/Not Approved
                                oClaimStatusList = ClaimStatusList.STD_RFLRND
                                bAddToFeed = True
                            Case Else
                                'Ignore this status change
                                bAddToFeed = False
                        End Select
                    'Changes for 12466 End
                Case ClaimStatusList.STD_RFLSTO, ClaimStatusList.STD_RFLSTU 'RTW from Unapproved Leave

                    'What is the current claim status?
                    Select Case oClaimStatusList
                        Case ClaimStatusList.LOA_STU, ClaimStatusList.STD_STDSTD, ClaimStatusList.STD_POSPTD, ClaimStatusList.STD_LOAMOD 'Changes for 12466
                            bAddToFeed = True
                        Case Else
                            'Ignore this status change
                            bAddToFeed = False
                    End Select

                Case ClaimStatusList.STD_RFLSTD 'RTW from Approved Leave

                    'What is the current claim status?
                    Select Case oClaimStatusList
                        Case ClaimStatusList.LOA_STU, ClaimStatusList.STD_STDSTD, ClaimStatusList.STD_POSPTD, ClaimStatusList.STD_LOAMOD 'Changes for 12466
                            bAddToFeed = True
                        Case Else
                            'Ignore this status change
                            bAddToFeed = False
                    End Select

                Case ClaimStatusList.STD_RFLRPD, ClaimStatusList.STD_POSRPD 'RTW from Partial Leave

                    'What is the current claim status?
                    Select Case oClaimStatusList
                        Case ClaimStatusList.LOA_STU, ClaimStatusList.STD_STDSTD, ClaimStatusList.STD_POSPTD, ClaimStatusList.STD_LOAMOD 'Changes for 12466
                            bAddToFeed = True
                        Case Else
                            'Ignore this status change
                            bAddToFeed = False
                    End Select
                    'Changes for 12466 Start
                Case ClaimStatusList.STD_RFLRND 'RTW from LOA/MOD

                    'What is the current claim status?
                    Select Case oClaimStatusList
                        Case ClaimStatusList.LOA_STU, ClaimStatusList.STD_STDSTD, ClaimStatusList.STD_LOAMOD, ClaimStatusList.STD_POSPTD
                            bAddToFeed = True
                        Case Else
                            'Ignore this status change
                            bAddToFeed = False
                    End Select
                    'Changes for 12466 Start
                Case ClaimStatusList.NULL

                    'What is the current claim status?
                    Select Case oClaimStatusList
                        'ITL Dt: 10/20/2014 Radar 20598 Adding LOASTU in case list
                        Case ClaimStatusList.LOA_STU, ClaimStatusList.STD_STDSTD, ClaimStatusList.STD_POSPTD, ClaimStatusList.FML_LOAFML, ClaimStatusList.FML_POSFLI, ClaimStatusList.STD_LOAMOD, ClaimStatusList.PFL_RFLPFU,
                            ClaimStatusList.PFL_RFLPFL, ClaimStatusList.PFL_LOAPFL, ClaimStatusList.PFL_PFLPFL 'Changes for 12466
                            bAddToFeed = True
                        Case Else
                            bAddToFeed = False
                    End Select

                    ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                    '
                    '   FML CODES
                    '
                    ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

                Case ClaimStatusList.FML_LOAFML

                    'What is the current claim status?
                    Select Case oClaimStatusList
                        Case ClaimStatusList.FML_RFLFML, ClaimStatusList.FML_POSFLI
                            bAddToFeed = True 'Radar 21219 - for RFLFML, records should be written to File
                        Case ClaimStatusList.FML_RFL
                            'RTW from Not at work/Not Approved
                            oClaimStatusList = ClaimStatusList.FML_RFLFML
                            bAddToFeed = True
                        Case Else
                            bAddToFeed = False
                    End Select


                Case ClaimStatusList.FML_PLAFLI, ClaimStatusList.FML_POSFLI

                    'What is the current claim status?
                    Select Case oClaimStatusList
                        Case ClaimStatusList.FML_LOAFML, ClaimStatusList.FML_RFLFLI
                            bAddToFeed = True
                        Case ClaimStatusList.FML_RFL
                            'RTW from Not at work/Not Approved
                            oClaimStatusList = ClaimStatusList.FML_RFLFLI
                            bAddToFeed = True
                        Case Else
                            bAddToFeed = False
                    End Select

                Case ClaimStatusList.FML_RFLFML

                    'What is the current claim status?
                    Select Case oClaimStatusList
                        Case ClaimStatusList.FML_LOAFML, ClaimStatusList.FML_POSFLI
                            bAddToFeed = True
                        Case Else
                            bAddToFeed = False
                    End Select

                Case ClaimStatusList.FML_RFLFLI

                    'What is the current claim status?
                    Select Case oClaimStatusList
                        Case ClaimStatusList.FML_LOAFML, ClaimStatusList.FML_POSFLI
                            bAddToFeed = True
                        Case Else
                            bAddToFeed = False
                    End Select

                    ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                    '
                    '   PFL CODES
                    '
                    ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                    'Changes as per Epic 828496 - NY PFL Claims Addition - Start
                Case ClaimStatusList.PFL_LOAPFL
                    'What is the current claim status?
                    Select Case oClaimStatusList
                        Case ClaimStatusList.PFL_RFLPFU
                            bAddToFeed = True
                        Case ClaimStatusList.PFL_PFLPFL
                            bAddToFeed = True
                        Case ClaimStatusList.PFL_LOAPFL
                            bAddToFeed = True
                        Case Else
                            bAddToFeed = False
                    End Select

                Case ClaimStatusList.PFL_PFLPFL
                    'What is the current claim status?
                    Select Case oClaimStatusList
                        Case ClaimStatusList.PFL_RFLPFL
                            bAddToFeed = True
                        Case ClaimStatusList.PFL_PFLPFL
                            bAddToFeed = True
                        Case ClaimStatusList.PFL_LOAPFL
                            bAddToFeed = True
                        Case Else
                            bAddToFeed = False
                    End Select
                    'Case Else
                    '    Select Case oClaimStatusList
                    '        Case ClaimStatusList.PFL_LOAPFL
                    '            bAddToFeed = True
                    '        Case ClaimStatusList.PFL_PFLPFL
                    '            bAddToFeed = True
                    '        Case Else
                    '            bAddToFeed = False
                    '    End Select
                    'Changes as per Epic 828496 - NY PFL Claims Addition - End

            End Select

        Catch ex As Exception
            'Logging may be added in a later iteration.

        End Try

        Return bAddToFeed
    End Function


    'Check to see if Tansaction has already been sent on an earlier feed
    '
    Public Function TransactionAlreadySent(ByRef oRow As DataRow, ByVal sUDL As String) As Boolean
        Dim bAlreadySent As Boolean = False
        Dim oFeedHistory As New DataSet
        Dim oFeedRow As DataRow
        Dim sParam As String
        Dim sTransDate As String
        Dim sTransCode As String
        Dim sClaimID As String
        Dim sAction As String
        Dim sActionReason As String

        Try

            'Translate the reason to text
            GetActionCodes(sAction, sActionReason, CType(oRow("TransCode"), Integer))

            'Set the Parm values
            sClaimID = CType(oRow("Claim_ID"), String)
            sTransCode = sAction & sActionReason
            sTransDate = CType(oRow("EFFECTIVE_DATE"), String)

            sParam = sClaimID & "," & sTransCode & "," & sTransDate
            RunSQL(sUDL, oFeedHistory, gsPackageName & ".sp_FedExG_Get_Hist_byTrans", sParam)

            'Is there any RTW History?
            If oFeedHistory.Tables(0).Rows.Count > 0 Then
                bAlreadySent = True
                'ITL Radar 20598 If new status is LOASTU check whether STOSTO already sent Start
            Else
                If sTransCode = "LOASTU" Then
                    sTransCode = "STOSTO"
                    sParam = sClaimID & "," & sTransCode & "," & sTransDate
                    RunSQL(sUDL, oFeedHistory, gsPackageName & ".sp_FedExG_Get_Hist_byTrans", sParam)
                    If oFeedHistory.Tables(0).Rows.Count > 0 Then
                        bAlreadySent = True
                    End If
                End If
                'ITL Radar 20598 If new status is LOASTU check whether STOSTO already sent End
            End If

        Catch ex As Exception
            'Logging may be added in a later iteration.

        End Try

        Return bAlreadySent

    End Function

    'Create the new datafeed table
    Public Sub CreateDataFeedTable()

        Try
            ' Create a new DataTable.
            goTable = New DataTable("Output")

            ' Declare variables for DataColumn and DataRow objects.
            Dim myDataColumn As DataColumn
            Dim myDataRow As DataRow

            'string="15" rem="Detail Record Indicator"
            myDataColumn = New DataColumn
            myDataColumn.DataType = System.Type.GetType("System.String")
            myDataColumn.ColumnName = "DetailRecID"
            myDataColumn.ReadOnly = False
            goTable.Columns.Add(myDataColumn)

            'string="15" rem="Employee ID" - Zero padded
            myDataColumn = New DataColumn
            myDataColumn.DataType = System.Type.GetType("System.String")
            myDataColumn.ColumnName = "EmployeeID"
            myDataColumn.ReadOnly = False
            goTable.Columns.Add(myDataColumn)

            'string="15" rem="Absence Sequence Indicator"  - Zero padded. Usually 000000000000000
            myDataColumn = New DataColumn
            myDataColumn.DataType = System.Type.GetType("System.String")
            myDataColumn.ColumnName = "TransSeq"
            myDataColumn.ReadOnly = False
            goTable.Columns.Add(myDataColumn)

            'string="1" rem="Filler" - Space
            myDataColumn = New DataColumn
            myDataColumn.DataType = System.Type.GetType("System.String")
            myDataColumn.ColumnName = "filler"
            myDataColumn.ReadOnly = False
            goTable.Columns.Add(myDataColumn)

            'date="yyyyMMdd" rem="STD -> Date of Disability; FMLA -> First Day Absent"  
            myDataColumn = New DataColumn
            myDataColumn.DataType = System.Type.GetType("System.DateTime")
            myDataColumn.ColumnName = "TransDate"
            myDataColumn.ReadOnly = False
            goTable.Columns.Add(myDataColumn)

            'string="24" rem="Blank"  
            myDataColumn = New DataColumn
            myDataColumn.DataType = System.Type.GetType("System.String")
            myDataColumn.ColumnName = "blank"
            myDataColumn.ReadOnly = False
            goTable.Columns.Add(myDataColumn)

            'string="3" rem="Action  			ie. STO/STD/PLA etc."  
            myDataColumn = New DataColumn
            myDataColumn.DataType = System.Type.GetType("System.String")
            myDataColumn.ColumnName = "Action"
            myDataColumn.ReadOnly = False
            goTable.Columns.Add(myDataColumn)

            'string="3" rem="Action Reason ie. STO/STD/PTD etc."  
            myDataColumn = New DataColumn
            myDataColumn.DataType = System.Type.GetType("System.String")
            myDataColumn.ColumnName = "ActionReason"
            myDataColumn.ReadOnly = False
            goTable.Columns.Add(myDataColumn)

        Catch ex As Exception
        End Try
    End Sub



    'RTW_Status	RTW_Reason	Work_Status	Work_Status_Desc
    Public Sub SetVariables(ByVal oRow As DataRow, ByRef oRTWStatus As DataExtractClasses.RTWStatus, ByRef oRTWReason As DataExtractClasses.RTWReason, ByRef oWorkStatus As DataExtractClasses.WorkStatus, ByRef oWorkStatusDesc As DataExtractClasses.WorkStatusDesc,
                            ByRef oPackageHandler As Boolean)
        Try

            'Set the RTW_Status
            Select Case CType(oRow("RTW_Status"), String).ToUpper

                Case "APPROVED"
                    oRTWStatus = RTWStatus.Approved
                Case "PEND"
                    oRTWStatus = RTWStatus.Pend
                Case "DENIED"
                    oRTWStatus = RTWStatus.Denied
                Case "TERMINATED"
                    oRTWStatus = RTWStatus.Terminated
                Case "CANCELLED"
                    oRTWStatus = RTWStatus.Cancelled
            End Select

            'Set the RTW_Reason
            If CType(oRow("RTW_Reason"), String) = "Administrative" Then
                oRTWReason = RTWReason.Administrative
            ElseIf CType(oRow("RTW_Reason"), String) = "ClaimWithdrawn" Then
                oRTWReason = RTWReason.ClaimWithdrawn
            ElseIf CType(oRow("RTW_Reason"), String) = "ClientRequest" Then
                oRTWReason = RTWReason.ClientRequest
            ElseIf CType(oRow("RTW_Reason"), String) = "Death" Then
                oRTWReason = RTWReason.Death
            ElseIf CType(oRow("RTW_Reason"), String) = "DisNotSupported" Then
                oRTWReason = RTWReason.DisNotSupported
            ElseIf CType(oRow("RTW_Reason"), String) = "DisabilitySupported" Then
                oRTWReason = RTWReason.DisabilitySupported
            ElseIf CType(oRow("RTW_Reason"), String) = "Employee" Then
                oRTWReason = RTWReason.Employee
            ElseIf CType(oRow("RTW_Reason"), String) = "Employer" Then
                oRTWReason = RTWReason.Employer
            ElseIf CType(oRow("RTW_Reason"), String) = "Maintenance" Then
                oRTWReason = RTWReason.Maintenance
            ElseIf CType(oRow("RTW_Reason"), String) = "MaxBenefits" Then
                oRTWReason = RTWReason.MaxBenefits
            ElseIf CType(oRow("RTW_Reason"), String) = "Medical" Then
                oRTWReason = RTWReason.Medical
            ElseIf CType(oRow("RTW_Reason"), String) = "NewClaim" Then
                oRTWReason = RTWReason.NewClaim
            ElseIf CType(oRow("RTW_Reason"), String) = "NoLongerEmployByComp" Then
                oRTWReason = RTWReason.NoLongerEmployByComp
            ElseIf CType(oRow("RTW_Reason"), String) = "NoMedsReceived" Then
                oRTWReason = RTWReason.NoMedsReceived
            ElseIf CType(oRow("RTW_Reason"), String) = "Noncompliance" Then
                oRTWReason = RTWReason.Noncompliance
            ElseIf CType(oRow("RTW_Reason"), String) = "NotEligible" Then
                oRTWReason = RTWReason.NotEligible
            ElseIf CType(oRow("RTW_Reason"), String) = "PreExistingCondition" Then
                oRTWReason = RTWReason.PreExistingCondition
            ElseIf CType(oRow("RTW_Reason"), String) = "Relapse" Then
                oRTWReason = RTWReason.Relapse
            ElseIf CType(oRow("RTW_Reason"), String) = "Retired" Then
                oRTWReason = RTWReason.Retired
            ElseIf CType(oRow("RTW_Reason"), String) = "ReturnToWork" Then
                oRTWReason = RTWReason.ReturnToWork
            ElseIf CType(oRow("RTW_Reason"), String) = "Settlement" Then
                oRTWReason = RTWReason.Settlement
            ElseIf CType(oRow("RTW_Reason"), String) = "StableAndMature" Then
                oRTWReason = RTWReason.StableAndMature
            ElseIf CType(oRow("RTW_Reason"), String) = "Reinstated" Then
                oRTWReason = RTWReason.Reinstated
            ElseIf CType(oRow("RTW_Reason"), String) = "Certification" Then
                oRTWReason = RTWReason.Certification
            ElseIf CType(oRow("RTW_Reason"), String) = "Certified" Then
                oRTWReason = RTWReason.Certified
            ElseIf CType(oRow("RTW_Reason"), String) = "Bonding" Then
                oRTWReason = RTWReason.Bonding
            ElseIf CType(oRow("RTW_Reason"), String) = "NoRequirements" Then
                oRTWReason = RTWReason.NoRequirements
            ElseIf CType(oRow("RTW_Reason"), String) = "NoCert" Then
                oRTWReason = RTWReason.NoCert
            ElseIf CType(oRow("RTW_Reason"), String) = "Takeover" Then
                oRTWReason = RTWReason.Takeover
            ElseIf CType(oRow("RTW_Reason"), String) = "MedicalMngt" Then
                oRTWReason = RTWReason.MedicalMngt
            ElseIf CType(oRow("RTW_Reason"), String) = "Conversion" Then
                oRTWReason = RTWReason.Conversion
            End If

            'Set the Work Status
            Select Case CType(oRow("Work_Status"), String).ToUpper
                Case "ATWORK"
                    oWorkStatus = WorkStatus.ATWORK
                Case "NOTATWORK"
                    oWorkStatus = WorkStatus.NOTATWORK
                Case "RELEASETORTW"
                    oWorkStatus = WorkStatus.RELEASEDTORTW
            End Select


            'Store the work status description
            Select Case CType(oRow("Work_Status_Desc"), String).ToUpper
                Case "FULLDUTY"
                    'fullduty
                    oWorkStatusDesc = WorkStatusDesc.FULLDUTY
                Case "RESTRICTED"
                    'partial duty
                    oWorkStatusDesc = WorkStatusDesc.PARTIALDUTY
                    'Changes for 12466 Start
                Case "PHYSICALRESTRICTIONS"
                    oWorkStatusDesc = WorkStatusDesc.MODJOBABILITY
                    'Changes for 12466 End
                Case Else
                    'The value must be null
                    oWorkStatusDesc = WorkStatusDesc.NULL
            End Select

            'Epic 1015206 04/04/2019 Changes Start
            Select Case CType(oRow("Package_Handler"), String).ToUpper
                Case "TRUE"
                    oPackageHandler = True
                Case Else
                    oPackageHandler = False
            End Select
            'Change End

        Catch ex As Exception

        End Try
    End Sub


    'Private Function RunSQL(ByVal sUDLFile As String, ByRef dsData As DataSet, ByVal sSQL As String, ByVal sParamsInput As String, Optional ByVal sQueryName As String = "", Optional ByVal bExecuteOnly As Boolean = False) As Boolean
    '    'Take the passed sql and params, run them and populate the passed dataset
    '    Dim sParams() As String
    '    Dim strTemp
    '    Dim intIndex As Short

    '    Dim objCon As OleDbConnection = New OleDbConnection("File Name=" & sUDLFile & ";")
    '    Dim objCommand As OleDbCommand = New OleDbCommand("Lee", objCon)
    '    Dim daData As OleDbDataAdapter = New OleDbDataAdapter(objCommand)

    '    RunSQL = True
    '    daData.SelectCommand = objCommand
    '    Try
    '        objCon.Open()
    '    Catch objExAlreadyOpen As InvalidOperationException
    '        'connection is already open, use it
    '    Catch objException As Exception
    '        'can't make a connection, fail out
    '        'LogError(objException, "RunSQL")
    '        RunSQL = False
    '        Exit Function
    '    End Try
    '    'LAR 04/29/2003 
    '    'check flag for execute-only
    '    If sParamsInput = "ExecuteOnly" Then
    '        bExecuteOnly = True
    '        sParamsInput = ""
    '    End If
    '    'LAR 04/29/2003 - end
    '    'if it is a stored proc, then we have to collect the params and process them as well
    '    If (UCase(Left(sSQL, 2)) = "PK" Or UCase(Left(sSQL, 2)) = "SP") Then
    '        If sParamsInput <> "" And bExecuteOnly = False Then
    '            sParams = Split(sParamsInput, ",")
    '            'loop thru all params in the file and construct the param list
    '            For intIndex = 0 To UBound(sParams)
    '                strTemp = strTemp + IIf(Len(strTemp) = 0, "'" & Trim(sParams(intIndex)) & "'", ", '" & Trim(sParams(intIndex)) & "'")
    '            Next intIndex
    '        Else
    '            strTemp = sParamsInput
    '        End If
    '        'build the oracle command string
    '        objCommand.CommandText = "{CALL " & sSQL & "(" & strTemp & ")}"
    '    Else
    '        'if it is just a simple sql statement, execute it directly
    '        objCommand.CommandText = sSQL
    '    End If

    '    'Execute statement
    '    'LAR 04/29/2003 
    '    If bExecuteOnly Then
    '        Try
    '            Dim iRowsAffected As Integer = objCommand.ExecuteNonQuery()
    '        Catch objException As Exception
    '            'LogError(objException, "RunSQL")
    '            RunSQL = False
    '            Exit Function
    '        End Try
    '    Else
    '        Try
    '            daData.Fill(dsData)
    '        Catch objException As Exception
    '            'LogError(objException, "RunSQL")
    '            RunSQL = False
    '            Exit Function
    '        End Try
    '    End If
    '    'LAR 04/29/2003 - end
    '    objCommand = Nothing
    '    objCon.Close()

    'End Function


    'Changes for RADAR 13330- Rewritting new RunSQL which will use support.dll
    Private Function RunSQL(ByVal sUDLFile As String, ByRef dsData As DataSet, ByVal sSQL As String, ByVal sParamsInput As String, Optional ByVal sQueryName As String = "", Optional ByVal bExecuteOnly As Boolean = False) As Boolean
        Dim sParams() As String
        Dim i, index As Integer
        Dim daObj As wkab.Support.DataAccess
        Dim dt, dtTemp As DataTable

        Try
            sUDLFile = sUDLFile.ToUpper()
            If (sUDLFile.Contains("WKABOLEDB.UDL") Or sUDLFile = "AETHPROD") Then
                sUDLFile = "AETHPROD"
            ElseIf (sUDLFile.Contains("WKABOLEDB_DEV2.UDL") Or sUDLFile = "AETHDEV2") Then
                sUDLFile = "AETHDEV2"
            ElseIf (sUDLFile.Contains("WKABOLEDB_STG1.UDL") Or sUDLFile = "AETHSTG1") Then
                sUDLFile = "AETHSTG1"
            ElseIf (sUDLFile = "AETHDEV1" Or sUDLFile.Contains("WKABOLEDB_DEV1.UDL")) Then
                sUDLFile = "AETHDEV1"
            ElseIf (sUDLFile = "AETHDEV3" Or sUDLFile.Contains("WKABOLEDB_DEV3.UDL")) Then
                sUDLFile = "AETHDEV3"
            ElseIf (sUDLFile = "AETHSTG2" Or sUDLFile.Contains("WKABOLEDB_STG2.UDL")) Then
                sUDLFile = "AETHSTG2"
            ElseIf (sUDLFile = "AETHQA1" Or sUDLFile.Contains("WKABOLEDB_QA1.UDL")) Then
                sUDLFile = "AETHQA1"
            ElseIf (sUDLFile = "AETHQA2" Or sUDLFile.Contains("WKABOLEDB_QA2.UDL")) Then
                sUDLFile = "AETHQA2"
            ElseIf (sUDLFile = "AETHQA3" Or sUDLFile.Contains("WKABOLEDB_QA3.UDL")) Then
                sUDLFile = "AETHQA3"
            ElseIf (sUDLFile = "AETHSTRS") Then
                sUDLFile = "AETHSTRS"
            ElseIf (sUDLFile = "AETHTRG1") Then
                sUDLFile = "AETHTRG1"
            ElseIf (sUDLFile = "AETHTRG2") Then
                sUDLFile = "AETHTRG2"
            End If

            If sParamsInput = "ExecuteOnly" Then
                bExecuteOnly = True
                sParamsInput = ""
            End If

            daObj = New wkab.Support.DataAccess(sUDLFile)
            'New change for changing the default value of 230 harcoded in Support.dll
            'as some of the feeds might take more than 230 sec to be generated
            daObj.CommandTimeOutValueChange = 500

            sParams = Split(sParamsInput, ",")
            index = sParams.Length

            If sParamsInput <> "" Then
                For i = 0 To index - 1
                    daObj.AddParameter(sParams(i))
                Next
            End If

            If bExecuteOnly = True Or sSQL.Contains("sp_FedExG_Insert_Feed_History") Then
                daObj.ExecuteSP(sSQL)
            Else
                dt = daObj.ExecuteQueryRefCursor(sSQL)
                dtTemp = dt.Copy()
                dsData.Tables.Add(dtTemp)
            End If
            RunSQL = True
        Catch ex As Exception
            RunSQL = False
        End Try
    End Function


    '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
    '          FFFFFFFFF     MMMM      MMMM      LL
    '          FF            MMMMM    MMMMM      LL
    '          FF            MM  MM  MM  MM      LL
    '          FFFFFFF       MM    MM    MM      LL
    '          FF            MM          MM      LL
    '          FF            MM          MM      LL
    '          FF            MM          MM      LLLLLLLLL
    '          
    '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

    'Process an FML Record
    Public Sub ProcessFMLClaims(ByVal dtRundate As Date, ByVal dtLastRunDate As Date, ByVal sUDL As String)
        Dim oFMLStatus As ClaimStatusList
        Dim oFMLClaim As New DataSet
        Dim oRow As DataRow
        Dim oTable As DataTable
        Dim lPreviousLeaveID As Long

        Try

            'Load the FML Claims
            LoadFMLClaims(oFMLClaim, dtRundate, dtLastRunDate, sUDL)

            'Were any LOA claims loaded?
            If Not (oFMLClaim Is Nothing) Then
                If oFMLClaim.Tables.Count > 0 Then

                    'Set the source table
                    oTable = oFMLClaim.Tables(0)

                    'Loop through the dataset to process each Claim
                    For Each oRow In oTable.Rows

                        oFMLStatus = ProcessFMLRecord(oRow, dtRundate, dtLastRunDate, sUDL)

                        'Update the Previous Claim ID
                        lPreviousLeaveID = CType(oRow("CLAIM_ID"), Long)

                    Next
                End If
            End If

        Catch ex As Exception

        End Try
    End Sub


    Private Sub LoadFMLClaims(ByRef oFMLClaim As DataSet, ByVal dtRundate As Date, ByVal dtLastRunDate As Date, ByVal sUDL As String)

        Dim oPreviousState As ClaimStatusList
        Dim sGetFMLClaim As String
        Dim sParam As String
        Dim sRundate As String
        Dim sLastRundate As String

        Try

            '   PROCEDURE sp_FedExG_Get_LOA_Changes (
            'i_RunDate	    IN  VARCHAR2,
            'i_LastRunDate	IN  VARCHAR2,
            'cur_ReturnData	OUT refcur_Output

            'Set the stored procedure name
            sGetFMLClaim = gsPackageName & ".sp_FedExG_Get_LOA_Changes"

            'Set the parameter list
            'sRundate = dtRundate.ToShortDateString
            'sLastRundate = dtLastRunDate.ToShortDateString
            'sParam = sRundate & "," & sLastRundate
            sParam = dtRundate & "," & dtLastRunDate & "," & gsRunType   '  use full date format  -  time needed for temp code

            'Call the stored procedure to get the history list
            RunSQL(sUDL, oFMLClaim, sGetFMLClaim, sParam)

        Catch ex As Exception
        End Try

    End Sub

    'Process an FML Record
    Public Function ProcessFMLRecord(ByRef oRow As DataRow, ByVal dtRundate As String, ByVal dtLastRunDate As String, ByVal sUDL As String)
        Dim oFMLPreviousStatus As ClaimStatusList
        Dim oFMLStatus As ClaimStatusList
        Dim iRecType As Integer
        Dim sLeaveID As String
        Dim bPackageHandler As Boolean = False 'Epic 1015206

        Try

            'Store the record type
            iRecType = CType(oRow("RecType"), Long)
            sLeaveID = CType(oRow("CLAIM_ID"), String)

            'Epic 1015206 04/04/2019 Changes Start
            Select Case CType(oRow("Package_Handler"), String).ToUpper
                Case "TRUE"
                    bPackageHandler = True
                Case Else
                    bPackageHandler = False
            End Select
            'Change End


            'What is the state of the current claim?
            If iRecType = 1 Then 'Leave open During Cycle FDA + 7

                'Get the previously status for this record
                oFMLPreviousStatus = GetPreviousStatus(sLeaveID, dtRundate, dtLastRunDate, sUDL)

                'Determine the Claim's current Status 
                oFMLStatus = DetermineFMLStatus(oRow, oFMLPreviousStatus, dtRundate, dtLastRunDate, sUDL)


            ElseIf iRecType = 2 Then 'Leave Open Prior to Cycle FDA + 7

                'Get the previously status for this record
                oFMLPreviousStatus = GetPreviousStatus(sLeaveID, dtRundate, dtLastRunDate, sUDL)

                'Determine the Claim's current Status 
                oFMLStatus = DetermineFMLStatus(oRow, oFMLPreviousStatus, dtRundate, dtLastRunDate, sUDL)

            ElseIf iRecType = 3 Then 'Intermittent Leave Close
                'Get the previously status for this record
                oFMLPreviousStatus = GetPreviousStatus(sLeaveID, dtRundate, dtLastRunDate, sUDL)

                'Determine the Claim's current Status 
                oFMLStatus = DetermineFMLStatus(oRow, oFMLPreviousStatus, dtRundate, dtLastRunDate, sUDL)

            ElseIf iRecType = 4 Then 'Continuous Leave Close

                'Get the previously status for this record
                oFMLPreviousStatus = GetPreviousStatus(sLeaveID, dtRundate, dtLastRunDate, sUDL)

                'Determine the Claim's current Status 
                oFMLStatus = DetermineFMLStatus(oRow, oFMLPreviousStatus, dtRundate, dtLastRunDate, sUDL)

            End If

        Catch ex As Exception

        End Try
    End Function


    'Determine the Claim's current Status 
    Public Function DetermineFMLStatus(ByRef oRow As DataRow, ByVal oFMLPreviousStatus As ClaimStatusList, ByVal dtRundate As String, ByVal dtLastRundate As String, ByVal sUDL As String) As ClaimStatusList

        Dim oRTWHistory As New DataSet
        Dim oLOAStatusList As ClaimStatusList
        Dim sAction As String
        Dim oRTWRow As DataRow
        Dim sParam As String
        Dim sProductID As String
        Dim sLeaveContinuity As String
        Dim sLeaveAction As String 'ITL Radar 20598 Dt: 10/20/2014 For leave action status
        Dim bPackageHandler As Boolean = False 'Epic 1015206

        Try

            sProductID = "6001" 'LOA Product Code

            'What is the current Status?
            sAction = CType(oRow("Status"), String).ToUpper
            sLeaveContinuity = CType(oRow("leave_continuity"), String).ToUpper
            sLeaveAction = CType(oRow("ACTION_NAME"), String).ToUpper   'ITL Radar 20598 Dt: 10/20/2014 Get leave action status
            'Epic 1015206 04/04/2019 Changes Start
            Select Case CType(oRow("Package_Handler"), String).ToUpper
                Case "TRUE"
                    bPackageHandler = True
                Case Else
                    bPackageHandler = False
            End Select
            'Change End

            'What is the current Action?
            Select Case sAction
                Case "OPEN"

                    'Is this continuous?
                    If sLeaveContinuity = "C" Then
                        'ITL Radar 20598 Dt: 10/20/2014 Set status Start
                        If gsIsParallel = "TRUE" Then
                            If sLeaveAction = "APPROVED" Then
                                oLOAStatusList = ClaimStatusList.FML_LOAFML
                            ElseIf sLeaveAction = "PENDED" And Not bPackageHandler Then
                                oLOAStatusList = ClaimStatusList.LOA_STU
                            End If
                        Else
                            oLOAStatusList = ClaimStatusList.FML_LOAFML
                        End If
                        'oLOAStatusList = ClaimStatusList.FML_LOAFML
                        'ITL Radar 20598 Dt: 10/20/2014 Set status End
                    ElseIf sLeaveContinuity = "I" Then
                        'ITL Radar 20598 Dt: 10/20/2014 All PLA will become POS - for Parallel file Start
                        If gsIsParallel = "TRUE" Then
                            oLOAStatusList = ClaimStatusList.FML_POSFLI
                        Else
                            If Not bPackageHandler Then 'Epic 1015206 04/05/2019
                                oLOAStatusList = ClaimStatusList.FML_PLAFLI
                            End If
                        End If
                        'ITL Radar 20598 Dt: 10/20/2014 All PLA will become POS - for Parallel file End
                    Else
                        oLOAStatusList = ClaimStatusList.NULL
                    End If

                Case "CLOSED"
                    If Not bPackageHandler Then ' Epic 1015206 04/08/2019
                        'Is this continuous?
                        If sLeaveContinuity = "C" Then
                            oLOAStatusList = ClaimStatusList.FML_RFLFML
                        ElseIf sLeaveContinuity = "I" Then
                            oLOAStatusList = ClaimStatusList.FML_RFLFLI
                        Else
                            oLOAStatusList = ClaimStatusList.NULL
                        End If
                    End If

            End Select

            'Should we add this record to the data feed?
            'ITL Radar 20598 Dt: 10/27/2014 AddToParallel function for Parallel and PROD Start
            If gsIsParallel = "TRUE" Then
                If AddToDataFeedParallel(oFMLPreviousStatus, oLOAStatusList, isSTDRecord(oRow)) = True Then
                    oRow("TransCode") = oLOAStatusList
                    oRow("SaveFlag") = 1
                Else
                    oRow("SaveFlag") = 0
                End If
            Else
                If AddToDataFeed(oFMLPreviousStatus, oLOAStatusList) = True Then
                    oRow("TransCode") = oLOAStatusList
                    oRow("SaveFlag") = 1
                Else
                    oRow("SaveFlag") = 0
                End If
            End If
            'Original Code Start
            'If AddToDataFeed(oFMLPreviousStatus, oLOAStatusList) = True Then
            '    oRow("TransCode") = oLOAStatusList
            '    oRow("SaveFlag") = 1
            'Else
            '    oRow("SaveFlag") = 0
            'End If
            'Original Code End
            'ITL Radar 20598 Dt: 10/27/2014 AddToParallel function for Parallel and PROD End

            If oRow("SaveFlag") = 1 Then
                If TransactionAlreadySent(oRow, sUDL) Then
                    oRow("SaveFlag") = 0
                End If
            End If

            If oRow("SaveFlag") = 1 Then

                'If TRUE then add to the datafeed
                AddRowToDataFeed(oRow)

                'Add this status to the history table and update the previous status
                AddRowToHistoryTable(oRow, sUDL, sProductID)
                oFMLPreviousStatus = oLOAStatusList
            End If

        Catch ex As Exception

        End Try

        'Return oClaimStatus
    End Function

    '***************  10/30
    ''Determine the FML Type
    'Public Function DetermineFMLStatus(ByRef oRow As DataRow, ByVal dtRundate As String, ByVal dtLastRundate As String, ByVal sUDL As String) As ClaimStatusList
    '    Dim oSTDStatus As ClaimStatusList
    '    Dim lLeaveID As Long
    '    Dim sRunDate As String
    '    Dim sLastRunDate As String
    '    Dim sParam As String
    '    Dim oRTWHistory As New DataSet
    '    Dim oRTWRow As DataRow

    '    Try

    '        'Load the RTW Records
    '        lLeaveID = CType(oRow("CLAIM_ID"), Long)
    '        sRunDate = dtRundate.ToString
    '        sLastRunDate = dtLastRundate.ToString

    '        'i_claimid       IN  s_dis_claim.claim_id%TYPE,
    '        'i_RunDate	IN  VARCHAR2,
    '        'i_LastRunDate	IN  VARCHAR2,
    '        sParam = lLeaveID.ToString & "," & sRunDate & "," & sLastRunDate
    '        RunSQL(sUDL, oRTWHistory, gsPackageName & ".sp_FedExG_Get_STD_Activity", sParam)

    '        'Is there any RTW History?
    '        If oRTWHistory.Tables(0).Rows.Count > 0 Then

    '            'loop through all the rows
    '            For Each oRTWRow In oRTWHistory.Tables(0).Rows


    '            Next

    '        End If


    '        'Is this an LOA/FML
    '        'oSTDStatus = ClaimStatusList.FML_LOAFML

    '        ''Is this an PLA/FLI
    '        'oSTDStatus = ClaimStatusList.FML_PLAFLI

    '        ''Is this an RFL/FML
    '        'oSTDStatus = ClaimStatusList.FML_RFLFML

    '        ''Is this an RFLFRI
    '        'oSTDStatus = ClaimStatusList.FML_RFLFLI

    '    Catch ex As Exception

    '    End Try
    'End Function

    '*****************   10/30 
    'Add a new row to the datafeed
    'Private Sub AddFMLRowToDataFeed(ByVal oRow As DataRow, ByVal oClaimStatusList As ClaimStatusList)
    '    Dim oDataRow As DataRow
    '    Dim sAction As String
    '    Dim sActionReason As String

    '    Try
    '        GetActionCodes(sAction, sActionReason, oClaimStatusList)

    '        'Only add the record if the codes are valid
    '        If sAction.Length > 0 And sActionReason.Length > 0 Then
    '            oDataRow = goTable.NewRow()
    '            oDataRow("DetailRecID") = "D" & Space(14)
    '            oDataRow("EmployeeID") = CType(oRow("EMP_ID"), String).Replace("-", "").PadLeft(15, "0")
    '            oDataRow("TransSeq") = "000000000000000"
    '            oDataRow("filler") = " " 'filler

    '            'This value needs to be calculated based on the action code and action reason
    '            oDataRow("TransDate") = CType(oRow("Effective_Date"), Date).ToShortDateString  'First Day Absent


    '            oDataRow("blank") = Space(24) '24 Spaces
    '            oDataRow("Action") = sAction
    '            oDataRow("ActionReason") = sActionReason

    '            'Add a new row to the dataset
    '            goTable.Rows.Add(oDataRow)
    '        End If

    '    Catch ex As Exception

    '    End Try
    'End Sub


    'Changes as per Epic 828496 - NY PFL Claims Addition - Start

    'Process PFL record

    Public Sub ProcessPFLClaims(ByVal dtRundate As Date, ByVal dtLastRunDate As Date, ByVal sUDL As String)
        Dim oPFLStatus As ClaimStatusList
        Dim oPFLClaim As New DataSet
        Dim oRow As DataRow
        Dim oTable As DataTable
        Dim lPreviousLeaveID As Long

        Try

            'Load the PFL Claims
            LoadPFLClaims(oPFLClaim, dtRundate, dtLastRunDate, sUDL)

            'Were any LOA claims loaded?
            If Not (oPFLClaim Is Nothing) Then
                If oPFLClaim.Tables.Count > 0 Then

                    'Set the source table
                    oTable = oPFLClaim.Tables(0)

                    'Loop through the dataset to process each Claim
                    For Each oRow In oTable.Rows

                        oPFLStatus = ProcessPFLRecord(oRow, lPreviousLeaveID, dtRundate, dtLastRunDate, sUDL)

                        'Update the Previous Claim ID
                        lPreviousLeaveID = CType(oRow("CLAIM_ID"), Long)

                    Next
                End If
            End If

        Catch ex As Exception

        End Try
    End Sub
    Public Function ProcessPFLRecord(ByRef oRow As DataRow, ByRef lPreviousClaimID As Long, ByVal dtRundate As Date, ByVal dtLastRunDate As Date, ByVal sUDL As String)
        Dim oPFLPreviousStatus As ClaimStatusList
        Dim oPFLStatus As ClaimStatusList
        Dim sClaimID As String
        Dim sRecType As String
        Dim sRundate As String
        Dim sLastRundate As String
        Dim iRecType As Integer


        Try

            iRecType = CType(oRow("RecType"), Long)
            sClaimID = CType(oRow("Claim_ID"), String)
            sRundate = dtRundate.ToShortDateString
            sLastRundate = dtLastRunDate.ToShortDateString


            'What is the state of the current claim?
            'Get the previous status for this record
            oPFLPreviousStatus = GetPreviousStatus(sClaimID, dtRundate, dtLastRunDate, sUDL) 'Generic function

            If oPFLPreviousStatus = ClaimStatusList.NULL Then
                sRecType = "1"      'Claim is new  -  no history
            Else
                sRecType = "2"      ' Claim is not new - has history
            End If

            'Determine the Claim's current Status 
            oPFLStatus = DeterminePFLStatus(oRow, oPFLPreviousStatus, sRundate, sLastRundate, sUDL, sRecType)

        Catch ex As Exception

        End Try
    End Function

    Private Sub LoadPFLClaims(ByRef oPFLClaim As DataSet, ByVal dtRundate As Date, ByVal dtLastRunDate As Date, ByVal sUDL As String)

        Dim sGetPFLClaim As String
        Dim sParam As String

        Try

            'Set the stored procedure name
            sGetPFLClaim = gsPackageName & ".sp_FedExG_Get_PFL_Changes"
            sParam = dtRundate & "," & dtLastRunDate & "," & gsRunType   '  use full date format  -  time needed for temp code

            'Call the stored procedure to get the history list
            RunSQL(sUDL, oPFLClaim, sGetPFLClaim, sParam)

        Catch ex As Exception
        End Try

    End Sub

    Public Function DeterminePFLStatus(ByRef oRow As DataRow, ByVal oPFLPreviousStatus As ClaimStatusList, ByVal dtRundate As Date, ByVal dtLastRundate As Date, ByVal sUDL As String, ByVal sRecType As String) As ClaimStatusList

        Dim oRTWHistory As New DataSet
        Dim oClaimStatusList As ClaimStatusList
        Dim lClaimID As Long
        Dim oRTWStatus As RTWStatus
        Dim oRTWReason As RTWReason
        Dim oWorkStatus As WorkStatus
        Dim oWorkStatusDesc As WorkStatusDesc
        Dim sRunDate As String
        Dim sLastRunDate As String
        Dim sProductID As String
        Dim bNoSaveStoSto As Boolean = False 'don't save the STOSTO record, if there is a STDSTD record
        Dim iRowLastRFL As Integer = -1 'the row number of the last RFP record (should be first record in output)
        Dim iRowCounter As Integer = 0 'current row number 
        Dim bPackageHandler As Boolean = False 'Epic 1015206

        Try

            'Load the RTW Records
            lClaimID = CType(oRow("Claim_ID"), Long)
            sRunDate = dtRundate.ToShortDateString
            sLastRunDate = dtLastRundate.ToShortDateString
            sProductID = oRow("Product_ID")

            SetVariables(oRow, oRTWStatus, oRTWReason, oWorkStatus, oWorkStatusDesc, bPackageHandler) ' Epic 1015206 04/05/2019 Added Package Handle parameter

            If Not bPackageHandler Then 'Epic 1015206 04/05/2019
                If oRTWStatus = RTWStatus.Denied Or oRTWReason = RTWReason.DisNotSupported Then  'Technical Scenario 2
                    If oWorkStatus = WorkStatus.ATWORK Or oWorkStatus = WorkStatus.RELEASEDTORTW Then
                        If oWorkStatusDesc = WorkStatusDesc.FULLDUTY Then
                            oClaimStatusList = ClaimStatusList.PFL_RFLPFU
                        End If
                    End If
                End If

            If oRTWStatus = RTWStatus.Denied Or oRTWStatus = RTWStatus.Pend Or oRTWStatus = RTWStatus.Terminated Or oRTWStatus = RTWStatus.Cancelled Or oRTWStatus = RTWStatus.Suspended Then
                If oWorkStatus = WorkStatus.NOTATWORK Then 'Technical Scenario 1
                    Select Case oRTWReason
                        Case RTWReason.NewClaim, RTWReason.Relapse
                            oClaimStatusList = ClaimStatusList.PFL_LOAPFL
                    End Select
                End If
            End If



                If oRTWStatus = RTWStatus.Approved Or oRTWStatus = RTWStatus.Terminated Then
                    If oWorkStatus = WorkStatus.ATWORK Or oWorkStatus = WorkStatus.RELEASEDTORTW Then
                        If oWorkStatusDesc = WorkStatusDesc.FULLDUTY Then
                            oClaimStatusList = ClaimStatusList.PFL_RFLPFL 'Technical Scenario 4
                        End If
                    End If
                End If
            End If


            If oRTWStatus = RTWStatus.Approved Then
                If oWorkStatus = WorkStatus.NOTATWORK Then
                    oClaimStatusList = ClaimStatusList.PFL_PFLPFL 'Technical Scenario 3
                End If
            End If


            If gsIsParallel = "TRUE" Then
                If AddToDataFeedParallel(oPFLPreviousStatus, oClaimStatusList, isPFLRecord(oRow)) = True Then 'AddToDataFeedParallel - Generic function
                    oRow("TransCode") = oClaimStatusList
                    oRow("SaveFlag") = 1
                    oPFLPreviousStatus = oClaimStatusList
                End If
            Else
                If AddToDataFeed(oPFLPreviousStatus, oClaimStatusList) = True Then 'AddToDataFeed - Generic function
                    oRow("TransCode") = oClaimStatusList
                    oRow("SaveFlag") = 1
                    oPFLPreviousStatus = oClaimStatusList
                End If
            End If

            ' Check to see if this code with this date has already been sent
            If TransactionAlreadySent(oRow, sUDL) Then 'TransactionAlreadySent - Generic 
                oRow("SaveFlag") = 0
            End If

            If oRow("SaveFlag") = 1 Then

                'If TRUE then add to the datafeed
                AddRowToDataFeed(oRow)

                'Add this status to the history table and update the previous status
                AddRowToHistoryTable(oRow, sUDL, sProductID)

            End If

        Catch ex As Exception

        End Try

        Return oClaimStatusList
    End Function
    'Changes as per Epic 828496 - NY PFL Claims Addition - End
End Class

