Public Class clsUtilityFunctions
   Public Function fGiveVersion() As String
      fGiveVersion = System.Reflection.Assembly.GetExecutingAssembly().GetName().Version.ToString()
   End Function

   Public Function FlattenDataset(ByRef dsData As DataSet, Optional ByVal iDepth As Integer = 1) As Boolean

      'this function will take a dataset and flatten it, by stringing all the rows
      'in it into one big long row. The iDepth argument gives a default depth, 
      'ie if the ds has 3 rows and the arg is 5, it will add 2 extra 'rows' to the
      'new row.

      Dim sColumnNames As String()
      Dim iCount As Integer
      Dim tblTableNew As DataTable = New DataTable()
      Dim row As DataRow

      'add any required empty rows
      If dsData.Tables(0).Rows.Count < iDepth Then
         For iCount = 0 To (iDepth - dsData.Tables(0).Rows.Count - 1)
            row = dsData.Tables(0).NewRow()
            dsData.Tables(0).Rows.Add(row)
         Next
      End If

      iCount = 0
      'create columns to match the datatypes of the incoming dataset
      For Each row In dsData.Tables(0).Rows
         Dim col As DataColumn, newCol As DataColumn
         For Each col In dsData.Tables(0).Columns
            'add a col
            newCol = New DataColumn()
            If row(col).GetType.FullName = "System.DBNull" Then
               newCol.DataType = Type.GetType("System.String")
            Else
               newCol.DataType = row(col).GetType
            End If
            newCol.ColumnName = "Col" & CStr(iCount)
            tblTableNew.Columns.Add(newCol)
            'newCol = tblTableNew.Columns.Add("Col" & CStr(iCount), row(col).GetType)
            iCount += 1
         Next
      Next

      'copy the data from the original table to the new one
      iCount = 0
      row = tblTableNew.NewRow()
      tblTableNew.Rows.Add(row)
      For Each row In dsData.Tables(0).Rows
         Dim col As DataColumn, newCol As DataColumn
         For Each col In dsData.Tables(0).Columns
            'set the value
            tblTableNew.Rows(0)("Col" & CStr(iCount)) = row(col)
            iCount += 1
         Next
      Next

      'now drop the old table and replace it with the new.
      dsData.Tables.Remove(dsData.Tables(0))
      dsData.Tables.Add(tblTableNew)

   End Function

    Public Function FilterOnDate(ByRef dsData As System.Data.DataSet, ByVal sDateCol As String, ByVal oCriterion As Object) As Boolean
        'this function will remove rows from the passed dataset where values
        'in the passed column name are outside the criterion passed.
        'ie if atd is older than the passed number of days.
        'Feel free to extend it, just be mindful of feeds already calling it.

    End Function

    Function ReplaceChars(ByVal sInString As String, ByVal sCharIn As String, ByVal sCharOut As String) As String
        'LAR 10/17/2003
        'just a wrapper fn on the native replace fn...
        'at some point we ought to put in the ability to specify a native fn for a subquery...

        'Return sInString.Replace(sCharIn, sCharOut)
        Dim sTemp As String = Replace(sInString, sCharIn, sCharOut)
        Return sTemp

    End Function

    Public Function GetEpisodeDays(ByVal sEpisodeId As String) As Integer
        'given the i of an episode, return the total number of approved days in it.

        Dim dsData As New System.Data.DataSet()
        Dim oAvon As New clsAvonClaimFeed()
        Dim sSQL As String
        Dim iNumDays As Integer = 0

        sSQL &= " select s_toccase.i, asd, atd, (atd - asd + 1) as date_diff "
        sSQL &= " from s_toccase, s_tocprocessinstance,  s_tocprocessstep "
        sSQL &= " where s_toccase.i_ocactvty_resultingacti = s_tocprocessinstance.i "
        sSQL &= " 	AND s_tocprocessinstance.i_ocprostp_currentstepof = s_tocprocessstep.i"
        sSQL &= " 	and guistepname in ('Approved', 'Closed') "
        sSQL &= " 	and ( (I_OCCASE_CHILDCASES = " & sEpisodeId & ") "
        sSQL &= " 	or (I_OCCASE_CHILDCASES in  "
        sSQL &= " 			(select  s_toccase.i from s_toccase   "
        sSQL &= " 			where I_OCCASE_CHILDCASES =  " & sEpisodeId & " )  ) ) "

        oAvon.RunSQL(sSQL, "", dsData)

        Dim rowCurrent As DataRow
        If TypeName(dsData) <> "Nothing" Then
            For Each rowCurrent In dsData.Tables(0).Rows
                If Not IsDBNull(rowCurrent.Item("date_diff")) Then
                    iNumDays += CInt(rowCurrent.Item("date_diff"))
                End If
            Next
        End If

        Return iNumDays

    End Function

    Public Function LTDEpisodeDays(ByRef dsData As System.Data.DataSet, ByVal sNumDays As String) As Boolean
        'LAR 11/07/2003 - this is a wrapper fn for the GetEpisodeDays fn that does all the ltd stuff
        'rather than call GetEpisodeDays directly from the xml file and then have to filter on days.

        Dim rowCurrent As DataRowView
        Dim iEpisodeDays As Integer
        Dim iDelete() As Integer
        ReDim iDelete(-1)
        Dim iCount As Integer = 0
        Dim iNumDays = CInt(sNumDays)
        'LAR 01/14/2004 - see if we have a place to put the ep days
        Dim cols As DataColumnCollection
        Dim bStoreDays As Boolean
        cols = dsData.Tables(0).Columns
        If cols.Contains("total_days") Then
            bStoreDays = True
        End If
        'LAR 01/14/2004 - end
        'create a dataview on the original table
        Dim dvDataView As New DataView(dsData.Tables(0))

        If TypeName(dsData) <> "Nothing" Then
            For Each rowCurrent In dvDataView
                Try
                    'get the approved days for the episode
                    iEpisodeDays = GetEpisodeDays(rowCurrent.Item("episode_id"))
                    'if there are fewer approved days than we are interested in, mark the row for deletion
                    If iEpisodeDays < iNumDays Then
                        ReDim Preserve iDelete(UBound(iDelete) + 1)
                        iDelete(UBound(iDelete)) = iCount
                    Else
                        'LAR 01/14/2004 - if we have a place to put it, store the ep days
                        If bStoreDays Then
                            rowCurrent.Item("total_days") = iEpisodeDays
                        End If
                    End If
                Catch e As Exception
                    'do nothing: 
                End Try
                iCount += 1
            Next
            'now delete all marked rows 
            Array.Sort(iDelete)
            Array.Reverse(iDelete)
            For iCount = 0 To (iDelete.GetLength(0) - 1)
                dvDataView.Delete(iDelete(iCount))
            Next
            dsData.AcceptChanges()

        End If

        Return True

    End Function

    Public Function GetScheduledWorkHours(ByVal pEmployeeID As Object, ByVal pdtStartDate As Object, ByVal pdtEndDate As Object) As Object

        Dim oTimeEntities As New TimeEntities.Schedule
        pdtStartDate = DateTime.Parse(pdtStartDate)
        pdtEndDate = DateTime.Parse(pdtEndDate)
        oTimeEntities.LoadWorkSchedule(pdtStartDate, pdtEndDate, Long.Parse(pEmployeeID))
        Dim dblHours As Double = oTimeEntities.GetTotalScheduledHours(pdtStartDate, pdtEndDate)
        Return dblHours

    End Function

End Class
