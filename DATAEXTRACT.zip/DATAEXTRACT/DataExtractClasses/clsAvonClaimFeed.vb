Imports System.Data.OleDb

Public Class clsAvonClaimFeed
    '=======================================================================================================
    '09/21/2005 LAR 4013 - Overhaul AVON Reverse Feed
    'I am converting the feed to pull data from the new Workability data tables and structure. 
    'There are enough changes that I am reverting the active version of this class to clsAvonClaimFeed.vb
    'instead of clsAvonClaimFeed1A.vb, which I will leave as is for reference.
    '=======================================================================================================

    'these enums are pasted in from wkab.support.LookupConstants.vb
    Enum PRODUCT_TYPE As Integer
        LOA = 6001
        STD = 6002
        LTD = 6003
        STAT = 6004
        PFL = 6005
    End Enum

    Enum RTW_STATUS
        Pend = 42001
        Approved = 42002
        Terminated = 42003
        Denied = 42004
        Suspended = 42005
        Cancelled = 42006
    End Enum

    Enum RTW_REASON As Integer
        Administrative = 43001
        ClaimWithdrawn = 43002
        ClientRequest = 43003
        Death = 43004
        DisNotSupported = 43005
        DisabilitySupported = 43006
        Employee = 43007
        Employer = 43008
        Maintenance = 43009
        MaxBenefits = 43010
        Medical = 43011
        NewClaim = 43012
        NoLongerEmployByComp = 43013
        NoMedsReceived = 43014
        Noncompliance = 43015
        NotEligible = 43016
        PreExistingCondition = 43017
        Relapse = 43018
        Retired = 43019
        ReturnToWork = 43020
        Settlement = 43021
        StableAndMature = 43022
        Reinstated = 43023
    End Enum

    Enum YES_NO As Integer
        Y = 1001
        N = 1002
    End Enum

    Enum WORK_STATUS As Integer
        AtWork = 38001
        NotAtWork = 38002
        ReleasedToRTW = 38003
    End Enum

    Enum WORK_STATUS_DESC As Integer
        BothPhysicalandHour = 40001
        FullDuty = 40002
        HourlyRestrictions = 40003
        PhysicalRestrictions = 40004
        ReducedSchedule = 40005
    End Enum

    Enum APPEAL_STATUS As Integer
        CANCELLED = 45003
        CLOSED = 45002
        ACTIVE = 45001
    End Enum

    Enum APPEAL_DECISION As Integer
        Upheld = 48001
        Reinstated = 48002
        PartiallyReinstated = 48003
        Rescinded = 48004
    End Enum

    Enum STD_STATUS As Integer
        Pend = 32001
        Open = 32002
        Closed = 32003
        Cancelled = 32004
    End Enum


    Public Function DeriveStatus(ByRef dsData As DataSet, ByVal sStartDate As String, ByVal sEndDate As String) As Boolean
        'This function is the main driver for the avon claim data feed.
        'The data set being passed in has all claim status data for the period being
        'extracted. It will loop thru the data, 
        'deciding what the corresponding output status should be. A new dataset 
        'is built, representing the data to be output. The table in the passed dataset
        'is dropped and replaced with it. The extract engine will then output 
        'that dataset to file as instructed.

        '***NOTE that several scenarios involve discovering future-dated claims. Because the 
        'extract could be run for a period in the past, we will use the End Date for the run for these
        'comparisons, rather than the system clock. ie if it is 06/17 and we are running a file
        'for 04/01, and a claim has a 1st date of absence of 04/15, it is in the future
        'in context of that file run, even though it is now in the past. Clear as mud, eh?

        Dim sAction, sReason As String
        Dim sEmpID As String
        Dim sProcessFlag As String = "I"
        Dim bSkipEntry As Boolean   'flag to say don't output the row for this case
        Dim tblOutput As DataTable = New DataTable("Output")
        Dim sEffDate, sBERTW As String
        Dim bBadRows As Boolean
        Dim sBadRowsData As String

        Dim dtEndDate As System.DateTime
        Dim bContinue As Boolean  'bm - 10/6/2003
        Dim iRowCurrentIndex As Integer = 0
        Dim dtHold As System.DateTime

        Dim lPriorStatus, lPriorWorkStatus, lPriorReason, iPriorRTWID As Long
        Dim iIndex As Long

        Dim rowCurrent As DataRow
        Dim dsDataTemp As DataSet = New DataSet
        dsDataTemp.Clear()

        If IsDate(sEndDate) Then
            dtEndDate = CDate(sEndDate)
        Else
            dtEndDate = System.DateTime.Now
        End If

        'create the output table
        tblOutput.Columns.Add("file_id", Type.GetType("System.String"))
        tblOutput.Columns.Add("record_id", Type.GetType("System.String"))
        tblOutput.Columns.Add("process_flag", Type.GetType("System.String"))
        tblOutput.Columns.Add("date", Type.GetType("System.String"))
        tblOutput.Columns.Add("emp_id", Type.GetType("System.String"))
        tblOutput.Columns.Add("eff_date", Type.GetType("System.String"))
        tblOutput.Columns.Add("action", Type.GetType("System.String"))
        tblOutput.Columns.Add("reason", Type.GetType("System.String"))
        tblOutput.Columns.Add("bertw", Type.GetType("System.String"))
        tblOutput.Columns.Add("OHN_ID", Type.GetType("System.String"))
        tblOutput.Columns.Add("claim_id", Type.GetType("System.Int64"))

        For Each rowCurrent In dsData.Tables(0).Rows
            'initialize all variables so we don't have any leftover settings from last row
            sAction = ""
            sReason = ""
            sProcessFlag = "I"
            bSkipEntry = False
            sBERTW = ""
            sEffDate = ""
            sEmpID = rowCurrent.Item("emp_id")
            Try
                'only consider the row if work status/rtw status/rtw reason combination is different from the previous rtw 
                'on the claim (ignoring cancelleds) -- this should work for appeals too....
                '12/12/2005 - this logic keeps getting flakier...now I have to keep stepping up the chain until I find one
                'that would have been acted on, ie skip pend npt new claim or relapse
                'go to db to get it (have to do rtw and appeal differently)
                lPriorStatus = 0
                lPriorReason = 0
                lPriorWorkStatus = 0
                iPriorRTWID = 0

                Select Case rowCurrent("source")
                    Case "RTW"
                        Dim sSQL = "select RTW_ID, rtw_status_id, work_status_id, RTW_REASON_ID from s_dis_rtw " _
                        & "where rtw_id = (select max(rtw_id) from(s_dis_rtw) " _
                        & " where (claim_id = " & rowCurrent("claim_id") & " And rtw_id < " & rowCurrent("rtw_id") & ") " _
                        & " and work_status_id != 38003 and rtw_status_id != 42006 " _
                        & " and not ( rtw_status_id = " & RTW_STATUS.Pend & " and rtw_status_id not in (" _
                        & RTW_REASON.NewClaim & ", " & RTW_REASON.Relapse & ")))"
                        If RunSQL(sSQL, "", dsDataTemp) Then
                            If dsDataTemp.Tables(0).Rows.Count > 0 Then
                                If Not IsDBNull(dsDataTemp.Tables(0).Rows(0).Item("RTW_STATUS_ID")) Then
                                    lPriorStatus = dsDataTemp.Tables(0).Rows(0).Item("RTW_STATUS_ID")
                                    lPriorReason = dsData.Tables(0).Rows(0)("RTW_REASON_ID")
                                    lPriorWorkStatus = dsDataTemp.Tables(0).Rows(0).Item("WORK_STATUS_ID")
                                    iPriorRTWID = dsData.Tables(0).Rows(0)("RTW_ID")
                                End If
                            End If
                        End If
                    Case "APPEAL"
                        'note that the appeals_id column has been aliased as rtw_id so the data extract union will work...
                        If RunSQL("select appeal_status_id, DECISION_ID from s_dis_appeals where appeals_id = (select max(appeals_id) from s_dis_appeals where claim_id = " _
                            & rowCurrent("claim_id") & " and appeals_id < " & rowCurrent("rtw_id") _
                            & " and appeal_status_id != " & APPEAL_STATUS.CANCELLED & ") ", "", dsDataTemp) Then
                            If dsDataTemp.Tables(0).Rows.Count > 0 Then
                                If Not IsDBNull(dsDataTemp.Tables(0).Rows(0).Item("appeal_status_id")) Then
                                    lPriorStatus = dsDataTemp.Tables(0).Rows(0).Item("appeal_status_id")
                                    lPriorReason = dsData.Tables(0).Rows(0)("DECISION_ID")
                                    lPriorWorkStatus = 0
                                End If
                            End If
                        End If
                End Select
                'if all 3 match previous, suppress (if both approved can ignore reason but not work status)
                If (lPriorStatus = rowCurrent("RTW_STATUS_ID") And rowCurrent("RTW_STATUS_ID") = RTW_STATUS.Approved And lPriorWorkStatus = rowCurrent("WORK_STATUS_ID")) _
                    Or (lPriorStatus = rowCurrent("RTW_STATUS_ID") And lPriorWorkStatus = rowCurrent("WORK_STATUS_ID") And lPriorReason = rowCurrent("RTW_REASON_ID")) Then
                    bSkipEntry = True
                Else
                    If Not IsDBNull(rowCurrent("RTW_START_DATE")) Then
                        dtHold = rowCurrent("RTW_START_DATE")
                        sEffDate = String.Format("{0:MM/dd/yyyy}", dtHold)
                    Else
                        sEffDate = ""
                    End If
                    If Not IsDBNull(rowCurrent("bertw")) Then
                        dtHold = rowCurrent("bertw")
                        sBERTW = String.Format("{0:MM/dd/yyyy}", dtHold)
                    Else
                        sBERTW = ""
                    End If
                End If

                'suppress future dated rtw pends
                If rowCurrent.Item("source") = "RTW" Then
                    If DateTime.Compare(CDate(rowCurrent("RTW_START_DATE")), dtEndDate.Date) > 0 _
                        And rowCurrent.Item("RTW_STATUS_ID") = RTW_STATUS.Pend Then
                        bSkipEntry = True
                    End If
                End If

                If Not bSkipEntry Then
                    Select Case rowCurrent.Item("source")
                        Case "RTW"
                            Select Case rowCurrent.Item("RTW_STATUS_ID")
                                Case RTW_STATUS.Suspended
                                    'we don't send suspendeds...
                                    bSkipEntry = True
                                Case RTW_STATUS.Pend
                                    'if there is no specific processing for this pend reason, use the default
                                    sAction = "STD"
                                    sReason = "PND"
                                    'don't extract ltd pnd and supress ALL future-dated pends
                                    If rowCurrent.Item("product") = PRODUCT_TYPE.LTD Then
                                        bSkipEntry = True
                                    Else
                                        'Only extract Pend/New Claim (this is always the status of the 1st and only the 1st rtw 
                                        'on a claim) or Relapse
                                        If rowCurrent.Item("RTW_REASON_ID") <> RTW_REASON.NewClaim And rowCurrent.Item("RTW_REASON_ID") <> RTW_REASON.Relapse Then
                                            bSkipEntry = True
                                        Else
                                            'if a claim is pended and in appeal, don't send it
                                            If IsAppealActive(rowCurrent.Item("claim_id")) Then
                                                bSkipEntry = True
                                            Else
                                            End If
                                        End If
                                    End If
                                    'suppress any pend if the claim is already approved in same file (if it's created and approved
                                    'same day we'll get a pend/new claim and then approved in same dataset)
                                    If Not bSkipEntry Then
                                        Dim dvDataView As New DataView(dsData.Tables(0))
                                        dvDataView.RowFilter = "claim_id = " & rowCurrent.Item("claim_id")
                                        Dim drv As DataRowView
                                        For Each drv In dvDataView
                                            If drv("rtw_status_id") = RTW_STATUS.Approved Or drv("rtw_status_id") = RTW_STATUS.Denied Then bSkipEntry = True
                                        Next
                                    End If
                                Case RTW_STATUS.Approved
                                    Select Case rowCurrent.Item("product")
                                        Case PRODUCT_TYPE.LTD
                                            sAction = "LTO"
                                            sReason = "LTD"
                                            'is it workers comp?
                                            If rowCurrent("WORK_RELATED_ID") = YES_NO.Y Then
                                                sReason = "WKC"
                                            End If
                                            'is it PT RTW w/ Mods? NOTE: this trumps the WKC above if both are present
                                            If rowCurrent("WORK_STATUS_ID") = WORK_STATUS.AtWork And _
                                                (rowCurrent("work_status_desc_id") = WORK_STATUS_DESC.HourlyRestrictions Or _
                                                rowCurrent("work_status_desc_id") = WORK_STATUS_DESC.BothPhysicalandHour) Then
                                                sAction = "LTD"
                                                sReason = "MRW"
                                            End If
                                        Case PRODUCT_TYPE.STD
                                            sAction = "STD"
                                            sReason = "STD"
                                            'is it workers comp?
                                            If rowCurrent("WORK_RELATED_ID") = YES_NO.Y Then
                                                sReason = "WKC"
                                            End If
                                            'State Disability
                                            If rowCurrent("statutory_flag") = 1 Then
                                                sAction = "STO"
                                                sReason = "MND"
                                            End If
                                            'is it PT RTW w/ Mods? NOTE: this trumps the WKC above if both are present
                                            If rowCurrent("WORK_STATUS_ID") = WORK_STATUS.AtWork And _
                                                (rowCurrent("WORK_STATUS_DESC_ID") = WORK_STATUS_DESC.HourlyRestrictions Or _
                                                rowCurrent("WORK_STATUS_DESC_ID") = WORK_STATUS_DESC.BothPhysicalandHour) Then
                                                sAction = "STD"
                                                sReason = "MRW"
                                            End If
                                    End Select
                                Case RTW_STATUS.Denied
                                    sAction = "LOA"
                                    sReason = "UNA"
                                    If IsAppealActive(rowCurrent.Item("claim_id")) Then sReason = "APL"
                                Case RTW_STATUS.Terminated
                                    Select Case rowCurrent.Item("product")
                                        Case PRODUCT_TYPE.LTD
                                            Select Case rowCurrent.Item("RTW_REASON_ID")
                                                Case RTW_REASON.ReturnToWork
                                                    sAction = "RFL"
                                                    sReason = "RFL"
                                                    sBERTW = ""
                                                Case RTW_REASON.Employer, RTW_REASON.Settlement, RTW_REASON.Retired, _
                                                        RTW_REASON.Administrative, RTW_REASON.DisNotSupported, RTW_REASON.MaxBenefits
                                                    sAction = "LOA"
                                                    sReason = "END"
                                                Case RTW_REASON.Death
                                                    sAction = ""
                                                    sReason = ""
                                            End Select
                                        Case Else   'std
                                            Dim bFoundLTD As Boolean = False
                                            'need to know if it is transitioning to ltd
                                            'look for an open or pend ltd claim with this std's id 
                                            'in the claim_id_std column. if found, we'll suppress this one
                                            If RunSQL("select * from s_dis_claim where product_id  = 6003 and claim_status_id in( " & STD_STATUS.Open & ", " & STD_STATUS.Pend & ") and claim_id_std = " & rowCurrent.Item("claim_id"), "", dsDataTemp) Then
                                                If dsDataTemp.Tables(0).Rows.Count > 0 Then
                                                    If Not IsDBNull(dsDataTemp.Tables(0).Rows(0)("claim_id")) Then
                                                        bFoundLTD = True
                                                    End If
                                                End If
                                            End If
                                            Select Case rowCurrent("RTW_REASON_ID")
                                                Case RTW_REASON.ReturnToWork
                                                    If bFoundLTD Then
                                                        bSkipEntry = True
                                                    Else
                                                        sAction = "RFL"
                                                        sReason = "RFL"
                                                        sBERTW = ""
                                                    End If
                                                Case RTW_REASON.MaxBenefits
                                                    If bFoundLTD Then
                                                        bSkipEntry = True
                                                    Else
                                                        sAction = "LOA"
                                                        sReason = "END"
                                                    End If
                                                Case RTW_REASON.Death
                                                    sAction = ""
                                                    sReason = ""
                                                Case RTW_REASON.DisNotSupported
                                                    sAction = "LOA"
                                                    sReason = "UNA"
                                                Case Else
                                                    sAction = "LOA"
                                                    sReason = "END"
                                            End Select
                                    End Select
                                Case RTW_STATUS.Cancelled
                                    'for cancelleds, decide if it was ever pended overnight. If so, we sent a record on it, 
                                    'so we have to synthesize a duplicate of the original, with the delete flag set
                                    ' bm - 10/7/2003 - bypass logical delete processing for LTD.  
                                    'For LTD, send a dummy STD close if the last status was closed on the STD claim.
                                    Select Case rowCurrent.Item("product")
                                        Case PRODUCT_TYPE.LTD
                                            Dim dtDisClaimActualRTWDate As Date
                                            'create the std closure (it was suppressed when it first happened but now that
                                            'the ltd is cancelled we need to send it)
                                            'Decide what the record should have looked like by the std status
                                            'get the std claim assoc with this ltd
                                            If RunSQL("select * from s_dis_claim where product_id  = 6002 and claim_id_ltd = " & rowCurrent.Item("claim_id"), "", dsDataTemp) Then
                                                If dsDataTemp.Tables(0).Rows.Count > 0 Then
                                                    'get the most recent rtw record for it
                                                    If RunSQL("select * from s_dis_rtw where claim_id = " & dsDataTemp.Tables(0).Rows(0).Item("claim_id") & " and work_status_id != 38003 order by create_date desc", "", dsDataTemp) Then
                                                        If Not IsDBNull(dsDataTemp.Tables(0).Rows(0).Item("RTW_START_DATE")) Then
                                                            Dim dtTemp As System.DateTime = dsDataTemp.Tables(0).Rows(0).Item("RTW_START_DATE")
                                                            sEffDate = String.Format("{0:MM/dd/yyyy}", dtTemp)
                                                        End If
                                                        'act based on its status.
                                                        Select Case dsDataTemp.Tables(0).Rows(0).Item("rtw_status_id")
                                                            Case RTW_STATUS.Approved, RTW_STATUS.Pend, RTW_STATUS.Cancelled
                                                                bSkipEntry = True
                                                            Case RTW_STATUS.Denied
                                                                sAction = "LOA"
                                                                sReason = "UNA"
                                                            Case RTW_STATUS.Terminated
                                                                If dsDataTemp.Tables(0).Rows(0).Item("RTW_REASON_ID") = RTW_REASON.ReturnToWork Then
                                                                    sAction = "RFL"
                                                                    sReason = "RFL"
                                                                    sBERTW = ""
                                                                ElseIf dsDataTemp.Tables(0).Rows(0).Item("RTW_REASON_ID") = RTW_REASON.MaxBenefits Then
                                                                    sAction = "LOA"
                                                                    sReason = "END"
                                                                End If
                                                        End Select
                                                        If Not bSkipEntry Then
                                                            'output the dummy std row and skip the ltd cancel
                                                            Dim newRow As DataRow
                                                            newRow = tblOutput.NewRow()
                                                            newRow("file_id") = "STD"
                                                            newRow("record_id") = "02"
                                                            newRow("process_flag") = "I"
                                                            newRow("date") = String.Format("{0:MM/dd/yyyy}", CDate(sEndDate))
                                                            newRow("emp_id") = sEmpID
                                                            newRow("eff_date") = String.Format("{0:MM/dd/yyyy}", sEffDate)
                                                            newRow("action") = sAction
                                                            newRow("reason") = sReason
                                                            newRow("bertw") = sBERTW
                                                            newRow("OHN_ID") = rowCurrent.Item("OHN_ID")
                                                            newRow("claim_id") = rowCurrent.Item("claim_id")
                                                            tblOutput.Rows.Add(newRow)
                                                            bSkipEntry = True
                                                        End If
                                                        dsDataTemp.Clear()
                                                    End If
                                                End If
                                            Else
                                                'no std for the ltd, that's ... bizarre. Skip it.
                                                bSkipEntry = True
                                            End If
                                        Case Else   'std
                                            Dim bLogicalDelete As Boolean = False
                                            Dim bOvernighted As Boolean
                                            'Cancels are suppressed, but in some cases we need to send a logical delete of what we sent on
                                            'the one that was cancelled when it was first made
                                            'if it is the FIRST line and it existed overnight, send log delete of pend
                                            If IsOnlyRTWOnClaim(rowCurrent("claim_id")) Then
                                                RunSQL("select edit_date from s_dis_rtw where rtw_id = " & rowCurrent("rtw_id").ToString, , dsDataTemp)
                                                If dsData.Tables(0).Rows.Count > 0 Then
                                                    If CType(dsDataTemp.Tables(0).Rows(0)("edit_date"), Date).Date < CType(sEndDate, Date).Date Then
                                                        sAction = "STD"
                                                        sReason = "DEL"
                                                        bLogicalDelete = True
                                                    End If
                                                End If
                                            Else
                                                'I can't figure out a foolproof way to deduce the prior status of a cancelled
                                                'rtw line since it is edited in place, so... have to use the audit tables, as much as I hate doing it.
                                                RunSQL("select * from a_dis_rtw where rtw_id = " & rowCurrent("rtw_id").ToString & " and rtw_status_id != " & RTW_STATUS.Cancelled, , dsDataTemp)
                                                If dsDataTemp.Tables(0).Rows.Count > 0 Then
                                                    lPriorStatus = dsDataTemp.Tables(0).Rows(0)("RTW_STATUS_ID")
                                                    lPriorReason = dsDataTemp.Tables(0).Rows(0)("RTW_REASON_ID")
                                                    'Was it a term/rtw? ie At Work, Claim Closed
                                                    If lPriorStatus = RTW_STATUS.Terminated And lPriorReason = RTW_REASON.ReturnToWork Then
                                                        sAction = "RFL"
                                                        sReason = "DEL"
                                                        bLogicalDelete = True
                                                    End If
                                                End If

                                                'Was it a approved? ie Not At Work, Claim Open
                                                If lPriorStatus = RTW_STATUS.Approved Then
                                                    sAction = "STD"
                                                    sReason = "DEL"
                                                    bLogicalDelete = True
                                                    lPriorStatus = 0
                                                    If RunSQL("select RTW_ID, rtw_status_id, work_status_id, RTW_REASON_ID, edit_date from s_dis_rtw where rtw_id = (select max(rtw_id) from s_dis_rtw where claim_id = " _
                                                        & rowCurrent("claim_id") & " and rtw_id < " & rowCurrent("rtw_id") _
                                                        & " and work_status_id != 38003) ", "", dsDataTemp) Then
                                                        If dsDataTemp.Tables(0).Rows.Count > 0 Then
                                                            If Not IsDBNull(dsDataTemp.Tables(0).Rows(0).Item("RTW_STATUS_ID")) Then
                                                                lPriorStatus = dsDataTemp.Tables(0).Rows(0).Item("RTW_STATUS_ID")
                                                            End If
                                                        End If
                                                    End If
                                                    'suppress if the record being cancelled was not output because status was same
                                                    Select Case lPriorStatus
                                                        Case RTW_STATUS.Approved
                                                            'if prior is approved then we didn't send this when it was approved;
                                                            bLogicalDelete = False
                                                        Case RTW_STATUS.Cancelled
                                                            'if prior status is cancelled and it was not cancelled overnight (ie edit date < start of this run), suppress this
                                                            If CType(dsDataTemp.Tables(0).Rows(0)("edit_date"), Date).Date >= CType(sStartDate, Date).Date Then
                                                                bLogicalDelete = False
                                                            End If
                                                    End Select
                                                End If
                                            End If

                                            If bLogicalDelete Then
                                                Dim newRow As DataRow
                                                newRow = tblOutput.NewRow()
                                                newRow("file_id") = "STD"
                                                newRow("record_id") = "02"
                                                newRow("process_flag") = "D"
                                                newRow("date") = String.Format("{0:MM/dd/yyyy}", CDate(sEndDate))
                                                newRow("emp_id") = sEmpID
                                                dtHold = rowCurrent("RTW_START_DATE")
                                                newRow("eff_date") = String.Format("{0:MM/dd/yyyy}", dtHold)
                                                newRow("action") = sAction
                                                newRow("reason") = sReason
                                                newRow("bertw") = sBERTW
                                                newRow("OHN_ID") = rowCurrent.Item("OHN_ID")
                                                newRow("claim_id") = rowCurrent.Item("claim_id")
                                                tblOutput.Rows.Add(newRow)
                                            End If
                                            'if it didn't exist overnight and it was cancelled claim withdrawn
                                            'we need to remove any other rows from the dataset for this claim.
                                            If rowCurrent.Item("rtw_reason_id") = RTW_REASON.ClaimWithdrawn Then
                                                RunSQL("select min(edit_date) as edit_date from s_dis_rtw where claim_id = " & rowCurrent("claim_id").ToString, , dsDataTemp)
                                                If dsData.Tables(0).Rows.Count > 0 Then
                                                    If CType(dsData.Tables(0).Rows(0)("edit_date"), Date).Date = CType(sEndDate, Date).Date Then
                                                        'if we aren't already on the last row, see if we're the last one 
                                                        'for this claim (if there's another for this claim then we need to go to it next)
                                                        Dim bDelete As Boolean
                                                        If iRowCurrentIndex < dsData.Tables(0).Rows.Count - 1 Then
                                                            If dsData.Tables(0).Rows(iRowCurrentIndex + 1).Item("claim_id") <> rowCurrent.Item("claim_id") Then
                                                                bDelete = True
                                                            End If
                                                        Else
                                                            bDelete = True
                                                        End If
                                                        If bDelete Then
                                                            'delete any already-created output rows for this claim                                                
                                                            Dim dvDataView As New DataView(tblOutput)
                                                            dvDataView.RowFilter = "claim_id = " & rowCurrent.Item("claim_id")
                                                            Dim drv As DataRowView
                                                            For Each drv In dvDataView
                                                                drv.Delete()
                                                            Next
                                                            dsData.AcceptChanges()
                                                        End If
                                                    End If
                                                End If

                                            End If
                                            bLogicalDelete = False
                                            'don't send the actual cancelled entry
                                            bSkipEntry = True
                                    End Select
                                Case Else
                                    'ERROR: NOT A HANDLED STATUS
                                    bSkipEntry = True
                            End Select
                        Case "APPEAL"
                            'default for appeal is to skip, unless it satisfies one of the conditions below
                            bSkipEntry = True
                            'find the claim record, our output on appeal depends on the state of the claim
                            If RunSQL("select * from s_dis_rtw where claim_id = " & rowCurrent.Item("claim_id") & " and work_status_id != 38003 order by create_date desc", "", dsDataTemp) Then
                                Dim lRTWStatus, lRTWReason, lRTWProduct As Long
                                Dim dtRTWStartDate As Date
                                If Not IsDBNull(dsDataTemp.Tables(0).Rows(0).Item("rtw_status_id")) Then
                                    lRTWStatus = dsDataTemp.Tables(0).Rows(0).Item("rtw_status_id")
                                End If
                                If Not IsDBNull(dsDataTemp.Tables(0).Rows(0).Item("rtw_reason_id")) Then
                                    lRTWReason = dsDataTemp.Tables(0).Rows(0).Item("rtw_reason_id")
                                End If
                                If Not IsDBNull(dsDataTemp.Tables(0).Rows(0).Item("RTW_START_DATE")) Then
                                    dtRTWStartDate = dsDataTemp.Tables(0).Rows(0).Item("RTW_START_DATE")
                                End If
                                If RunSQL("select product_id from s_dis_claim where claim_id = " & rowCurrent.Item("claim_id"), "", dsDataTemp) Then
                                    If Not IsDBNull(dsDataTemp.Tables(0).Rows(0).Item("product_id")) Then
                                        lRTWProduct = dsDataTemp.Tables(0).Rows(0).Item("product_id")
                                    End If
                                End If

                                'note that I've aliased appeal_status_id as rtw_status_id and decision_id as rtw_reason_id for the sql union
                                If rowCurrent.Item("RTW_STATUS_ID") = APPEAL_STATUS.ACTIVE Then
                                    Select Case lRTWProduct
                                        Case PRODUCT_TYPE.STD
                                            'Scenario 8 - new appeal created, status active, for std rtw terminated/disnotsupp, output loa/apl eff terminated/disnotsupp rtw start dt
                                            'Scenario 14 - new appeal created, status active, for std rtw denied/noncompliance, output loa/apl
                                            If (lRTWStatus = RTW_STATUS.Terminated And lRTWReason = RTW_REASON.DisNotSupported) Or _
                                                (lRTWStatus = RTW_STATUS.Denied And lRTWReason = RTW_REASON.Noncompliance) Then
                                                sAction = "LOA"
                                                sReason = "APL"
                                                sEffDate = dtRTWStartDate
                                                bSkipEntry = False
                                            End If
                                        Case PRODUCT_TYPE.LTD
                                            'Scenario 32/33 - new appeal created for rtw ltd denied/disnotsupp, output lto/apl eff ltd denied/disnotsupp start dt
                                            If lRTWStatus = RTW_STATUS.Denied Then 'And lRTWReason = RTW_REASON.DisNotSupported Then
                                                sAction = "LTO"
                                                sReason = "APL"
                                                sEffDate = dtRTWStartDate
                                                bSkipEntry = False
                                            End If
                                    End Select
                                End If

                                'Scenario 14 pt 2 - appeal updated to closed, decision Upheld - rtw not changed, output loa/una eff rtw start dt
                                'Scenario 33 pt 2 - appeal updated to closed, decision Upheld - rtw not changed, output loa/una eff rtw start dt
                                If rowCurrent.Item("RTW_STATUS_ID") = APPEAL_STATUS.CLOSED And rowCurrent.Item("rtw_reason_id") = APPEAL_DECISION.Upheld Then
                                    If lRTWStatus = RTW_STATUS.Denied Then
                                        sAction = "LOA"
                                        sReason = "UNA"
                                        sEffDate = dtRTWStartDate
                                        bSkipEntry = False
                                    End If
                                End If
                                'capture but ignore all other appeal activity on avon claims. That includes updates to the above appeals if the status does not change.
                                'Scenario 8 pt 2 - appeal updated to closed, decision Reinstated or PartiallyReinstated or Rescinded (overturned) - new rtw is created so act on it and ignore appeal, output std/std
                                'Scenario 32 pt 2 - appeal overturned - rtw is updated so act on it and ignore appeal, output std/std
                            End If
                    End Select
                End If
            Catch
                'LAR 11/23/2004 - if there was a data problem with this record then just log it and go on to the next.
                'Service Delivery will have to fix the claim tomorrow.
                Dim i As Integer = 0
                'save off the details of the offending row
                For i = 0 To rowCurrent.Table.Columns.Count - 1
                    sBadRowsData &= rowCurrent(i) & ";"
                Next
                'removing trailing delimiter & add linefeed
                sBadRowsData = Left(sBadRowsData, Len(sBadRowsData) - 1) & vbCr & vbLf
                bBadRows = True
                bSkipEntry = True
            End Try

            If Not bSkipEntry Then
                'now add the data to the work table
                Dim newRow As DataRow
                newRow = tblOutput.NewRow()
                newRow("file_id") = "STD"
                newRow("record_id") = "02"
                newRow("process_flag") = sProcessFlag
                newRow("date") = String.Format("{0:MM/dd/yyyy}", CDate(sEndDate))
                newRow("emp_id") = sEmpID
                sEffDate = String.Format("{0:MM/dd/yyyy}", sEffDate)
                newRow("eff_date") = sEffDate
                newRow("action") = sAction
                newRow("reason") = sReason
                newRow("bertw") = sBERTW
                newRow("OHN_ID") = rowCurrent.Item("OHN_ID")
                newRow("claim_id") = rowCurrent.Item("claim_id")
                tblOutput.Rows.Add(newRow)
            End If
            bSkipEntry = False
            iRowCurrentIndex += 1
        Next

        Try

            'drop the original table out of the dataset
            dsData.Tables.Remove(dsData.Tables(0))
            'add the new one
            dsData.Tables.Add(tblOutput)

            If dsData.Tables(0).Columns.Contains("claim_id") Then dsData.Tables(0).Columns.Remove("claim_id")

            If bBadRows Then
                'throw a non-fatal exception
                Dim sErrorText As String = "NON-FATAL ERROR: "
                sErrorText &= "Found rows with bad data. All such rows were deleted from the feed. Here is a list of the raw data:" & vbCr & vbLf & sBadRowsData & vbCr & vbLf
                Throw New System.Exception(sErrorText)
            End If
        Catch ex As Exception
            Throw ex
            Return False
        End Try

        Return True

    End Function

    Public Function IsOnlyRTWOnClaim(ByVal ClaimID As Integer) As Boolean
        Dim dsData As New DataSet

        RunSQL("select count(*) as counter from s_dis_rtw where claim_id = " & ClaimID.ToString, , dsData)
        If dsData.Tables(0).Rows.Count > 0 Then
            If dsData.Tables(0).Rows(0)("counter") = 1 Then
                Return True
            Else
                Return False
            End If
        End If

    End Function

    'LAR 11/13/2003 - made this public so I can use it from clsUtilityFunctions
    Public Function RunSQL(ByVal sSQL As String, Optional ByVal sParamsInput As String = "", Optional ByRef dsData As DataSet = Nothing, Optional ByVal strDbaseSource As String = "") As Boolean
        'Take the passed sql and params, run them and populate the passed dataset
        Dim sParams() As String
        Dim strTemp As String
        Dim intIndex As Short

        'added code to set the UDL based upon a passed argument.  If argument is not passed, default to the wkab UDL.
        'If the passed argument is DRMS, use the DRMS UDL, otherwise, use the Wkab UDL.
        Dim strUDLName As String
        If strDbaseSource = "" Then
            strUDLName = "File Name=c:\WKABOLEDB.UDL;"
        ElseIf strDbaseSource = "DRMS" Then
            strUDLName = "File Name=c:\DRMSOLEDB.UDL;"
        Else
            strUDLName = "File Name=c:\WKABOLEDB.UDL;"
        End If

        Dim objCon As OleDbConnection = New OleDbConnection(strUDLName)
        Dim objCommand As OleDbCommand = New OleDbCommand("Lee", objCon)
        Dim daData As OleDbDataAdapter = New OleDbDataAdapter(objCommand)
        Dim iRowsAffected As Integer

        RunSQL = True
        daData.SelectCommand = objCommand
        Try
            objCon.Open()
        Catch objExAlreadyOpen As InvalidOperationException
            'connection is already open, use it
        Catch objException As Exception
            'can't make a connection, fail out
            LogError(objException, "RunSQL")
            RunSQL = False
            Exit Function
        End Try
        'if it is a stored proc, then we have to collect the params and process them as well
        If UCase(Left(sSQL, 2)) = "PK" Or UCase(Left(sSQL, 2)) = "SP" Then
            If sParamsInput <> "" Then
                sParams = Split(sParamsInput, ",")
                'loop thru all params in the file and construct the param list
                For intIndex = 0 To UBound(sParams)
                    strTemp = strTemp + IIf(Len(strTemp) = 0, "'" & Trim(sParams(intIndex)) & "'", ", '" & Trim(sParams(intIndex)) & "'")
                Next intIndex
            End If
            'build the oracle command string
            objCommand.CommandText = "{CALL " & sSQL & "(" & strTemp & ")}"
        Else
            'if it is just a simple sql statement, execute it directly
            objCommand.CommandText = sSQL
        End If

        'Execute statement
        'if we got a dataset, fill it
        If TypeName(dsData) <> "Nothing" Then
            Try
                dsData.Clear()
                daData.Fill(dsData)
            Catch objException As Exception
                LogError(objException, "RunSQL")
                RunSQL = False
                Exit Function
            End Try
        Else
            'otherwise, it must be just an insert or update, so just execute it
            Try
                Dim objTrans As OleDbTransaction
                ' Start a local transaction
                objTrans = objCon.BeginTransaction()
                ' Assign transaction object for a pending local transaction
                objCommand.Connection = objCon
                objCommand.Transaction = objTrans
                iRowsAffected = objCommand.ExecuteNonQuery()
                objTrans.Commit()
            Catch objException As Exception
                LogError(objException, "RunSQL")
                RunSQL = False
                Exit Function
            End Try
        End If

        objCommand = Nothing

        Try
            objCon.Close()
        Catch objException As Exception
            'don't worry, it'll go out of scope anyway
        End Try

    End Function

    Private Function IsAppealActive(ByVal lClaimID As Long) As Boolean
        Dim dsAppeals As New DataSet

        RunSQL("PK_DISABILITY.SP_Get_Claim_Appeals", lClaimID.ToString, dsAppeals)

        If dsAppeals.Tables(0).Rows.Count > 0 Then
            dsAppeals.Tables(0).DefaultView.RowFilter = "APPEAL_STATUS = 'ACTIVE'"
            If dsAppeals.Tables(0).DefaultView.Count > 0 Then
                Return True
            Else
                Return False
            End If
        End If

    End Function

    Private Function WasInStatusOvernight(ByVal lClaimID As String, ByVal lStatus As Long, ByVal dtDate As Date) As Boolean
        'this function will determine if a claim was ever in a given status overnight
        'this is used to infer that an std/std or std/pnd record was sent on it.
        Dim dsData As New DataSet
        Dim rowCurrent As DataRow
        Dim dtPriorDate, dtCompare As System.DateTime
        Dim lPriorStatus As Long

        RunSQL("select * from s_dis_rtw where claim_id = " & lClaimID.ToString & " and work_status_id != 38003 order by create_date desc", "", dsData)

        Try
            'prime the vars with the first row's data
            dtPriorDate = dtDate
            For Each rowCurrent In dsData.Tables(0).Rows
                'if the row is in our status, and more than a day older than the compare date, then it was in status overnight
                '(note, since the dataset is sorted, we know each one is LATER
                'than the one prior, we just have to know if by >= 1 day)
                If (rowCurrent("rtw_status_id") = lStatus) And (CDate(rowCurrent("edit_date")).Date < dtPriorDate.Date) Then
                    Return True
                Else
                    'if not, save off the value and go to the next row
                    dtPriorDate = rowCurrent("edit_date")
                End If
            Next

        Catch ex As System.Exception
            Throw New System.Exception("WasInStatusOvernight: Could not establish whether claim " & lClaimID.ToString & " was in status " & lStatus.ToString & " overnight. " & ex.Message & " " & ex.InnerException.Message)
        End Try

    End Function

    Private Function LogError(ByVal objException As Exception, ByVal sFunction As String)
        'get the exception text and write it to the log file
        'note that we don't have access to the extract engine's log file so we can't write the error out.
        'this function serves instead as a debugging tool so we can step into here and esily see the
        'exception messages...
        Dim sErrorMsg As String
        sErrorMsg = "Error in " & sFunction & ". "
        sErrorMsg &= objException.Message
        If TypeName(objException.InnerException) <> "Nothing" Then
            sErrorMsg &= " " & objException.InnerException.Message
        End If

    End Function
    Private Function WriteFile(ByRef strInput As String) As Object

        FileOpen(1, "C:\DataExtracts\ExtractDefinitionFiles\log\GoddamFuckingAvon.log", OpenMode.Append)
        PrintLine(1, strInput)
        FileClose(1)

    End Function


End Class
