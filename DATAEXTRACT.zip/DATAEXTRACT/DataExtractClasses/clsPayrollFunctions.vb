Public Class clsPayrollFunctions
    'This class contains functions that can be called from the DataExtract
    'engine to do custom work on the payroll extract data. They are called by 
    'placing a reference to them in the SubQueries section of the extract
    'definition xml file like so:
    '<SubQueries>
    '   <NegatedPats assembly="DataExtractClasses" object="DataExtractClasses.clsPayrollFunctions" function="RemoveNegatedPats" Param="m_dsData"/>
    '</SubQueries>

    Public Function RemoveNegatedPats(ByRef dsData As DataSet) As String
        'LAR 03/25/2003
        'this function's job is to go thru a dataset of payroll extract
        'records, and remove any PAT pairs that offset each other. Ex:
        '113668162 H58119 MYRAN HEATHER L  1364 SALARIED-FT NY 20030203 20030209 20030203 20030312 N 28860 555 555 1166.42
        '113668162 H58119 MYRAN HEATHER L  1364 SALARIED-FT NY 20030203 20030209 20030203 20030312 N 28860 -555 -555 1166.42
        'RemoveNegatedPats = True
        Dim lPATID As Integer
        Dim i As Integer

        'create a dataview on the original table
        Dim dvDataView As New DataView(dsData.Tables(0))
        'sort it by patid so we can find based on it
        dvDataView.Sort = "PATid"
        'go thru row by row
        'For a pat that has been negated, the PATNegatedID col will have the PATID
        'of the negating pat. The negating pat itself will have -1 in that col.
        'All others will have 0 (possibly null but not supposed to be).
        'only take them out in pairs: if the original pat is not in this dataset, 
        'don't take out the negating pat.
        Dim drv As DataRowView
        Dim iCount As Integer = 0
        Dim iHold As Integer = 0
        Dim iDelete() As Integer
        ReDim iDelete(-1)

        For Each drv In dvDataView
            If Not drv.Row.RowState = DataRowState.Detached Then
                'even after a row is deleted, it still tries to look at it.
                'this will pop an error, so do a try catch and ignore the error
                Try
                    If Not IsDBNull(drv("PATNegatedID")) Then
                        lPATID = drv("PATNegatedID")
                        If lPATID <> 0 Then
                            'find its mate
                            If lPATID <> -1 Then
                                Dim iFoundIndex As Integer = dvDataView.Find(lPATID)
                                If iFoundIndex > 0 Then
                                    'if present, remove both
                                    'first delete the matching one
                                    Try
                                        ReDim Preserve iDelete(UBound(iDelete) + 1)
                                        iDelete(UBound(iDelete)) = iFoundIndex
                                    Catch e As Exception
                                        'don't do anything: prob means it's already deleted
                                        RemoveNegatedPats &= "Errored trying to delete 1st of pair, with patid " & CStr(lPATID) & " "
                                    End Try
                                    'now the original
                                    lPATID = drv("PATid")
                                    iFoundIndex = dvDataView.Find(lPATID)
                                    Try
                                        'dvDataView.Delete(iFoundIndex)
                                        'RemoveNegatedPats &= CStr(lPATID) & " "
                                        'If UBound(iDelete) > 0 Then
                                        ReDim Preserve iDelete(UBound(iDelete) + 1)
                                        'End If
                                        iDelete(UBound(iDelete)) = iFoundIndex
                                    Catch e As Exception
                                        'don't do anything: prob means it's already deleted
                                        RemoveNegatedPats &= "Errored trying to delete 2nd of pair, with patid " & CStr(lPATID) & " "
                                    End Try
                                End If
                            End If
                        End If
                    End If
                Catch e As Exception
                    'do nothing: it's trying to asses a deleted row.
                End Try
            End If
            'iCount += 1
        Next
        Array.Sort(iDelete)
        Array.Reverse(iDelete)
        For iCount = 0 To (iDelete.GetLength(0) - 1)
            dvDataView.Delete(iDelete(iCount))
        Next
        dsData.AcceptChanges()

    End Function

    Public Function ConvertDate(ByVal sDate As String, ByVal Conversion As String, ByVal sDirection As String, Optional ByVal sOverrideSame As String = "0") As System.DateTime
        'this function takes in a date, a day of week to convert it to, and the direction (forward or backward in time)
        'and returns the appropriate date
        'the enums equate to 0 Sunday to 6 Saturday
        'the override option tells us whether to leave a date as is if it
        'is already on the desired day of week
        'Dim dtDate As System.DateTime = CDate(oDate.GetType.ToString)
        Dim dtDate As System.DateTime = CDate(sDate)
        'find the num days between the new day and current one
        'ie pass in a wed, conv is sat, diff is 3
        'pass in sat, conv is wed, diff is -3
        Dim iDiff As Integer = CInt(Conversion) - dtDate.DayOfWeek
        'first see if the passed date is already on the right day 
        If iDiff = 0 Then
            'if the override flag is not set then return same day
            'so leave iDiff at 0
            'otherwise go a whole week up or back
            If sOverrideSame = "1" Then
                Select Case sDirection
                    Case "prior"
                        iDiff = -7
                    Case "next"
                        iDiff = 7
                    Case Else
                        'error
                        'return original date
                        Return dtDate
                End Select
            End If
        Else
            'slightly different logic if going ahead or back
            Select Case sDirection
                Case "prior"
                    'standard is going back to a prior day ie wed to sun
                    'so leave a neg diff as is
                    If iDiff > 0 Then
                        'more complex: ie going from tues to prior thurs; diff is 2
                        'really want to go BACK 5 days so conv 2 to -5 by sub 7
                        iDiff -= 7
                    End If
                Case "next"
                    'standard, going forward to a later day ie sun to wed
                    'so leave pos diff as is
                    If iDiff < 0 Then
                        'more complex: ie going from wed to next mon; diff is -2
                        'really want to go FORWARD 5 days so conv -2 to 5 by add 7
                        iDiff += 7
                    End If
                Case Else
                    'error
                    'return original date
                    Return dtDate
            End Select
        End If

        ConvertDate = dtDate.AddDays(iDiff)

    End Function

    Public Function PRU30_MarkMultipleEmployees(ByRef dsData As DataSet) As String
        'DDM 05/13/2003
        'this function's job is to go thru a dataset of payroll extract
        'records and mark all the multiple occursnces of an employee with a letter for the occurrance
        'EX.    1123233 A
        '       1123233 B
        '       1123233 C
        '       112456  A
        '       112456  B
        '       112456  C

        Dim iEmpID As Integer = 0
        Dim iMarker As Integer = 65

        'create a dataview on the original table
        Dim dvDataView As New DataView(dsData.Tables(0))
        'sort it by ssn so we can find based on it
        dvDataView.Sort = "ssn"
        'go thru row by row
        
        Dim drv As DataRowView
        Dim iCount As Integer = 0
        Dim iHold As Integer = 0

        For Each drv In dvDataView
            Try
                If Not IsDBNull(drv("ssn")) Then
                    If iEmpID <> drv("ssn") Then
                        'need to reset letter and update 
                        iMarker = 65
                        iEmpID = drv("ssn")
                    End If
                    'need to increment letter
                    drv("ProcessGroup") = Chr(iMarker)
                    iMarker += 1
                End If
            Catch e As Exception
                'do nothing: 
            End Try
        Next
        dsData.AcceptChanges()

    End Function

    Public Function EventIDEqualsEpisodeID(ByRef dsData As DataSet) As Boolean
        'this was implemented for HBC
        'We are retrieving the event id (casenumber) twice, and a subquery is
        'converting one to the casenumber for the episode. Occasionally that subquery
        'has failed and the ids were left the same. This fn will decide if that
        'has happened and throw an exception. Any offending rows will be marked,
        'noted, and deleted from the dataset. Also any with null ids.
        'The exception will be handled non-fatally, simply logged.

        Dim iFound As Integer = 0
        Dim i As Integer = 0
        Dim iRowCounter As Integer = 0
        Dim bFound As Boolean, bHandleThis As Boolean
        Dim sFound As String = ""
        Dim drv As DataRowView
        Dim iDelete() As Integer

        'create a dataview on the original table
        Dim dvDataView As New DataView(dsData.Tables(0))
        ReDim iDelete(-1)

        'loop to find any that match or are null
        For Each drv In dvDataView
            If Not IsDBNull(drv("casenumber")) Then
                If Not IsDBNull(drv("event_id")) Then
                    If drv("casenumber") = drv("event_id") Then
                        'mark it for processing
                        bHandleThis = True
                    End If
                Else
                    'mark it for processing
                    bHandleThis = True
                End If
            Else
                'mark it for processing
                bHandleThis = True
            End If
            If bHandleThis Then
                bFound = True
                'save off the details of the offending row
                For i = 0 To dvDataView.Table.Columns.Count - 1
                    sFound &= drv(i) & ";"
                Next
                'removing trailing delimiter & add linefeed
                sFound = Left(sFound, Len(sFound) - 1)
                'save off the index of the row
                ReDim Preserve iDelete(UBound(iDelete) + 1)
                iDelete(UBound(iDelete)) = iRowCounter
                iFound += 1
            End If
            iRowCounter += 1
            bHandleThis = False
        Next

        'now take any found rows out of the dataset
        If bFound Then
            Array.Sort(iDelete)
            'reverse the sort so we remove from the bottom first
            Array.Reverse(iDelete)
            For i = 0 To (iDelete.GetLength(0) - 1)
                dvDataView.Delete(iDelete(i))
            Next
            dsData.AcceptChanges()
            'throw an exception 
            Throw New System.Exception("NON-FATAL ERROR: Found " & iFound.ToString & _
            " rows where casenumber = event_id or one of the ids is null. All such rows were deleted from the feed. " & _
            "Here is a list (note that there has been no formatting applied to this list, " & _
            "and the data are semi-colon delimited regardless of the actual formatting or " & _
            "delimiting of the final file):" & vbCr & vbLf & sFound)
        End If

        Return bFound

    End Function

End Class
