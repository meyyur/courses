Option Strict Off
Option Explicit On
Imports System
Imports System.Xml.Serialization
Imports System.Data.OleDb
Imports System.Xml
Imports System.Web.Mail
Imports System.Windows.Forms
Imports System.IO
Imports System.Reflection
Imports DataExtractClasses
Imports wkab


Public Class clsDataExtract
    '*****************************************************************************
    'Written by Lee Rutty Jan/Feb 2003
    'This class processes xml data extract definition files to create a data output
    'file for transmission to the customer. All relevant flexibility is written into
    'it to allow new feeds to be defined by creating new extract definition files,
    'not new applications.
    '*****************************************************************************
    Private m_sInputFileName As String
    Private m_sOutputFileName As String
    Private m_sLogFileName As String
    Private m_sRunDate As String
    Private m_sHeader As String
    Private m_sFooter As String
    Private m_lRecordCount As Integer
    Private m_iLogLevel As Integer
    Private m_JobName As String
    Private m_xmlDoc As New Xml.XmlDocument()
    Private m_dsData As DataSet = New DataSet() 'this is the primary dataset
    Private Const HIGH As Integer = 1   'log everything
    Private Const MED As Integer = 2    'log most
    Private Const LOW As Integer = 3    'log only errors
    Private m_bWarning As Boolean
    Public m_bSkipProcessing As Boolean
    Public Shared strDBLog As String
    Private Declare Sub Sleep Lib "kernel32" (ByVal dwMilliseconds As Long)

    Public Function fGiveVersion() As String
        fGiveVersion = System.Reflection.Assembly.GetExecutingAssembly().GetName().Version.ToString()
    End Function

    Public Sub FTPOutputFileProcessFileTest(ByVal sFileName As String)
        If Not Initialize(sFileName) Then
            'error
        End If

        If Not FTPOutputFile() Then
            'error
            WriteLog("FTPOutputFile failed.", LOW, 2)
            EmailConfirmation(True)
            Exit Sub
        End If
    End Sub

    Public Function ProcessFile(ByRef sFileName As String) As Data.DataSet
        'the main driver function, the public interface of this class
        Dim DBFlag As Boolean
        Dim sSQL As String
        Dim sParams As String

        m_sRunDate = CStr(Now)
        If Not Initialize(sFileName) Then
            'error
        End If
        'init flag
        m_bWarning = False

        m_JobName = GetValueFromFile("JobName", "name")
        WriteLog("Start: " & m_JobName, HIGH)
        'Changes for RADAR-13330 Database metatable is filled 
        DBFlag = DBLogStart(m_JobName, CStr(Now), "DataExtract")


        WriteLog("Processing file " & sFileName & ".", HIGH)

        'variable declaration
        Dim xmlElement, xmlChild As Xml.XmlElement
        Dim iChild As Integer
        Dim sNodeName, sPriority As String
        Dim colDataSets As New Collection

        'LAR 11/06/2003 - added preprocessing capabilities. xml will look like this:
        '<Preprocessing>
        '    <casenumber Query="call PK_coreutility.SP_SET_CASENUMBERS()" Param="" replace="" />
        '    <21dayproc Query="call PK_FEEDS.sp_avon_21day_clock()" Param="" replace="" />
        '</Preprocessing>
        'this defines any queries or functions that need to be run prior to the main query being run.
        'The example above is for the avon feed, where there are 2 stored procs that need to run to 
        'pre-process the data. Originally they were scheduled thru CRON but this created too many 
        'vulnerabilities and dependencies so it makes more sense to bring it into the app.

        'For Preprocessing

        xmlElement = m_xmlDoc.SelectSingleNode("Root//Preprocessing")
        If TypeName(xmlElement) <> "Nothing" Then
            If xmlElement.HasChildNodes Then
                For iChild = 0 To xmlElement.ChildNodes.Count - 1
                    xmlChild = xmlElement.ChildNodes(iChild)
                    If TypeName(xmlChild) <> "Nothing" Then
                        sNodeName = xmlChild.Name
                        If xmlChild.HasAttributes Then
                            sSQL = GetValueFromFile(sNodeName, "Query")
                            sParams = GetValueFromFile(sNodeName, "Params")
                            'Changes for RADAR-13330 Try catch block added
                            Try
                                WriteLog("Running preprocessing query " & sNodeName & ".", HIGH)
                                If Not RunSQL(m_dsData, sSQL, sParams, sNodeName) Then
                                    'error
                                    WriteLog("Preprocessing failed on " & sNodeName & ". Extract aborted.", LOW, 2)
                                    DBLogEnd(m_JobName, CStr(Now), "FAIL", "DataExtract", DBFlag)
                                    EmailConfirmation(True)
                                    Exit Function
                                End If
                            Catch ex As Exception
                                LogError(ex, "Preprocessing")
                                WriteLog("Preprocessing failed on " & sNodeName & ". Extract aborted.", LOW, 3)
                                DBLogEnd(m_JobName, CStr(Now), "FAIL", "DataExtract", DBFlag)
                                EmailConfirmation(True)
                                Throw ex
                            End Try
                        End If
                    End If
                Next
            End If
        End If
       

        'LAR 11/06/2003 - end
        'loop thru the queries and process each

        xmlElement = m_xmlDoc.SelectSingleNode("Root//SQL")
        'process each query in the SQL section, along with all other processing.
        'Note that in some situations we will need to have several main queries,
        'ie if we need to pull data from wkab/fineos in one proc and drms in another.
        'we will create a collection of datasets of them, and combine them according
        'to their defined priority to create the final output dataset.
        '***NOTE: not implemented. So far we use the append and prepend subquery 
        'functionality to accomplish this.
        If TypeName(xmlElement) <> "Nothing" Then
            'find each child node in turn; each has details on a query
            '***NOTE: FOR THIS VERSION WE ONLY ALLOW ONE MAIN QUERY!!!!
            If xmlElement.HasChildNodes Then
                For iChild = 0 To xmlElement.ChildNodes.Count - 1
                    xmlChild = xmlElement.ChildNodes(iChild)
                    If TypeName(xmlChild) <> "Nothing" Then
                        'the node name is the name/number of the query
                        sNodeName = xmlChild.Name
                        If xmlChild.HasAttributes Then
                            sSQL = GetValueFromFile(sNodeName, "Query")
                            sParams = GetValueFromFile(sNodeName, "Params")
                            sPriority = GetValueFromFile(sNodeName, "priority")
                            If GetValueFromFile(sNodeName, "skip_processing") = Nothing Then
                                m_bSkipProcessing = False
                            Else
                                m_bSkipProcessing = CBool(GetValueFromFile(sNodeName, "skip_processing"))
                            End If
                            'Changes for RADAR-13330 Try catch block added
                            Try
                                WriteLog("Running main query " & sNodeName & ".", HIGH)
                                If Not RunSQL(m_dsData, sSQL, sParams, sNodeName) Then
                                    'error
                                    WriteLog("Main Query failed on " & sNodeName & ". Extract aborted.", LOW, 2)
                                    DBLogEnd(m_JobName, CStr(Now), "FAIL", "DataExtract", DBFlag)
                                    EmailConfirmation(True)
                                    Exit Function
                                End If
                            Catch ex As Exception
                                LogError(ex, "Main Query")
                                WriteLog("Main Query failed on " & sNodeName & ". Extract aborted.", LOW, 3)
                                DBLogEnd(m_JobName, CStr(Now), "FAIL", "DataExtract", DBFlag)
                                EmailConfirmation(True)
                                Throw ex
                                'Exit Function
                            End Try



                            'If Not RunBlendQueries(m_dsData, sNodeName) Then
                            '    'error
                            '    WriteLog("RunSubQueries failed on " & sNodeName & ". Extract aborted.", LOW)
                            '    EmailConfirmation(True)
                            '    Exit Function
                            'End If
                            If Not m_bSkipProcessing Then
                                'Changes for RADAR-13330 Try catch block added
                                Try
                                    If Not RunSubQueries(m_dsData, sNodeName) Then
                                        'error
                                        WriteLog("RunSubQueries failed on " & sNodeName & ". Extract aborted.", LOW, 2)
                                        'WriteLog("Starting insertion in DetailTable for database logging.", HIGH)
                                        'If (DBLogEnd(CStr(Now), "FAIL", "DataExtract", DBFlag)) Then
                                        '    WriteLog("Insert in DetailTable completed successfully.", HIGH)
                                        'Else
                                        '    WriteLog("Insert in DetailTable failed.", HIGH, 2)
                                        'End If
                                        DBLogEnd(m_JobName, CStr(Now), "FAIL", "DataExtract", DBFlag)
                                        EmailConfirmation(True)
                                        Exit Function
                                    End If
                                Catch ex As Exception
                                    LogError(ex, "Sub Query")
                                    WriteLog("Sub Query failed on " & sNodeName & ". Extract aborted.", LOW, 3)
                                    DBLogEnd(m_JobName, CStr(Now), "FAIL", "DataExtract", DBFlag)
                                    EmailConfirmation(True)
                                    Throw ex
                                    'Exit Function
                                End Try

                                'If Not FormatData(m_dsData, sNodeName) Then
                                '    'error
                                '    WriteLog("FormatData failed on " & sNodeName & ". Extract aborted.", LOW)
                                '    EmailConfirmation(True)
                                '    Exit Function
                                'End If

                                'Changes for RADAR-13330 Try catch block added
                                Try
                                    If Not FilterData(m_dsData, sNodeName) Then
                                        'error
                                        WriteLog("FilterData failed on " & sNodeName & ". Extract aborted.", LOW, 2)
                                        DBLogEnd(m_JobName, CStr(Now), "FAIL", "DataExtract", DBFlag)
                                        EmailConfirmation(True)
                                        Exit Function
                                    End If
                                Catch ex As Exception
                                    LogError(ex, "Filter Data")
                                    WriteLog("FIlter Data failed on " & sNodeName & ". Extract aborted.", LOW, 3)
                                    DBLogEnd(m_JobName, CStr(Now), "FAIL", "DataExtract", DBFlag)
                                    EmailConfirmation(True)
                                    Throw ex
                                    'Exit Function
                                End Try

                                'do the header & footer now, because they may require 
                                'data from columns that are about to be stripped
                                m_lRecordCount = m_dsData.Tables(0).Rows.Count
                                'm_sHeader = GenerateHeader()
                                m_sHeader = GenerateHeaderFooter("Header")
                                'm_sFooter = GenerateFooter()
                                m_sFooter = GenerateHeaderFooter("Footer")

                                'Changes for RADAR-13330 Try catch block added    
                                Try
                                    If Not StripColumns(m_dsData, sNodeName) Then
                                        'error
                                        WriteLog("StripColumns failed on " & sNodeName & ". Extract aborted.", LOW, 2)
                                        DBLogEnd(m_JobName, CStr(Now), "FAIL", "DataExtract", DBFlag)
                                        EmailConfirmation(True)
                                        Exit Function
                                    End If
                                Catch ex As Exception
                                    LogError(ex, "StripColumns")
                                    WriteLog("StripColumns failed on " & sNodeName & ". Extract aborted.", LOW, 3)
                                    DBLogEnd(m_JobName, CStr(Now), "FAIL", "DataExtract", DBFlag)
                                    EmailConfirmation(True)
                                    Throw ex
                                    'Exit Function
                                End Try

                                'Changes for RADAR-13330 Try catch block added
                                Try
                                    If Not CleanseData(m_dsData) Then
                                        'error
                                        WriteLog("CleanseData failed on " & sNodeName & ". Extract aborted.", LOW, 2)
                                        DBLogEnd(m_JobName, CStr(Now), "FAIL", "DataExtract", DBFlag)
                                        EmailConfirmation(True)
                                        Exit Function
                                    End If
                                Catch ex As Exception
                                    LogError(ex, "StripColumns")
                                    WriteLog("CleanseData failed on " & sNodeName & ". Extract aborted.", LOW, 3)
                                    DBLogEnd(m_JobName, CStr(Now), "FAIL", "DataExtract", DBFlag)
                                    EmailConfirmation(True)
                                    Throw ex

                                End Try

                                'Changes for RADAR-13330 Try catch block added
                                Try
                                    If Not SortData(m_dsData) Then
                                        'error
                                        WriteLog("SortData failed on " & sNodeName & ". Extract aborted.", LOW, 2)
                                        DBLogEnd(m_JobName, CStr(Now), "FAIL", "DataExtract", DBFlag)
                                        EmailConfirmation(True)
                                        Exit Function
                                    End If
                                Catch ex As Exception
                                    LogError(ex, "SortData")
                                    WriteLog("SortData failed on " & sNodeName & ". Extract aborted.", LOW, 3)
                                    DBLogEnd(m_JobName, CStr(Now), "FAIL", "DataExtract", DBFlag)
                                    EmailConfirmation(True)
                                    Throw ex
                                    'Exit Function
                                End Try
                                'now add this dataset to the collection, with its priority as its key
                                'colDataSets.Add(dsData1, sPriority)
                            Else
                                'error
                                'no attributes
                            End If
                        Else
                            'error
                            'child node is nothing
                        End If
                    End If
                Next
                'now we have a collection of one or more datasets, each with an 
                'assigned priority. We will now combine them into a single
                'output dataset, by glueing them together in priority order.
            Else
                'error
                'no child nodes
            End If
        Else
            'error
            'typename = nothing
        End If

        'if we have more than 1 ds in the collection, merge them
        'If colDataSets.Count > 1 Then
        '    'merge them
        '    Dim i As Integer
        '    For i = 1 To colDataSets.Count
        '        Dim sTableName As String = "Table" & CStr(i)
        '        Dim tbTable As New DataTable()
        '        Dim dsData1 As New DataSet()
        '        dsData1 = colDataSets.Item(i)
        '        tbTable = dsData1.Tables(0).Copy()
        '        tbTable.TableName = sTableName
        '        m_dsData.Tables.Add(tbTable)
        '    Next
        'Else
        '        'otherwise go with the one we have
        '    m_dsData = colDataSets.Item(1)
        'End If

        If Not m_bSkipProcessing Then
            'Changes for RADAR-13330 Try catch block added
            Try
                If Not ArchiveFile() Then
                    'error
                    WriteLog("ArchiveFile failed. Extract aborted.", LOW, 2)
                    DBLogEnd(m_JobName, CStr(Now), "FAIL", "DataExtract", DBFlag)
                    EmailConfirmation(True)
                    Exit Function
                End If
            Catch ex As Exception
                LogError(ex, "ArchiveFile")
                WriteLog("ArchiveFile failed. Extract aborted.", LOW, 3)
                DBLogEnd(m_JobName, CStr(Now), "FAIL", "DataExtract", DBFlag)
                EmailConfirmation(True)
                Throw ex
                'Exit Function
            End Try

            'Changes for RADAR-13330 Try catch block added
            Try
                If Not OutputData(m_dsData) Then
                    'error
                    WriteLog("OutputData failed. Extract aborted.", LOW, 2)
                    DBLogEnd(m_JobName, CStr(Now), "FAIL", "DataExtract", DBFlag)
                    EmailConfirmation(True)
                    Exit Function
                End If
            Catch ex As Exception
                LogError(ex, "OutputData")
                WriteLog("OutputData failed. Extract aborted.", LOW, 3)
                DBLogEnd(m_JobName, CStr(Now), "FAIL", "DataExtract", DBFlag)
                EmailConfirmation(True)
                Throw ex
                'Exit Function
            End Try

            'Changes for RADAR-13330 Try catch block added
            Try
                If Not EncryptOutputFile() Then
                    'error
                    WriteLog("EncryptOutputFile failed.", LOW, 2)
                    DBLogEnd(m_JobName, CStr(Now), "FAIL", "DataExtract", DBFlag)
                    EmailConfirmation(True)
                    Exit Function
                End If
            Catch ex As Exception
                LogError(ex, "EncryptOutputFile")
                WriteLog("EncryptOutputFile failed. Extract aborted.", LOW, 3)
                DBLogEnd(m_JobName, CStr(Now), "FAIL", "DataExtract", DBFlag)
                EmailConfirmation(True)
                Throw ex
                'Exit Function
            End Try

            'Changes for RADAR-13330 Try catch block added
            Try
                If Not SetRunDates() Then
                    'error
                    WriteLog("SetRunDates failed. Extract aborted.", LOW, 2)
                    DBLogEnd(m_JobName, CStr(Now), "FAIL", "DataExtract", DBFlag)
                    EmailConfirmation(True)
                    Exit Function
                End If
            Catch ex As Exception
                LogError(ex, "SetRunDates")
                WriteLog("SetRunDates failed. Extract aborted.", LOW, 3)
                DBLogEnd(m_JobName, CStr(Now), "FAIL", "DataExtract", DBFlag)
                EmailConfirmation(True)
                Throw ex

            End Try

            'Try to update the sequence number
            If Not SetSequenceNumber() Then
                'Really not an error but we may want to log 
                'that there was no Sequence Number TAG
            End If

            Application.DoEvents()

        End If

        'Changes for RADAR-13330 Try catch block added
        Try
            If Not FTPOutputFile() Then
                'error
                WriteLog("FTPOutputFile failed.", LOW, 2)
                DBLogEnd(m_JobName, CStr(Now), "FAIL", "DataExtract", DBFlag)
                EmailConfirmation(True)
                Exit Function
            End If
        Catch ex As Exception
            LogError(ex, "FTPOutputFile")
            WriteLog("FTPOutputFile failed.Extract aborted.", LOW, 3)
            DBLogEnd(m_JobName, CStr(Now), "FAIL", "DataExtract", DBFlag)
            EmailConfirmation(True)
            Throw ex
        End Try

        Application.DoEvents()
        WriteLog("Finish: " & GetValueFromFile("JobName", "name"), HIGH)
       

        'Changes for RADAR-13330 Try catch block added
        Try
            If Not EmailConfirmation(False) Then
                'error
                WriteLog("Email Confirmation failed.Extract aborted", LOW, 2)
                DBLogEnd(m_JobName, CStr(Now), "FAIL", "DataExtract", DBFlag)
                Exit Function
            End If
        Catch ex As Exception
            LogError(ex, "EmailConfirmation")
            WriteLog("EmailConfirmation failed. Extract aborted.", LOW, 3)
            DBLogEnd(m_JobName, CStr(Now), "FAIL", "DataExtract", DBFlag)
            Throw ex
        End Try

        'Changes for RADAR-13330 Log is written in log table
        DBLogEnd(m_JobName, CStr(Now), "PASS", "DataExtract", DBFlag)

        ProcessFile = m_dsData
    End Function

    Private Function RunBlendQueries(ByRef dsData As DataSet, ByVal sQueryName As String)
        'This function runs any described blend queries and merges the defined data with
        'the results from the main query
        '*****NOTE THIS FN IS ONLY PARTLY CODED. I DECIDED I DON'T NEED IT AFTER ALL...

        'The param can be a column name, straight text or a ref to another value in the file.
        Dim sSQL As String
        RunBlendQueries = True

        Dim xmlElement, xmlChild As Xml.XmlElement
        Dim iChild As Integer
        Dim sNodeName, sParams As String

        'find the blendquery main node
        xmlElement = m_xmlDoc.SelectSingleNode("Root//" & sQueryName & "//BlendQueries")
        If TypeName(xmlElement) <> "Nothing" Then
            'find each child node in turn; each has a query and params  
            If xmlElement.HasChildNodes Then
                WriteLog("Running blend queries.", HIGH)
                For iChild = 0 To xmlElement.ChildNodes.Count - 1
                    xmlChild = xmlElement.ChildNodes(iChild)
                    If TypeName(xmlChild) <> "Nothing" Then
                        sNodeName = xmlChild.Name
                        If xmlChild.HasAttributes Then
                            'run the query and populate a temp dataset
                            sSQL = GetValueFromFile(sNodeName, "Query")
                            sParams = GetValueFromFile(sNodeName, "Params")
                            Dim dsData1 As New DataSet
                            If Not RunSQL(dsData1, sSQL, sParams, sNodeName) Then
                                'error
                                WriteLog("RunBlendQueries failed on " & sNodeName & ". Extract aborted.", LOW, 2)
                                EmailConfirmation(True)
                                Exit Function
                            Else
                                'compare to the original
                                'if it is the same, append the rows
                                m_dsData.Merge(dsData1, True, MissingSchemaAction.Add)
                                'if not, pop a warning and bail
                            End If
                        End If
                    End If
                Next
            End If
        End If
    End Function


    Private Function CleanseData(ByRef dsData As DataSet) As Boolean
        'this function is a place to do any strange data-cleansing chores
        'that may be necessary. Case in point: fineos stores null dates
        'as 01/01/1753 in many columns. They do not intend to fix this. 
        'Instead they deal with it whenever the column is referenced (ui etc)
        'and filter out any 1753 date. No, really, I shit you not. So I
        'have to deal with it here.
        CleanseData = True
        'null out any 1753 dates
        Dim myRow As DataRow
        Dim myColumn As DataColumn
        For Each myRow In dsData.Tables(0).Rows
            For Each myColumn In dsData.Tables(0).Columns
                'LAR 09/26/2003 - added in code to handle null accident values (s/b 1 or 0,
                'some are showing up as null
                If myColumn.ColumnName.ToUpper = "ACCIDENT" Then
                    If myRow(myColumn) Is System.DBNull.Value Then
                        myRow(myColumn) = False
                    End If
                End If
                If Not IsDBNull(myRow(myColumn)) Then
                    Select Case myRow(myColumn).GetType.FullName
                        Case "System.DateTime"
                            'if it is a date...
                            If System.DateTime.Equals(myRow(myColumn), CDate("01/01/1753")) Then
                                'null it out
                                myRow(myColumn) = System.DBNull.Value
                            End If
                        Case "System.String"
                            'if it is a string...
                            If myRow(myColumn) = "17530101" Then
                                myRow(myColumn) = System.DBNull.Value
                            End If
                        Case Else
                            'do nothing
                    End Select
                End If
            Next
        Next

    End Function

    Private Function GenerateFooter() As String
        Dim sOutput, sFooter As String
        Dim xmlElement As Xml.XmlElement

        xmlElement = m_xmlDoc.SelectSingleNode("Root//Footer[@Footer]")
        sFooter = ""
        sOutput = ""
        If TypeName(xmlElement) <> "Nothing" Then
            sFooter = xmlElement.GetAttribute("Footer")
        End If
        'now, the Footer may just be straight text that we just need to translate.
        'OR, it might be fixed width (regardless of the file type)
        'if the Footer node has any child nodes, it means it is fixed width
        If xmlElement.HasChildNodes Then
            'fixed width will always have double-bars separating the values
            Dim sFooterFields() As String = Split(sFooter, "||")
            Dim sTemp As String
            Dim i As Integer
            For i = 0 To UBound(sFooterFields)
                'get the translated value for this field
                sTemp = Translate(sFooterFields(i))
                sTemp = FormatDataField(sTemp, "Root//Footer/field" & CStr(i + 1))
                'get the node defining the format for this column
                'xmlChild = m_xmlDoc.SelectSingleNode("Root//Footer/field" & CStr(i + 1))
                'If TypeName(xmlChild) <> "Nothing" Then
                '    'type is numeric, string or date
                '    sType = xmlChild.GetAttribute("type")
                '    sWidth = xmlChild.GetAttribute("width")
                '    Select Case sType
                '        Case "string"
                '            'control for nulls
                '            If IsDBNull(sTemp) Or sTemp = "" Then
                '                'simply pad with the total number of spaces
                '                sTemp = PadString("", CInt(sWidth), "R")
                '            Else
                '                'use .NET's padding to add the correct # of spaces
                '                sTemp = sTemp.PadRight(CInt(sWidth))
                '            End If
                '        Case "numeric"
                '            'control for nulls
                '            Dim dblVal As Double
                '            If IsDBNull(sTemp) Or sTemp = "" Then
                '                dblVal = 0
                '            Else
                '                dblVal = CDbl(sTemp)
                '            End If
                '            'find out if the width attribute is a number or a dec precision.
                '            'if it is a number we will pad left with that many spaces
                '            'otherwise we will format it per the decimal precision
                '            'If InStr(sWidth, ".") > 0 Then
                '            sTemp = PadNumeric(dblVal, CDbl(sWidth))
                '            'Else
                '            'sTemp = CStr(dblVal).PadLeft(CInt(sWidth))
                '            'sTemp = CStr(Format(dblVal, sWidth))
                '            'End If
                '        Case "date"
                '            'if it is a date then the formatting has been done in the translate
                '        Case Else
                '            '
                '    End Select
                'End If
                sOutput &= sTemp
            Next
        Else
            sOutput = Translate(sFooter)
        End If

        Return sOutput

    End Function

    Private Function GenerateHeader() As String
        Dim sOutput, sHeader As String
        Dim xmlElement As Xml.XmlElement

        'LAR 04/29/2003
        Dim sQuoteStrings As String = ""
        'see if we are to put all values in quotes
        'ie "02","I","04/24/2003","117001","04/02/2003","STD","STD","04/14/2003"
        If GetValueFromFile("Output", "quote_strings") = "true" Then
            sQuoteStrings = Chr(34)
        End If
        'LAR 04/29/2003 - end

        xmlElement = m_xmlDoc.SelectSingleNode("Root//Header[@Header]")
        sHeader = ""
        sOutput = ""
        If TypeName(xmlElement) <> "Nothing" Then
            sHeader = xmlElement.GetAttribute("Header")
        End If
        'now, the header may just be straight text that we just need to translate.
        'OR, it might be fixed width (regardless of the file type)
        'if the header node has any child nodes, it means it is fixed width
        If xmlElement.HasChildNodes Then
            'fixed width will always have double-bars separating the values
            Dim sHeaderFields() As String = Split(sHeader, "||")
            Dim sTemp As String
            Dim i As Integer
            For i = 0 To UBound(sHeaderFields)
                'get the translated value for this field
                sTemp = Translate(sHeaderFields(i))
                sTemp = FormatDataField(sTemp, "Root//Header/field" & CStr(i + 1))
                'get the node defining the format for this column
                'xmlChild = m_xmlDoc.SelectSingleNode("Root//field" & CStr(i + 1))
                'If TypeName(xmlChild) <> "Nothing" Then
                '    'type is numeric, string or date
                '    sType = xmlChild.GetAttribute("type")
                '    sWidth = xmlChild.GetAttribute("width")
                '    Select Case sType
                '        Case "string"
                '            'control for nulls
                '            If IsDBNull(sTemp) Or sTemp = "" Then
                '                'simply pad with the total number of spaces
                '                sTemp = PadString("", CInt(sWidth), "R")
                '            Else
                '                'use .NET's padding to add the correct # of spaces
                '                sTemp = sTemp.PadRight(CInt(sWidth))
                '            End If
                '        Case "numeric"
                '            'control for nulls
                '            Dim dblVal As Double
                '            If IsDBNull(sTemp) Or sTemp = "" Then
                '                dblVal = 0
                '            Else
                '                dblVal = CDbl(sTemp)
                '            End If
                '            'find out if the width attribute is a number or a dec precision.
                '            'if it is a number we will pad left with that many spaces
                '            'otherwise we will format it per the decimal precision
                '            'If InStr(sWidth, ".") > 0 Then
                '            sTemp = PadNumeric(dblVal, CDbl(sWidth))
                '            'Else
                '            'sTemp = CStr(dblVal).PadLeft(CInt(sWidth))
                '            'sTemp = CStr(Format(dblVal, sWidth))
                '            'End If
                '        Case "date"
                '            'if it is a date then the formatting has been done in the translate
                '        Case Else
                '            '
                '    End Select
                'End If
                sOutput &= sTemp
            Next
        Else
            sOutput = Translate(sHeader)
        End If

        Return sOutput

    End Function

    Private Function GenerateHeaderFooter(ByVal sMode As String) As String
        'sMode will be "Header" or "Footer"
        Dim sOutput, sHeaderFooter As String
        Dim xmlElement As Xml.XmlElement

        'LAR 04/29/2003
        Dim sQuoteStrings As String = ""
        sOutput = ""
        'see if we are to put all values in quotes
        'ie "02","I","04/24/2003","117001","04/02/2003","STD","STD","04/14/2003"
        If GetValueFromFile("Output", "quote_strings") = "true" Then
            sQuoteStrings = Chr(34)
        End If

        xmlElement = m_xmlDoc.SelectSingleNode("Root//" & sMode & "[@" & sMode & "]")
        If TypeName(xmlElement) <> "Nothing" Then
            sHeaderFooter = xmlElement.GetAttribute(sMode)
            'now, the header/footer may just be straight text that we just need to translate.
            'OR, it might be fixed width (regardless of the file type)
            'if the header/footer node has any child nodes, it means it is fixed width
            If xmlElement.HasChildNodes Then
                'fixed width will always have double-bars separating the values
                Dim sHeaderFooterFields() As String = Split(sHeaderFooter, "||")
                Dim sTemp As String
                Dim i As Integer
                For i = 0 To UBound(sHeaderFooterFields)
                    'get the translated value for this field
                    sTemp = Translate(sHeaderFooterFields(i))
                    'now format it per specs
                    sTemp = FormatDataField(sTemp, "Root//" & sMode & "/field" & CStr(i + 1))
                    sOutput &= sTemp
                Next
            Else
                sOutput = Translate(sHeaderFooter)
            End If
        End If

        Return sOutput
    End Function

    Private Function EncryptOutputFile() As Boolean
        EncryptOutputFile = True
        Dim sKey As String
        Dim sCommandLine As String
        Dim sPassPhrase As String

        'If GetValueFromFile("encryption", "tool") = "PGP" Then
        '    WriteLog("Encrypting data file.", HIGH)

        '    sKey = GetValueFromFile("encryption", "key")
        '    sMode = GetValueFromFile("encryption", "mode")
        '    If sMode.ToLower = "ascii" Or sMode.ToLower = "text" Then
        '        sMode = "-a"
        '    Else
        '        sMode = ""
        '    End If

        '    sCommandLine = "pgp -e " & m_sOutputFileName & " " & sMode & " -r " & Chr(34) & sKey & Chr(34) & " --signer Core --passphrase eligibility --overwrite remove"
        '    Shell(sCommandLine, AppWinStyle.MinimizedNoFocus, True) 'use wait param true so pgp finishes before ftp
        '    'ok, wait for 16 seconds to let the encryption completely finish
        '    Sleep(16000)
        'End If

        If GetValueFromFile("encryption", "tool") = "PGP" Then
            WriteLog("Encrypting data file.", HIGH)

            sKey = GetValueFromFile("encryption", "key")
            sPassPhrase = GetValueFromFile("encryption", "passphrase")  ' In most cases the passphrase is eligibility for dataextract server


            If sPassPhrase = "" Then
                sCommandLine = "gpg --batch --yes -r " & Chr(34) & sKey & Chr(34) & " --trust-model always -e " & m_sOutputFileName
            Else
                sCommandLine = "gpg --batch --yes --passphrase " & sPassPhrase & " -r " & Chr(34) & sKey & Chr(34) & " --trust-model always -e " & m_sOutputFileName
            End If


            Shell(sCommandLine, AppWinStyle.MinimizedNoFocus, True) 'use wait param true so pgp finishes before ftp
            'ok, wait for 16 seconds to let the encryption completely finish
            Sleep(16000)
        End If
    End Function

    Private Function FormatData(ByRef dsData As DataSet, ByVal sQueryName As String) As Boolean
        'find the format entries in the file and format the columns as defined
        Dim xmlElement, xmlChild As Xml.XmlElement
        Dim iChild, iAttribute, iIndex As Integer
        Dim sName, sValue, sNodeName As String
        Dim sTemp As String

        FormatData = True

        'xmlElement = m_xmlDoc.SelectSingleNode("Root//Format")
        xmlElement = m_xmlDoc.SelectSingleNode("Root//" & sQueryName & "//Format")
        If TypeName(xmlElement) <> "Nothing" Then
            'find each child node in turn; each has details on a col to format
            If xmlElement.HasChildNodes Then
                WriteLog("Formating data file.", HIGH)
                For iChild = 0 To xmlElement.ChildNodes.Count - 1
                    xmlChild = xmlElement.ChildNodes(iChild)
                    If TypeName(xmlChild) <> "Nothing" Then
                        'the node name is the name of the column
                        sNodeName = xmlChild.Name
                        'retrieve the attributes and set the variables
                        If xmlChild.HasAttributes Then
                            For iAttribute = 0 To xmlChild.Attributes.Count - 1
                                'name is the data type
                                sName = xmlChild.Attributes.Item(iAttribute).Name
                                'value is the format string ie 000-00-0000 for SSN
                                sValue = xmlChild.Attributes.Item(iAttribute).Value
                                'apply the formatting per the data type
                                WriteLog("Formating " & sNodeName, HIGH)
                                Select Case sName
                                    Case "boolean"
                                        For iIndex = 0 To dsData.Tables(0).Rows.Count - 1
                                            'get the data at this col
                                            If Not IsDBNull(dsData.Tables(0).Rows(iIndex).Item(sNodeName)) Then
                                                sTemp = dsData.Tables(0).Rows(iIndex).Item(sNodeName)
                                            Else
                                                sTemp = ""
                                            End If
                                            'right now this is the only boolean format we support...
                                            If sValue = "Y/N" Then
                                                'if the data is not already Y/N
                                                If sTemp <> "Y" And sTemp <> "N" Then
                                                    If sTemp = "1" Then
                                                        sTemp = "Y"
                                                    Else
                                                        sTemp = "N"
                                                    End If
                                                End If
                                            End If
                                            If sValue = "0/1" Or sValue = "1/0" Then
                                                'if the data is not already 1/0
                                                If sTemp <> "1" And sTemp <> "0" Then
                                                    If sTemp = "True" Then
                                                        sTemp = "1"
                                                    Else
                                                        sTemp = "0"
                                                    End If
                                                End If
                                            End If
                                            Try
                                                'change the value of the field to the formatted value
                                                dsData.Tables(0).Rows(iIndex).Item(sNodeName) = sTemp
                                            Catch objException As Exception
                                                LogError(objException, "FormatData")
                                                FormatData = False
                                                Exit Function
                                            End Try
                                        Next
                                    Case "numeric", "numeric_StripDecimal"
                                        Dim dDbl As Double
                                        For iIndex = 0 To dsData.Tables(0).Rows.Count - 1
                                            'if it is null, leave it null
                                            If Not IsDBNull(dsData.Tables(0).Rows(iIndex).Item(sNodeName)) Then
                                                'get the data at this col
                                                sTemp = dsData.Tables(0).Rows(iIndex).Item(sNodeName)
                                                'cast it just in case
                                                dDbl = CDbl(sTemp)
                                                'apply the format
                                                sTemp = String.Format("{0:" & sValue & "}", dDbl)
                                                'if we are doing an 'implied decimal' format we need
                                                'to strip out the decimal itself
                                                If sName = "numeric_StripDecimal" Then
                                                    sTemp = Replace(sTemp, ".", "")
                                                End If
                                                Try
                                                    'change the value of the field to the formatted value
                                                    dsData.Tables(0).Rows(iIndex).Item(sNodeName) = sTemp
                                                Catch objException As Exception
                                                    LogError(objException, "FormatData")
                                                    FormatData = False
                                                    Exit Function
                                                End Try
                                            End If
                                        Next
                                    Case "date"
                                        Dim dtDate As Date
                                        Dim dtTemp As New DateTime
                                        For iIndex = 0 To dsData.Tables(0).Rows.Count - 1
                                            'if it is null, leave it null
                                            If Not IsDBNull(dsData.Tables(0).Rows(iIndex).Item(sNodeName)) Then
                                                'get the data at this col
                                                sTemp = dsData.Tables(0).Rows(iIndex).Item(sNodeName)
                                                'cast it just in case
                                                dtDate = CDate(sTemp)
                                                'apply the format
                                                sTemp = String.Format("{0:" & sValue & "}", dtDate)
                                                Try
                                                    'change the value of the field to the formatted value
                                                    'check underlying datatype: sometimes we
                                                    'will have dates as strings
                                                    If dsData.Tables(0).Rows(iIndex).Item(sNodeName).GetType.FullName = "System.String" Then
                                                        dsData.Tables(0).Rows(iIndex).Item(sNodeName) = sTemp
                                                    Else
                                                        'If IsDate(sTemp) Then
                                                        '    dsData.Tables(0).Rows(iIndex).Item(sNodeName) = CDate(sTemp)
                                                        '    'dsData.Tables(0).Rows(iIndex).Item(sNodeName) = String.Format("{0:" & sValue & "}", dtDate)
                                                        dtTemp = System.Convert.ToDateTime(sTemp)
                                                        dsData.Tables(0).Rows(iIndex).Item(sNodeName) = dtTemp
                                                        'Dim sFormats As String() = dtTemp.GetDateTimeFormats
                                                        'End If
                                                    End If
                                                Catch objException As Exception
                                                    LogError(objException, "FormatData")
                                                    FormatData = False
                                                    Exit Function
                                                End Try
                                            End If
                                        Next
                                End Select
                            Next
                        End If
                    End If
                Next
            End If
        End If
    End Function

    Private Function EmailConfirmation(ByVal bError As Boolean) As Boolean
        'send a conf email to everyone defined in the file
        Dim sMsg, sTo, sJob, sFrom, sLog, sBody As String
        Dim iAttribute As Integer
        Dim xmlElement As Xml.XmlElement

        EmailConfirmation = True

        'collect the properties
        sJob = GetValueFromFile("JobName", "name")
        sMsg = "DO NOT REPLY TO THIS EMAIL. CONTACT THE HELP DESK DIRECTLY WITH ANY QUESTIONS/PROBLEMS." & vbCrLf & vbCrLf
        sMsg &= sJob & " ran at " & CStr(m_sRunDate) & "."

        If GetValueFromFile("email", "body_msg") Is Nothing Then
        Else
            sBody = GetValueFromFile("email", "body_msg")
            sMsg &= vbCrLf & sBody
        End If

        If bError Then
            sMsg &= vbCrLf & "There were errors."
            sJob &= " - ERRORS"
        End If
        If m_bWarning Then
            sJob &= " - WARNINGS"
        End If

        If GetValueFromFile("email", "sendsecure") = "true" Then
            sJob &= " [send secure]"
        End If

        sFrom = GetValueFromFile("email", "From")
        sLog = GetValueFromFile("Output", "logdir")
        If Right(sLog, 1) <> "\" Then sLog &= "\"
        sLog &= GetValueFromFile("Output", "logfile")
        'capability to email the output file as well
        If GetValueFromFile("email", "output") = "true" Then
            'check for existence of output file first
            If File.Exists(m_sOutputFileName) Then
                sLog &= "," & m_sOutputFileName
            End If
        End If

        'loop thru all entered email addresses and send email to them
        xmlElement = m_xmlDoc.SelectSingleNode("Root//To")
        If TypeName(xmlElement) <> "Nothing" Then
            If xmlElement.HasAttributes Then
                'retrieve the attributes and set the variables
                For iAttribute = 0 To xmlElement.Attributes.Count - 1
                    sTo = xmlElement.Attributes.Item(iAttribute).Value
                    If Not SendMail(sJob, sTo, sFrom, sMsg, sLog) Then
                        'error
                        EmailConfirmation = False
                        Exit Function
                    End If
                Next
            End If
        End If

    End Function

    Private Function SendMail(ByVal sSubject As String, ByVal sSendTo As String, ByVal sFrom As String, ByVal sBody As String, Optional ByVal sAttachment As String = "") As Boolean
        Dim mailClient As System.Net.Mail.SmtpClient = New System.Net.Mail.SmtpClient("mail.aetna.com")
        Dim message As System.Net.Mail.MailMessage = New System.Net.Mail.MailMessage()

        With message
            .IsBodyHtml = False
            .From = New System.Net.Mail.MailAddress(sFrom)
            .To.Add(sSendTo)
            .Subject = sSubject
            .Body = sBody
            .Priority = Net.Mail.MailPriority.Normal
        End With

        'add attachments if any
        If sAttachment <> "" Then
            Dim sAtt As String() = Split(sAttachment, ",")
            Dim iCount As Integer
            For iCount = 0 To sAtt.GetUpperBound(0)
                'if extract file gets over 1 MB, don't attach it and say so
                If FileLen(sAtt(iCount)) > 1048576 Then
                    message.Body &= vbCrLf & "Extract file size is " & Str(FileLen(sAtt(iCount))) & " bytes." & vbCrLf & "The file is not included due to its large size."
                Else
                    message.Attachments.Add(New System.Net.Mail.Attachment(sAtt(iCount)))
                End If
            Next
        End If

        mailClient.Send(message)
        SendMail = True
    End Function

    Private Function ArchiveFile() As Boolean
        Dim sNewFileName, sArchivePath As String
        WriteLog("Archiving old file.", HIGH)
        ArchiveFile = True

        'if the file already exists...
        If File.Exists(m_sOutputFileName) Then
            Dim fiFile As New FileInfo(m_sOutputFileName)
            'rename according to definition in extract file
            sNewFileName = GetValueFromFile("archive", "rename")
            'get the archive dir 
            sArchivePath = GetValueFromFile("archive", "location")
            'if it doesn't already exist, create it
            If Len(Dir(sArchivePath, vbDirectory)) = 0 Then
                MkDir(sArchivePath)
            End If
            'if the archive dir already contains a file with this name (will happen
            'if the renaming scheme only includes date and this is 2nd or later
            'run on same day) then rename it and delete it.
            If File.Exists(sArchivePath & "\" & sNewFileName) Then
                Dim sCopyName As String
                'insert the time into the name before the dot
                sCopyName = Replace(sNewFileName, ".", "_" & Replace(TimeString, ":", ".") & ".")
                File.Copy(sArchivePath & "\" & sNewFileName, sArchivePath & "\" & sCopyName)
                File.Delete(sArchivePath & "\" & sNewFileName)
            End If
            'move the old file into the archive dir, renaming it as we do
            fiFile.MoveTo(sArchivePath & "\" & sNewFileName)
            'if there is an encrypted file present, delete it
            If File.Exists(m_sOutputFileName & ".pgp") Then
                File.Delete(m_sOutputFileName & ".pgp")
            ElseIf File.Exists(m_sOutputFileName & ".asc") Then
                File.Delete(m_sOutputFileName & ".asc")
            End If
        End If
    End Function

    Private Function FTPOutputFile() As Boolean
        'this fn uses the external class clsFTPClass to transfer the output file
        'to a destination where the customer will take possession of it
        Dim xmlElement, xmlChild As Xml.XmlElement
        Dim iChild, iAttribute As Integer
        Dim sName, sFilename As String
        Dim sIP, sUserName, sPassword, sPath, sLog As String
        Dim sConnectionType As String = String.Empty
        Dim sLogLevel As String = String.Empty
        'Dim LogLevel As DataTransfer.ErrorLogLevel = Common.ErrorLogLevel.AlwaysLog
        Dim bRet, bOverwrite As Boolean
        'Dim DTConnectionType As FTPConnectionType
        Dim FTPTool As String = "WinInet"
        'Changes Start for ftping the file to the new domain till the time the old domain is not sunset
        Dim sNewFilename As String = ""

        FTPOutputFile = True
        'use the encrypted file name if it exists, otherwise the output file
        sFilename = m_sOutputFileName
        If File.Exists(m_sOutputFileName & ".pgp") Then
            sFilename = m_sOutputFileName & ".pgp"
        ElseIf File.Exists(m_sOutputFileName & ".asc") Then
            sFilename = m_sOutputFileName & ".asc"
        End If
        'strip the directory out of the filename
        Dim iPos As Integer = sFilename.LastIndexOf("\")
        If iPos <> 0 Then
            sFilename = Right(sFilename, Len(sFilename) - (iPos + 1))
        End If
        xmlElement = m_xmlDoc.SelectSingleNode("Root//ftp")
        If TypeName(xmlElement) <> "Nothing" Then
            'find each child node in turn; each has details on the ftp destination
            If xmlElement.HasChildNodes Then
                'Changes for ftping file to multiple destinations, moving the statement inside the loop 
                'after the FTP data has been read from the xml file
                'WriteLog("FTPing data file.", HIGH)
                For iChild = 0 To xmlElement.ChildNodes.Count - 1
                    'Changes Start for ftping the file to the new domain till the time the old domain is not sunset                    
                    sNewFilename = ""
                    'Changes End for ftping the file to the new domain till the time the old domain is not sunset
                    xmlChild = xmlElement.ChildNodes(iChild)
                    If TypeName(xmlChild) <> "Nothing" Then
                        'retrieve the attributes and set the variables
                        If xmlChild.HasAttributes Then
                            For iAttribute = 0 To xmlChild.Attributes.Count - 1
                                sName = xmlChild.Attributes.Item(iAttribute).Name
                                Select Case sName
                                    Case "IP"
                                        sIP = xmlChild.Attributes.Item(iAttribute).Value
                                    Case "username"
                                        sUserName = xmlChild.Attributes.Item(iAttribute).Value
                                    Case "password"
                                        sPassword = xmlChild.Attributes.Item(iAttribute).Value
                                    Case "path"
                                        sPath = xmlChild.Attributes.Item(iAttribute).Value
                                    Case "overwrite"
                                        bOverwrite = CBool(xmlChild.Attributes.Item(iAttribute).Value)
                                    Case "log"
                                        sLog = xmlChild.Attributes.Item(iAttribute).Value
                                    Case "connectionType"
                                        '09/23/05 - JMH - Supports AUTH/SSL
                                        'Optional Child, Legitimate Values: DT_STANDARD, DT_AUTH_SSL
                                        sConnectionType = xmlChild.Attributes.Item(iAttribute).Value
                                    Case "logLevel"
                                        '09/26/05 - JMH - Sets DataTransfer Logging Level
                                        'Optional Child, Legitimate Values: PRODUCTION, DEBUG
                                        sLogLevel = xmlChild.Attributes.Item(iAttribute).Value
                                        'Changes Start for ftping the file to the new domain till the time the old domain is not sunset
                                    Case "newfilename"
                                        sNewFilename = xmlChild.Attributes.Item(iAttribute).Value
                                        'Changes End for ftping the file to the new domain till the time the old domain is not sunset
                                End Select
                            Next

                            If (sConnectionType <> Nothing And sConnectionType <> String.Empty) Then
                                FTPTool = "WS_FTP"
                            End If
                            'Change for Radar 13330 - Ftping files to multiple servers. Adding this part here tp imperove the logging
                            WriteLog("FTPing data file to: " & sIP, HIGH)
                            'add datetime stamp to log file name
                            sLog = Mid(sLog, 1, Len(sLog) - 4) & "_" & Format(Now(), "yyyyMMdd_HHmmss") & Mid(sLog, Len(sLog) - 3)

                            Dim oFTP As InternetTransfer.clsFTP = New InternetTransfer.clsFTP
                            'Changes Start for ftping the file to the new domain till the time the old domain is not sunset
                            'bRet = oFTP.FTPSendFile(sIP, sUserName, sPassword, GetValueFromFile("Output", "FileDir"), sFilename, sLog, sPath, bOverwrite)
                            Try
                                'This will translate the dynamic data in the string
                                If sNewFilename <> String.Empty Then
                                    sNewFilename = Translate(sNewFilename)
                                End If
                                bRet = oFTP.FTPSendFile(sIP, sUserName, sPassword, GetValueFromFile("Output", "FileDir"), sFilename, sLog, sPath, bOverwrite, sNewFilename)
                                strDBLog &= InternetTransfer.clsFTP.strDBLog

                                'Changes End for ftping the file to the new domain till the time the old domain is not sunset
                                'End If

                                If Not bRet Then
                                    WriteLog("Error FTPing file.", LOW, 2)
                                    FTPOutputFile = False
                                    'Change for Radar 13330 - Ftping files to multiple servers. Adding this part here tp imperove the logging
                                Else
                                    WriteLog("File FTPed successfully", LOW)
                                    'Not adding FTPOutputFile = True here as in case file needs
                                    'to be Ftped to multiple locations then if one fails, it 
                                    'should still be trated as a failure
                                End If
                            Catch ex As Exception
                                strDBLog &= InternetTransfer.clsFTP.strDBLog
                                WriteLog("Error FTPing file.", LOW, 3)
                                Throw ex
                            End Try

                            'Change for Radar 13330 End - Adding this part to improve logging
                        End If
                    End If
                Next
            End If
        End If

    End Function

    Private Function RunSubQueries(ByRef dsData As DataSet, ByVal sQueryName As String) As Boolean
        'This function runs any described subqueries and replaces the defined data with
        'the results from the subquery
        'This is kinda hard to follow. Essentially, they can set up aliases in the 
        'definition file that tell us that we need to replace given columns with the result
        'of a subquery, using one of the existing columns as a param. The entry in the 
        'file might look like this:
        '- <SubQueries>
        '    <supervisoruniqueid Query="PK_FEEDS.sp_sel_ssn_empid" Param="?supervisoruniqueid?" replace="supervisoruniqueid,'SUPERVISOR_EMP_ID'" /> 
        '</SubQueries>
        'this tells us to run PK_FEEDS.sp_sel_ssn_empid, pass it supervisoruniqueid
        'and use the results to replace the 
        'supervisoruniqueid,SUPERVISOR_EMP_ID columns' data with the results.
        'The point of all this is to keep the data pulls in the procs, not in 
        'code. 
        'The param can be a column name, straight text or a ref to another value in the file.
        Dim sParam As String
        RunSubQueries = True

        Dim xmlElement, xmlChild As Xml.XmlElement
        Dim iChild, iAttribute As Integer, iFlatten As Integer
        Dim sColToPass As String
        Dim bFlatten As Boolean

        'find the subquery main node
        'xmlElement = m_xmlDoc.SelectSingleNode("Root//SubQueries")
        xmlElement = m_xmlDoc.SelectSingleNode("Root//" & sQueryName & "//SubQueries")
        If TypeName(xmlElement) <> "Nothing" Then
            'find each child node in turn; each has a query, params and the name of the col to replace
            If xmlElement.HasChildNodes Then
                WriteLog("Running sub-queries.", HIGH)
                For iChild = 0 To xmlElement.ChildNodes.Count - 1
                    xmlChild = xmlElement.ChildNodes(iChild)
                    If TypeName(xmlChild) <> "Nothing" Then
                        'retrieve the attributes and set the variables
                        'also check for prepend and append conditions.
                        'thiese will require us to add columns to the front or back
                        'of the table for the subquery results.
                        If xmlChild.HasAttributes Then
                            Dim sName, sQuery, sReplace, sObject, sFunction, sAssembly As String
                            Dim bPrepend, bAppend, bInsert, bObject As Boolean
                            Dim sPrepend, sAppend, sInsert As String
                            Dim iInsertIndex As Integer
                            bPrepend = False
                            bAppend = False
                            bInsert = False
                            bObject = False
                            sPrepend = ""
                            sAppend = ""
                            sInsert = ""
                            sName = ""
                            sQuery = ""
                            sReplace = ""
                            sObject = ""
                            sFunction = ""
                            bFlatten = False
                            iInsertIndex = 0
                            For iAttribute = 0 To xmlChild.Attributes.Count - 1
                                sName = xmlChild.Attributes.Item(iAttribute).Name
                                Select Case sName
                                    Case "Query"
                                        sQuery = xmlChild.Attributes.Item(iAttribute).Value
                                    Case "Param"
                                        sColToPass = xmlChild.Attributes.Item(iAttribute).Value
                                    Case "replace"
                                        sReplace = xmlChild.Attributes.Item(iAttribute).Value
                                    Case "prepend"
                                        bPrepend = True
                                        sPrepend = xmlChild.Attributes.Item(iAttribute).Value
                                    Case "append"
                                        bAppend = True
                                        sAppend = xmlChild.Attributes.Item(iAttribute).Value
                                    Case "insert"
                                        bInsert = True
                                        sInsert = xmlChild.Attributes.Item(iAttribute).Value
                                    Case "insert_before"
                                        iInsertIndex = m_dsData.Tables(0).Columns.IndexOf(xmlChild.Attributes.Item(iAttribute).Value)
                                    Case "object"
                                        sObject = xmlChild.Attributes.Item(iAttribute).Value
                                        bObject = True
                                    Case "assembly"
                                        sAssembly = xmlChild.Attributes.Item(iAttribute).Value
                                    Case "function"
                                        sFunction = xmlChild.Attributes.Item(iAttribute).Value
                                    Case "flatten"
                                        bFlatten = True
                                        iFlatten = xmlChild.Attributes.Item(iAttribute).Value
                                End Select
                            Next
                            'now run the subquery for each row in the dataset
                            'Dim i As Integer = 0
                            'if we have a subquery that requires prepending columns,
                            'we are going to be creating new tables with the 
                            'prepended columns and copying over data, then dropping
                            'the originals. In order to not re-process
                            'the new tables, make a notation in each
                            'original's extended property
                            'Dim thisTable As DataTable
                            'For Each thisTable In dsData.Tables
                            'thisTable.ExtendedProperties.Add("state", "original")
                            'Next
                            'Dim iTableCount As Integer = dsData.Tables.Count
                            'For i = 0 To iTableCount - 1
                            WriteLog("Running sub-query " & sQuery & ".", HIGH)
                            Dim myRow As DataRow

                            Dim iPos, iPos2 As Integer
                            Dim sOldText, sNewText, sColName As String
                            If bPrepend Then
                                'create a new table to hold the new data
                                '(including prepended columns)
                                Dim tblDataTableNew As DataTable = New DataTable
                                'pass in the old table and the new, empty table
                                'the fn will make the new table look like the old,
                                'but with the new, empty columns prepended
                                PrependColumns(dsData.Tables(0), tblDataTableNew, sPrepend)
                                'now drop the old table and replace it with the new.
                                dsData.Tables.Remove(dsData.Tables(0))
                                dsData.Tables.Add(tblDataTableNew)
                            End If
                            If bInsert Then
                                'create a new table to hold the new data
                                '(including inserted columns)
                                Dim tblDataTableNew As DataTable = New DataTable
                                'pass in the old table and the new, empty table
                                'the fn will make the new table look like the old,
                                'but with the new, empty columns inserted
                                InsertColumns(dsData.Tables(0), tblDataTableNew, sInsert, iInsertIndex)
                                'now drop the old table and replace it with the new.
                                dsData.Tables.Remove(dsData.Tables(0))
                                dsData.Tables.Add(tblDataTableNew)
                            End If
                            If bAppend Then
                                'AppendColumns(thisTable, sAppend)
                                AppendColumns(dsData.Tables(0), sAppend)
                            End If
                            'check to see if we need to run an object or a sql query
                            If bObject Then
                                'here we need to invoke a method on a given object.
                                'the name of the class and method come from the file
                                'so it has to be flexible enough to handle anything
                                Dim objObject As New Object
                                Dim assem As System.Reflection.Assembly
                                Dim tType As Type
                                Dim bOnce As Boolean
                                ' Load the assembly to use.
                                assem = System.Reflection.Assembly.Load(sAssembly)
                                ' Get the type to use from the assembly.
                                tType = assem.GetType(sObject)
                                ' Get the method to use from the type.
                                Dim mMethod As MethodInfo
                                mMethod = tType.GetMethod(sFunction)
                                ' Create an instance of the type.
                                objObject = Activator.CreateInstance(tType)
                                Dim args As String = Translate(sColToPass)
                                ' Create an array to hold the arguments.
                                ' Set the arguments.
                                Dim sTempArgs() As Object = Split(args, ",")
                                'handle the special case where the dataset is 
                                'to be passed in.
                                'find out if any arg is the dataset (that determines if
                                'we are going to do this once or for every row)
                                Dim i As Integer
                                If InStr(args, "m_dsData") > 0 Then
                                    bOnce = True
                                Else
                                    bOnce = False
                                End If
                                Dim sArgs(sTempArgs.GetUpperBound(0)) As Object
                                If bOnce Then
                                    For i = 0 To sTempArgs.GetUpperBound(0)
                                        If sTempArgs(i) = "m_dsData" Then
                                            sArgs(i) = m_dsData
                                        Else
                                            sArgs(i) = Translate(sTempArgs(i))
                                        End If
                                    Next
                                    ' Invoke the method.
                                    Try
                                        'if it is a local fn, just call it...
                                        If sObject = "DataExtract.clsDataExtract" Then
                                            Select Case sFunction
                                                Case "AddProviders"
                                                    Dim bRet = AddProviders(sArgs(0))
                                            End Select
                                        Else
                                            Dim result As Object = mMethod.Invoke(objObject, sArgs)
                                        End If
                                        'WriteLog(result, HIGH)
                                    Catch ex As Exception
                                        LogError(ex, "RunSubQueries")
                                        'custom fns may return non-fatal exceptions
                                        'just log these and continue
                                        If InStr(ex.Message, "NON-FATAL ERROR") = 0 Then
                                            If TypeName(ex.InnerException) <> "Nothing" Then
                                                If InStr(ex.InnerException.Message, "NON-FATAL ERROR") = 0 Then
                                                    RunSubQueries = False
                                                    Exit Function
                                                Else
                                                    'also flag it so we can put a warning in the email subj
                                                    m_bWarning = True
                                                End If
                                            End If
                                        Else
                                            'also flag it so we can put a warning in the email subj
                                            m_bWarning = True
                                        End If
                                    End Try
                                Else
                                    For Each myRow In dsData.Tables(0).Rows
                                        'this is really weak; it just allows you to replace a single value with 
                                        'the return from the fn; needs to be made more flexible
                                        For i = 0 To sTempArgs.GetUpperBound(0)
                                            sArgs(i) = Translate(sTempArgs(i))
                                            iPos = InStr(sArgs(i), "?")
                                            If iPos = 0 Then
                                                'not a column, just plain text
                                            Else
                                                'references at least one col name
                                                Do While (iPos <> 0)
                                                    iPos2 = InStr(iPos + 1, sArgs(i), "?")
                                                    sOldText = Mid(sArgs(i), iPos, iPos2 - iPos + 1)
                                                    sColName = Mid(sArgs(i), iPos + 1, iPos2 - iPos - 1)
                                                    If Not IsDBNull(myRow(sColName)) Then
                                                        sNewText = myRow(sColName)
                                                    Else
                                                        sNewText = ""
                                                    End If
                                                    sArgs(i) = Replace(sArgs(i), sOldText, sNewText)
                                                    iPos = InStr(sArgs(i), "?")
                                                Loop
                                            End If
                                        Next
                                        ' Invoke the method.
                                        Try
                                            Dim result As Object = mMethod.Invoke(objObject, sArgs)
                                            myRow(sReplace) = result
                                            'WriteLog(result, HIGH)
                                        Catch ex As Exception
                                            LogError(ex, "RunSubQueries")
                                            'custom fns may return non-fatal exceptions
                                            'just log these and continue
                                            If InStr(ex.Message, "NON-FATAL ERROR") = 0 Then
                                                If TypeName(ex.InnerException) <> "Nothing" Then
                                                    If InStr(ex.InnerException.Message, "NON-FATAL ERROR") = 0 Then
                                                        RunSubQueries = False
                                                        Exit Function
                                                    Else
                                                        'also flag it so we can put a warning in the email subj
                                                        m_bWarning = True
                                                    End If
                                                End If
                                            Else
                                                'also flag it so we can put a warning in the email subj
                                                m_bWarning = True
                                            End If
                                        End Try
                                    Next
                                End If
                            Else
                                Dim sHoldQuery As String = sQuery
                                For Each myRow In dsData.Tables(0).Rows
                                    Dim bNullParam As Boolean = False
                                    'check to find out if the param is a ref to a col in the row
                                    'if it is delimited with ? then it is a ref to a col
                                    'loop thru all we find and replace the param with the actual value
                                    sNewText = ""
                                    'set the original query back, incase it got translated for the last row
                                    sQuery = sHoldQuery
                                    '1st check the query for embedded column names
                                    'this will happen with drms queries
                                    iPos = InStr(sQuery, "?")
                                    If iPos = 0 Then
                                        'not a column, just plain text
                                    Else
                                        'references at least one col name
                                        Do While (iPos <> 0)
                                            iPos2 = InStr(iPos + 1, sQuery, "?")
                                            sOldText = Mid(sQuery, iPos, iPos2 - iPos + 1)
                                            sColName = Mid(sQuery, iPos + 1, iPos2 - iPos - 1)
                                            'LAR 11/06/2003 - added null check
                                            If Not IsDBNull(myRow(sColName)) Then
                                                sNewText = myRow(sColName)
                                            Else
                                                sNewText = ""
                                                bNullParam = True   'LAR 12/20/2004
                                            End If
                                            sQuery = Replace(sQuery, sOldText, sNewText)
                                            iPos = InStr(sQuery, "?")
                                        Loop
                                    End If
                                    sQuery = Translate(sQuery)
                                    sParam = sColToPass
                                    sNewText = ""
                                    iPos = InStr(sParam, "?")
                                    If iPos = 0 Then
                                        'not a column, just plain text
                                    Else
                                        'references at least one col name
                                        Do While (iPos <> 0) And Not bNullParam
                                            iPos2 = InStr(iPos + 1, sParam, "?")
                                            sOldText = Mid(sParam, iPos, iPos2 - iPos + 1)
                                            sColName = Mid(sParam, iPos + 1, iPos2 - iPos - 1)
                                            'watch out for nulls in the data; they will cause oledb exceptions
                                            'we will skip this query altogether
                                            If IsDBNull(myRow(sColName)) Then
                                                bNullParam = True
                                            Else
                                                sNewText &= myRow(sColName)
                                                sParam = Replace(sParam, sOldText, sNewText)
                                            End If
                                            iPos = InStr(sParam, "?")
                                        Loop
                                    End If
                                    'if params is empty, then the col being referenced
                                    'must be null so the subquery will fail.
                                    'to avoid an oledb exception, don't run
                                    'the query; just set all values to null
                                    If bNullParam Then
                                        Dim sToReplace() As String
                                        Dim iCount As Integer
                                        sToReplace = Split(sReplace, ",")
                                        For iCount = 0 To UBound(sToReplace)
                                            myRow(sToReplace(iCount)) = System.DBNull.Value
                                        Next
                                    Else
                                        'send it to the translate fn to catch refs to other
                                        'entries in the file and formatting..
                                        sParam = Translate(sParam)
                                        'now run the subquery and get the results
                                        Dim dsSub As DataSet = New DataSet
                                        If Not RunSQL(dsSub, sQuery, sParam, xmlChild.Name) Then
                                            'error
                                            RunSubQueries = False
                                            Exit Function
                                        End If
                                        If Not dsSub.Tables.Count = 0 Then
                                            'presumably we got one row back and the number and order of elements in the 
                                            'return set matches what we are to replace...
                                            'WriteLog("SubQuery " & sQuery & ", params " & sParam & " returned " & dsSub.Tables(0).Rows.Count & " rows", LOW)
                                            If bFlatten Then
                                                'flatten the results
                                                Dim objUtility As New DataExtractClasses.clsUtilityFunctions
                                                objUtility.FlattenDataset(dsSub, iFlatten)
                                            End If
                                            Dim sToReplace() As String
                                            Dim iCount As Integer
                                            sToReplace = Split(sReplace, ",")
                                            For iCount = 0 To UBound(sToReplace)
                                                Try
                                                    'if the new value is not null, set it into the original field
                                                    If Not IsDBNull(dsSub.Tables(0).Rows(0).Item(iCount)) Then
                                                        myRow(sToReplace(iCount)) = dsSub.Tables(0).Rows(0).Item(iCount)
                                                    End If
                                                Catch ex As System.IndexOutOfRangeException
                                                    'if the subquery returned no row then set the value to null
                                                    'myRow(sToReplace(iCount)) = System.DBNull.Value
                                                Catch ex As Exception
                                                    'catch all other exceptions
                                                    LogError(ex, "RunSubQueries")
                                                    RunSubQueries = False
                                                    Exit Function
                                                End Try
                                            Next
                                        End If
                                    End If
                                Next myRow
                                'Next thisTable
                                'Next i
                            End If
                        End If
                    End If
                Next iChild
            End If
        End If
        'End If

    End Function

    Private Function PrependColumns(ByRef tblTableOld As DataTable, ByRef tblTableNew As DataTable, ByVal sPrepend As String) As Boolean
        'this fn takes the passed table and prepends the columns specified
        'in the argument string
        'This one isn't as nice as the append fn, as there is no 
        'graceful way to prepend columns in a table. Have to do it the brute force way.
        Dim sColumnNames As String() = Split(sPrepend, ",")
        Dim iCount As Integer
        Dim myDataColumn As DataColumn
        Dim myDataRow As DataRow

        Try
            'first add the prepend columns
            For iCount = 0 To UBound(sColumnNames)
                myDataColumn = New DataColumn(sColumnNames(iCount), System.Type.GetType("System.String"))
                tblTableNew.Columns.Add(myDataColumn)
            Next
            'now add the existing columns to the table
            For iCount = 0 To tblTableOld.Columns.Count - 1
                myDataColumn = New DataColumn(tblTableOld.Columns.Item(iCount).ColumnName, tblTableOld.Columns.Item(iCount).DataType)
                tblTableNew.Columns.Add(myDataColumn)
            Next
            'now copy over all the rows...
            For Each myDataRow In tblTableOld.Rows
                ' Create an array for the new data.
                Dim lCount As Long = (tblTableOld.Columns.Count - 1) + UBound(sColumnNames) + 1
                Dim rowVals(lCount) As Object
                Dim rc As DataRowCollection
                rc = tblTableNew.Rows
                Dim iIndex As Integer = 0
                'set the first few columns to empty (these are the prepend cols)
                For iCount = 0 To UBound(sColumnNames)
                    'rowVals(iIndex) = "Hello"
                    rowVals(iIndex) = System.DBNull.Value
                    iIndex += 1
                Next
                'now the rest of the data for the row
                For iCount = 0 To tblTableOld.Columns.Count - 1
                    rowVals(iIndex) = myDataRow.Item(iCount)
                    iIndex += 1
                Next
                'add the row to the row collection
                rc.Add(rowVals)
            Next
        Catch ex As Exception
            LogError(ex, "PrependColumns")
            PrependColumns = False
            Exit Function
        End Try

    End Function

    Private Function InsertColumns(ByRef tblTableOld As DataTable, ByRef tblTableNew As DataTable, ByVal sInsert As String, ByVal iInsertIndex As Integer) As Boolean
        'this fn takes the passed table and inserts the columns specified
        'in the argument string at the iIndex location in the table.
        'Note that the iIndex is the column BEFORE WHICH the new columns will be inserted.
        'This one isn't as nice as the append fn, as there is no 
        'graceful way to insert columns in a table. Have to do it the brute force way.
        'Note: this can probably be combined with the Prepend fn with a switch or two...
        Dim sColumnNames As String() = Split(sInsert, ",")
        Dim iCount As Integer
        Dim myDataColumn As DataColumn
        Dim myDataRow As DataRow

        Try
            'first add the existing columns up to the insert position
            For iCount = 0 To iInsertIndex - 1
                myDataColumn = New DataColumn(tblTableOld.Columns.Item(iCount).ColumnName, tblTableOld.Columns.Item(iCount).DataType)
                tblTableNew.Columns.Add(myDataColumn)
            Next

            'now the columns to be inserted
            For iCount = 0 To UBound(sColumnNames)
                myDataColumn = New DataColumn(sColumnNames(iCount), System.Type.GetType("System.String"))
                tblTableNew.Columns.Add(myDataColumn)
            Next

            'now add the rest of the existing columns to the table
            For iCount = iInsertIndex To tblTableOld.Columns.Count - 1
                myDataColumn = New DataColumn(tblTableOld.Columns.Item(iCount).ColumnName, tblTableOld.Columns.Item(iCount).DataType)
                tblTableNew.Columns.Add(myDataColumn)
            Next

            'now copy over all the rows...
            For Each myDataRow In tblTableOld.Rows
                ' Create an array for the new data.
                Dim lCount As Long = (tblTableOld.Columns.Count - 1) + UBound(sColumnNames) + 1
                Dim rowVals(lCount) As Object
                Dim rc As DataRowCollection
                rc = tblTableNew.Rows
                Dim iIndex As Integer = 0
                'now the first cols of the data for the row
                For iCount = 0 To iInsertIndex - 1
                    rowVals(iIndex) = myDataRow.Item(iCount)
                    iIndex += 1
                Next
                'set the next few columns to empty (these are the insert cols)
                For iCount = 0 To UBound(sColumnNames)
                    'rowVals(iIndex) = "Hello"
                    rowVals(iIndex) = System.DBNull.Value
                    iIndex += 1
                Next
                'now the rest of the data for the row
                For iCount = iInsertIndex To tblTableOld.Columns.Count - 1
                    rowVals(iIndex) = myDataRow.Item(iCount)
                    iIndex += 1
                Next
                'add the row to the row collection
                rc.Add(rowVals)
            Next
        Catch ex As Exception
            LogError(ex, "InsertColumns")
            InsertColumns = False
            Exit Function
        End Try

    End Function

    Private Function AppendColumns(ByRef tblTable As DataTable, ByVal sAppend As String) As Boolean
        'this fn takes the passed table and appends the columns specified
        'in the argument string
        Dim sColumnNames As String() = Split(sAppend, ",")
        Dim i As Integer
        Try
            For i = 0 To UBound(sColumnNames)
                If Not tblTable.Columns.Contains(sColumnNames(i)) Then
                    Try
                        Dim colColumn As DataColumn = tblTable.Columns.Add(sColumnNames(i), System.Type.GetType("System.String"))
                    Catch ex As Exception
                        'catch all exceptions
                        LogError(ex, "AppendColumns")
                        AppendColumns = False
                        Exit Function
                    End Try
                End If
            Next
        Catch ex As Exception
            LogError(ex, "AppendColumns")
            AppendColumns = False
            Exit Function
        End Try
    End Function

    'Changes for RADAR-13330. Name of older version of RUNSQL is changed to RunSQLOLEDB.
    'Exception handling part is removed because now exception handling is done at the point 
    'of call. ProcessFile has the exception handling part

    Private Function RunSQLOLEDB(ByRef dsData As DataSet, ByVal sSQL As String, ByVal sParamsInput As String, Optional ByVal sQueryName As String = "") As Boolean
        'Take the passed sql and params, run them and populate the passed dataset
        Dim sParams() As String
        Dim strTemp, sUDLFile As String
        Dim intIndex As Short
        Dim bExecuteOnly As Boolean

        sUDLFile = ""
        strTemp = ""
        If sQueryName <> "" Then
            sUDLFile = GetValueFromFile(sQueryName, "udl")
        End If

        If sUDLFile = "" Then
            RunSQLOLEDB = False
            Exit Function
        End If

        Dim objCon As OleDbConnection = New OleDbConnection("File Name=" & sUDLFile & ";")
        Dim objCommand As OleDbCommand = New OleDbCommand("Lee", objCon)
        Dim daData As OleDbDataAdapter = New OleDbDataAdapter(objCommand)

        RunSQLOLEDB = True
        daData.SelectCommand = objCommand
        'Try
        objCon.Open()
        'Catch objExAlreadyOpen As InvalidOperationException
        'connection is already open, use it
        'Catch objException As Exception
        'can't make a connection, fail out
        'LogError(objException, "RunSQL")
        'RunSQLOLEDB = False
        'Exit Function
        'End Try

        If sParamsInput = "ExecuteOnly" Then
            bExecuteOnly = True
            sParamsInput = ""
        End If

        'if it is a stored proc, then we have to collect the params and process them as well
        If UCase(Left(sSQL, 2)) = "PK" Or UCase(Left(sSQL, 2)) = "SP" Then
            If sParamsInput <> "" Then
                sParams = Split(sParamsInput, ",")
                'loop thru all params in the file and construct the param list
                For intIndex = 0 To UBound(sParams)
                    strTemp = strTemp + IIf(Len(strTemp) = 0, "'" & Trim(sParams(intIndex)) & "'", ", '" & Trim(sParams(intIndex)) & "'")
                Next intIndex
            End If
            'build the oracle command string
            objCommand.CommandText = "{CALL " & sSQL & "(" & strTemp & ")}"
        ElseIf UCase(Left(sSQL, 9)) = "EXEC DBO." Then
            objCommand.CommandTimeout = 0
            objCommand.CommandText = sSQL
        Else
            'if it is just a simple sql statement, execute it directly
            objCommand.CommandTimeout = 0
            objCommand.CommandText = sSQL
        End If

        If bExecuteOnly Then
            'Try
            Dim iRowsAffected As Integer = objCommand.ExecuteNonQuery()
            'Catch objException As Exception
            'LogError(objException, "RunSQL")
            'RunSQLOLEDB = False
            'Exit Function
            'End Try
        Else
            'Try
            daData.Fill(dsData)
            'Catch objException As Exception
            'LogError(objException, "RunSQL")
            'RunSQLOLEDB = False
            'Exit Function
            'End Try
        End If

        objCommand = Nothing
        objCon.Close()
    End Function

    Private Function Translate(ByRef sInput As String) As String
        'This fn translates the embedded codes in the definition file and returns the translated value.
        'for example, the params might include the last run date and the current run date.
        'The file would have an entry like Params=10917,^LastRun/Date^,#RunDateyyyymmdd#
        '^ delimiters mean replace what is between them with the corresponding entry in the file;
        '# delimiters mean to replace the contents with program-logic defined values (in this case
        'the current run date in the given format)
        Dim iPos, iPos2 As Short
        Dim sReplace As String
        Dim aSplit() As String
        Dim sReturn As String
        Dim sOldText, sNewText As String
        Dim sTemp, sColName, sFilter As String

        sReturn = sInput
        iPos = InStr(sReturn, "^")
        Do While (iPos <> 0)
            iPos2 = InStr(iPos + 1, sReturn, "^")
            'save off the original text (^LastRun/Date^)
            sOldText = Mid(sReturn, iPos, iPos2 - iPos + 1)
            'get the 'interior' text (LastRun/Date)
            sReplace = Mid(sReturn, iPos + 1, iPos2 - iPos - 1)
            'will always (by convention) have a parent & child xml node, sep by /
            aSplit = Split(sReplace, "/")
            'get the corresponding value from the xml file
            sNewText = GetValueFromFile(aSplit(0), aSplit(1))
            'replace the entire orig text with the value from the file
            sReturn = Replace(sReturn, sOldText, sNewText)
            'find the next carat if any and run the loop again
            iPos = InStr(sReturn, "^")
        Loop

        iPos = 0
        iPos = InStr(sReturn, "#")
        'see comments above for details...
        Do While (iPos <> 0)
            iPos2 = InStr(iPos + 1, sReturn, "#")
            sOldText = Mid(sReturn, iPos, iPos2 - iPos + 1)
            sReplace = Mid(sReturn, iPos + 1, iPos2 - iPos - 1)
            If sReplace = "record_count" Then
                sNewText = CStr(m_lRecordCount)
            ElseIf sReplace = "record_count_plus_hdr_ftr" Then
                sNewText = CStr(m_lRecordCount + 2)
            ElseIf Left(sReplace, 3) = "SUM" Then
                'find out the name of the column to take the sum of
                'split it on comma; user may enter a colname, comma, filter
                aSplit = Split(Mid(sReplace, 4), ",")
                sColName = aSplit(0)
                sFilter = ""
                'if there was a comma, pull out the filter, otherwise default it to ""
                If UBound(aSplit) > 0 Then
                    sFilter = aSplit(1)
                End If
                'try to get the sum
                Dim objSum As Object
                Try
                    objSum = m_dsData.Tables(0).Compute("Sum(" & sColName & ")", sFilter)
                    sNewText = objSum
                Catch objException As Exception
                    LogError(objException, "Translate")
                    Translate = ""
                    Exit Function
                End Try
            ElseIf Left(sReplace, 5) = "COUNT" Then
                'find out the name of the column to take the count of
                'split it on comma; user may enter a colname, comma, filter
                aSplit = Split(Mid(sReplace, 6), ",")
                sColName = aSplit(0)
                sFilter = ""
                'if there was a comma, pull out the filter, otherwise default it to ""
                If UBound(aSplit) > 0 Then
                    sFilter = aSplit(1)
                End If
                If sFilter = "unique" Then
                    'we want a count of unique values in a column
                    'can't see a way to sort a data table, so make a dataview out of it
                    Dim dvTemp As DataView = New DataView(m_dsData.Tables(0))
                    'sort the dataview on that column
                    dvTemp.Sort = sColName & " asc"
                    'loop thru and count 
                    Dim i, iCount As Integer
                    Dim sPrior As String = ""
                    For i = 0 To dvTemp.Count - 1
                        If Not IsDBNull(dvTemp.Item(i).Item(sColName)) Then
                            If CStr(dvTemp.Item(i).Item(sColName)) <> sPrior Then
                                iCount += 1
                                sPrior = CStr(dvTemp.Item(i).Item(sColName))
                            End If
                        End If
                    Next
                    sNewText = CStr(iCount)
                Else
                    'straight count (with or without filter)
                    'try to get the count
                    Dim objCount As Object
                    Try
                        'sTemp = m_dsData.Tables(0).Compute("Count(" & sTemp & ")", sFilter).GetType.ToString
                        objCount = m_dsData.Tables(0).Compute("Count(" & sColName & ")", sFilter)
                        sNewText = objCount
                    Catch objException As Exception
                        LogError(objException, "Translate")
                        Translate = ""
                        Exit Function
                    End Try
                End If
            ElseIf Left(sReplace, 4) = "Date" Then
                sTemp = Mid(sReplace, 5)
                sNewText = Format(Now, sTemp)
            ElseIf Left(sReplace, 7) = "RunDate" Then
                sTemp = Mid(sReplace, 5)
                sNewText = m_sRunDate
            ElseIf Left(sReplace, 8) = "FileDate" Then
                sTemp = Mid(sReplace, 9)
                sNewText = Format(FileDateTime(m_sOutputFileName), sTemp)
            End If
            sReturn = Replace(sReturn, sOldText, sNewText)
            iPos = InStr(sReturn, "#")
        Loop

        Translate = sReturn

    End Function


    Private Function GetValueFromFile(ByRef sSection As String, ByRef sKey As String) As String
        'get a value out of the file;
        Dim xmlElement As Xml.XmlElement
        Dim sResult As String

        'find the node for the section and key passed in
        xmlElement = m_xmlDoc.SelectSingleNode("Root//" & sSection & "[@" & sKey & "]")
        If TypeName(xmlElement) <> "Nothing" Then
            'get its value
            sResult = xmlElement.GetAttribute(sKey)
        Else
            'don't log that we didn't find a udl file
            'don't log that we didn't find a returndataset tag- changes for RADAR-13330
            'dont log for timeout value as well
            If sKey <> "udl" And sKey <> "returndataset" And sKey <> "timeout" Then
                WriteLog("Error in GetValueFromFile: Error finding value for Root//" & sSection & "[@" & sKey & "].", LOW, 2)
                'Added by Prashant for proper error messages
                'GetValueFromFile = Nothing
                'Exit Function
                'Changes end
            End If
        End If

        GetValueFromFile = Translate(sResult)

    End Function

    Private Function LogError(ByVal objException As Exception, ByVal sFunction As String)
        'get the exception text and write it to the log file
        Dim sErrorMsg As String
        sErrorMsg = "Error in " & sFunction & ". "
        sErrorMsg &= objException.Message
        If TypeName(objException.InnerException) <> "Nothing" Then
            sErrorMsg &= " " & objException.InnerException.Message
        End If
        WriteLog(sErrorMsg, LOW, 3)

    End Function

    Private Function StripColumns(ByRef dsData As DataSet, ByVal sQueryName As String) As Boolean
        'this fn strips any defined columns out of the result set.
        'This allows us to use an existing query or proc that we know works,
        'and pull out any cols that this customer doesn't want
        'in the feed.
        Dim xmlElement As Xml.XmlElement
        Dim i As Integer
        Dim colName As String

        StripColumns = True

        xmlElement = m_xmlDoc.SelectSingleNode("Root//" & sQueryName & "//TrimColumns")
        If TypeName(xmlElement) <> "Nothing" Then
            If xmlElement.HasAttributes Then
                For i = 0 To xmlElement.Attributes.Count - 1
                    colName = xmlElement.Attributes.Item(i).Name
                    WriteLog("Stripping column " & colName & ".", HIGH)
                    Dim cols As DataColumnCollection
                    ' Get the DataColumnCollection from a DataTable in a DataSet.
                    cols = dsData.Tables(0).Columns
                    If cols.Contains(colName) Then
                        If cols.CanRemove(cols(colName)) Then
                            'Try
                            cols.Remove(colName)
                            'Catch objException As Exception
                            '    StripColumns = False
                            '    LogError(objException, "StripColumns")
                            '    StripColumns = False
                            '    Exit Function
                            'End Try
                        End If
                    End If
                Next
            End If
        End If

    End Function

    Private Function AdvanceDate(ByRef dtDate As System.DateTime, ByVal sFreq As String) As System.DateTime
        'advance the passed date by the passed interval
        Dim dtTemp As System.DateTime

        Select Case sFreq
            Case "hourly"
                dtTemp = dtDate.AddHours(1)
            Case "daily"
                dtTemp = dtDate.AddDays(1)
            Case "weekdaily"
                'this means only run on weekdays
                'if we are at friday or saturday, advance to monday
                'otherwise just advance by a day.
                Select Case dtDate.DayOfWeek
                    Case DayOfWeek.Friday
                        dtTemp = dtDate.AddDays(3)
                    Case DayOfWeek.Saturday
                        dtTemp = dtDate.AddDays(2)
                    Case Else
                        dtTemp = dtDate.AddDays(1)
                End Select
            Case "weekly"
                dtTemp = dtDate.AddDays(7)
            Case "biweekly"     '12/20/2004
                dtTemp = dtDate.AddDays(14)
            Case "semi-monthlyA"
                '1st & 15th of the month. Find which is next
                Select Case Microsoft.VisualBasic.Day(Now)
                    Case Is < 15
                        'advance to the 15th
                        dtTemp = dtDate.AddDays(15 - dtDate.Day)
                    Case Else
                        'if it is the 15th, or any other date, 
                        'set to 1st of next month 
                        'there should be a simple way to do this, but noooo
                        '1st advance to the next month
                        dtTemp = dtDate.AddMonths(1)
                        'then subtract day of month - 1 to get down to 1
                        If dtTemp.Day <> 1 Then
                            dtTemp = dtTemp.AddDays(-(dtTemp.Day - 1))
                        End If
                End Select
            Case "semi-monthlyB"
                '15th & 30th of the month. 
                Select Case Microsoft.VisualBasic.Day(Now)
                    Case Is < 15
                        'advance to the 15th
                        dtTemp = dtDate.AddDays(15 - dtDate.Day)
                    Case Else
                        'advance to the 30th
                        dtTemp = dtDate.AddDays(30 - dtDate.Day)
                End Select
            Case "monthly"
                dtTemp = dtDate.AddMonths(1)
            Case "quarterly"
                dtTemp = dtDate.AddMonths(3)
        End Select
        AdvanceDate = dtTemp

    End Function

    Private Function SetRunDates() As Boolean
        'after running the file, reset the run dates to new values
        'the original intent was to set the last run date to the run
        'date of this run, and advance it by the set amt to get the next run date.
        'Now we are adding a 'rolling window' capability,
        'where both dates are advanced by the set interval, so we can accomodate
        'situations where ie the file is run on friday night and the window run will 
        'be the prev sun to sat. After running both dates are advanced
        'by a week.
        Dim xmlElement As Xml.XmlElement
        Dim sFreq As String
        Dim dtNextRun As System.DateTime

        SetRunDates = True
        dtNextRun = m_sRunDate
        If m_sInputFileName <> "" Then
            'find the node for the schedule
            xmlElement = m_xmlDoc.SelectSingleNode("Root//Schedule")
            If TypeName(xmlElement) <> "Nothing" Then
                'set last run date to this run's run date
                xmlElement.SetAttribute("LastRunDate", m_sRunDate)
                'look for a frequency node; if one does not exist, or if it has no value,
                'do not advance the dates.
                sFreq = xmlElement.GetAttribute("frequency")
                If sFreq <> "" Then
                    'advance the next run date by the defined frequency
                    dtNextRun = AdvanceDate(dtNextRun, sFreq)
                    xmlElement.SetAttribute("NextRunDate", CStr(dtNextRun))
                    'now do the start and end dates
                    Select Case xmlElement.GetAttribute("type")
                        Case "rolling"
                            'this is the rolling window type
                            'advance the start and end dates by the interval
                            Dim dtTemp As System.DateTime
                            dtTemp = CDate(xmlElement.GetAttribute("StartDate"))
                            dtTemp = AdvanceDate(dtTemp, sFreq)
                            xmlElement.SetAttribute("StartDate", CStr(dtTemp))
                            dtTemp = CDate(xmlElement.GetAttribute("EndDate"))
                            dtTemp = AdvanceDate(dtTemp, sFreq)
                            xmlElement.SetAttribute("EndDate", CStr(dtTemp))
                        Case "simple", ""
                            'just set the start and end dates to the last and next run dates
                            xmlElement.SetAttribute("StartDate", xmlElement.GetAttribute("LastRunDate"))
                            xmlElement.SetAttribute("EndDate", xmlElement.GetAttribute("NextRunDate"))
                        Case "rollfixed"
                            'PID 07/25/2006
                            'This is a variant on the rolling window type.
                            'Advance the start and end dates by the interval, 
                            'but only on a certain day of the week, the roll date
                            Dim dtTemp As System.DateTime
                            Dim dtTemp2 As System.DateTime
                            Dim sRollFreq As String
                            Dim iRollDay As Integer
                            Dim iDayOfWeek As Integer
                            Dim dtStartDt As System.DateTime
                            Dim dtEndDt As System.DateTime
                            Dim dtLastRunDt As System.DateTime

                            sRollFreq = xmlElement.GetAttribute("Roll_Frequency")
                            iRollDay = xmlElement.GetAttribute("rollday")
                            dtTemp = CDate(xmlElement.GetAttribute("StartDate"))
                            dtTemp2 = CDate(xmlElement.GetAttribute("LastRunDate"))
                            iDayOfWeek = dtTemp.DayOfWeek
                            If dtTemp2.DayOfWeek = iRollDay Then
                                dtTemp = AdvanceDate(dtTemp, sRollFreq)
                                xmlElement.SetAttribute("StartDate", CStr(dtTemp))
                                dtTemp = CDate(xmlElement.GetAttribute("EndDate"))
                                dtTemp = AdvanceDate(dtTemp, sRollFreq)
                                xmlElement.SetAttribute("EndDate", CStr(dtTemp))
                            Else
                                xmlElement.SetAttribute("StartDate", xmlElement.GetAttribute("StartDate"))
                                dtStartDt = xmlElement.GetAttribute("StartDate")
                                xmlElement.SetAttribute("EndDate", xmlElement.GetAttribute("EndDate"))
                                dtEndDt = xmlElement.GetAttribute("EndDate")
                                dtLastRunDt = xmlElement.GetAttribute("LastRunDate")
                            End If
                    End Select
                End If
                m_xmlDoc.Save(m_sInputFileName)
            Else
                'LAR 07/24/2003 - not finding the schedule not is not a fatal error
                'lots of reasons why a particular feed might not be date-centric.
                'just log it and continue
                'SetRunDates = False
                WriteLog("Error in SetRunDates: Error finding Schedule node; could not set run dates.", LOW, 2)
            End If
        Else
            SetRunDates = False
            WriteLog("Error in SetRunDates: Error finding input file; could not set run dates.", LOW, 2)
        End If

    End Function

    Private Function SetSequenceNumber() As Boolean

        'Added 10/11/2006 - Chris Dedam
        'This function will auto increment the sequence number of the XML file
        Dim xmlElement As Xml.XmlElement
        Dim sSequenceNumber As String
        Dim sIncrement As String
        Dim lNextSequence As Long

        'Defualt to true
        SetSequenceNumber = True

        'Is the XML Input filename defined?
        If m_sInputFileName <> "" Then

            'find the node for the sequence
            xmlElement = m_xmlDoc.SelectSingleNode("Root//Sequence")

            'Did we find the Sequence tag?
            If TypeName(xmlElement) <> "Nothing" Then

                'look for a sequence number and the increment value
                sSequenceNumber = xmlElement.GetAttribute("Number")
                sIncrement = xmlElement.GetAttribute("Increment")

                'Is the increment value not set or not valid?
                If ((sIncrement.Trim.Length = 0) Or (IsNumeric(sIncrement) = False)) Then
                    sIncrement = "1"
                End If

                'Is the sequence number valid
                If IsNumeric(sSequenceNumber) And sSequenceNumber <> "" Then

                    'Calculate the new sequence number 
                    lNextSequence = Long.Parse(sSequenceNumber) + Long.Parse(sIncrement)

                    'Set the new sequence number
                    xmlElement.SetAttribute("Number", lNextSequence.ToString)

                    m_xmlDoc.Save(m_sInputFileName)
                Else
                    'The sequence number was invalid so return false and write a message to the error log
                    SetSequenceNumber = False
                    WriteLog("Error in SetSequenceNumber: Invalid Sequence Number. ", LOW, 2)
                End If
            Else
                SetSequenceNumber = False
            End If
        Else
            SetSequenceNumber = False
        End If

        Return SetSequenceNumber
    End Function


    Private Function FormatDataField(ByVal oData As Object, ByVal sNodePath As String, Optional ByVal sMode As String = "") As String
        'find the entry (if it exists) for this field in the formatting section
        'and format the passed data, returning it as a string for output to file
        'LAR 10/15/2003 - added optional mode param to tell us we're in fixed format mode
        Dim xmlElement As Xml.XmlElement
        Dim iAttribute As Integer
        Dim sName, sValue As String
        Dim sTemp As String
        If Not IsDBNull(oData) Then
            sTemp = oData
        Else
            sTemp = ""
        End If

        'see if there is a format defined for this column
        'if no format defined, we just pass it as a string for output
        xmlElement = m_xmlDoc.SelectSingleNode(sNodePath)
        If TypeName(xmlElement) <> "Nothing" Then
            'name is the data type
            sName = xmlElement.Attributes.Item(iAttribute).Name
            'value is the format string ie 000-00-0000 for SSN
            sValue = xmlElement.Attributes.Item(iAttribute).Value
            Select Case sName
                Case "string"
                    'control for nulls
                    If sTemp = "" Then
                        'simply pad with the total number of spaces
                        sTemp = PadString("", CInt(sValue), "R")
                    Else
                        'use .NET's padding to add the correct # of spaces
                        sTemp = sTemp.PadRight(CInt(sValue))
                    End If
                    'truncate at right edge if it is too big
                    If Len(sTemp) > CInt(sValue) Then
                        sTemp = Left(sTemp, CInt(sValue))
                    End If
                Case "boolean"
                    'LAR 12/10/2004 - restructure from ifs to select case 
                    Select Case sValue
                        Case "Y/N"
                            'if the data is not already Y/N
                            If sTemp <> "Y" And sTemp <> "N" Then
                                If sTemp = "1" Then
                                    sTemp = "Y"
                                Else
                                    sTemp = "N"
                                End If
                            End If
                            'LAR 10/10/2003 - added 1/0 and T/F
                        Case "0/1", "1/0"
                            'if the data is not already 1/0
                            If sTemp <> "1" And sTemp <> "0" Then
                                If sTemp = "True" Then
                                    sTemp = "1"
                                Else
                                    sTemp = "0"
                                End If
                            End If
                        Case "T/F"
                            'if the data is not already T/F
                            If sTemp <> "T" And sTemp <> "F" Then
                                If sTemp = "1" Or sTemp = "True" Then
                                    sTemp = "T"
                                Else
                                    sTemp = "F"
                                End If
                            End If
                            'LAR 10/17/2003 - added M/F
                        Case "M/F"
                            'if the data is not already M/F
                            If sTemp <> "M" And sTemp <> "F" Then
                                If sTemp = "1" Or sTemp = "True" Then
                                    sTemp = "M"
                                Else
                                    sTemp = "F"
                                End If
                            End If
                            'LAR 10/28/2003 - added A/T for Bayer Migration
                        Case "A/T"
                            'if the data is not already A/T
                            If sTemp <> "A" And sTemp <> "T" Then
                                If sTemp = "1" Or sTemp = "True" Then
                                    sTemp = "A"
                                Else
                                    sTemp = "T"
                                End If
                            End If
                            'LAR 02/24/2004 - added for Motorola transition
                        Case "EXEMPT/NONEXEMPT"
                            'if the data is not already 0/1 or empty
                            If sTemp <> "E" And sTemp <> "N" And sTemp <> "" Then
                                If sTemp = "EXEMPT" Then
                                    sTemp = "E"
                                Else
                                    sTemp = "N"
                                End If
                            Else
                                sTemp = " "
                            End If
                            'LAR 02/24/2004 - end
                    End Select
                Case "numeric", "numeric_StripDecimal", "numeric_negative"
                    Dim dDbl As Double
                    'if it is null, leave it null
                    'LAR 12/02/2003 - no, if it is null set it to 0 so it can have the format applied...
                    If sTemp = "" Then sTemp = "0"
                    If sTemp <> "" Then
                        Dim bSign As Boolean
                        'cast it just in case
                        dDbl = CDbl(sTemp)
                        'if the format mask starts with '+' then we want to
                        'force a sign at the beginning, prepended to the
                        'numeric string
                        If sValue.StartsWith("+") Then
                            bSign = True
                            'remove the '+' as it isn't really part of the mask
                            sValue = sValue.Remove(0, 1)
                        End If

                        If sTemp.StartsWith("-") And sName = "numeric_negative" Then
                            sValue = sValue.Remove(0, 1)
                        End If
                        'apply the format
                        sTemp = String.Format("{0:" & sValue & "}", dDbl)
                        'if the user entered more digits than the mask allows, have to remove digits to make it fit.
                        'ie the mask is 0000.00 and the user enters 12345, it gets formatted to 12345.00
                        'which is too wide. So have to remove the 1.
                        Dim iFormatDecPlacement As Integer = sValue.IndexOf(".") 'does the format include decimal?
                        If iFormatDecPlacement > 0 Then
                            Dim iDataDecPlacement As Integer = sTemp.IndexOf(".")
                            If iDataDecPlacement > iFormatDecPlacement Then
                                sTemp = sTemp.Remove(0, iDataDecPlacement - iFormatDecPlacement)
                            End If
                        End If
                        If bSign Then
                            'now force on the '+' (regular formats already put
                            'a '-' on neg nums)
                            If Not sTemp.StartsWith("-") Then
                                sTemp = "+" & sTemp
                            End If
                        End If
                        'if we are doing an 'implied decimal' format we need
                        'to strip out the decimal itself
                        If sName = "numeric_StripDecimal" Then
                            sTemp = Replace(sTemp, ".", "")
                        End If
                        bSign = False
                    End If
                Case "date"
                    Dim dtDate As Date
                    Dim dtTemp As New DateTime
                    'if it is null, leave it null
                    If sTemp <> "" Then
                        'cast it just in case
                        Try
                            dtDate = CDate(sTemp)
                            'apply the format
                            sTemp = String.Format("{0:" & sValue & "}", dtDate)
                        Catch e As Exception
                            'if it has errored on the cast, it must already have been
                            'formatted or is an invalid date. Either way, can't
                            'format it so just return it
                        End Try
                    Else
                        'LAR 10/15/2003 - if date is null and we're running in fixed mode, pad it with spaces
                        If sMode = "fixed" Then
                            sTemp = sTemp.PadRight(sValue.Length)
                        End If
                    End If
                Case "skip"
                    'DDM 5/12/03 there is a need to carry a value through for footer calcs but not output in regular ouput section
                    sTemp = ""

            End Select
        End If

        Return sTemp

    End Function

    Private Function OutputData(ByRef dsData As DataSet) As Boolean
        'write the data set to the output file.
        'Noet that the definition file contains instructions on formatting etc
        Dim strFormat, strDataLine, strDelimiter As String
        Dim sQuoteStrings As String = ""
        'LAR 04/29/2003 - end

        OutputData = True

        strFormat = GetValueFromFile("Output", "Format")
        'LAR 04/29/2003 
        'see if we are to put all values in quotes
        'ie "02","I","04/24/2003","117001","04/02/2003","STD","STD","04/14/2003"
        If GetValueFromFile("Output", "quote_strings") = "true" Then
            sQuoteStrings = Chr(34)
        End If
        'LAR 04/29/2003 - end
        WriteLog("Writing data to file.", HIGH)

        Select Case strFormat
            Case "delimited", "csv"
                If strFormat = "csv" Then
                    strDelimiter = ","
                Else
                    strDelimiter = GetValueFromFile("Output", "delimiter")
                    If strDelimiter = "TAB" Then
                        strDelimiter = vbTab
                    End If
                End If
                'WriteFile(GetValueFromFile("Output", "Header"))
                If m_sHeader <> Nothing Then 'dont output a line feed if the header is empty
                    WriteFile(m_sHeader)
                End If
                Dim thisTable As DataTable
                For Each thisTable In dsData.Tables
                    ' For each row, print the values of each column.
                    Dim myRow As DataRow
                    For Each myRow In thisTable.Rows
                        If myRow.RowState <> DataRowState.Deleted Then
                            Dim myCol As DataColumn
                            For Each myCol In thisTable.Columns
                                'strDataLine &= myRow(myCol) & strDelimiter
                                'LAR 04/29/2003
                                Dim sTemp As String = FormatDataField(myRow(myCol), "Root//Format/" & myCol.ColumnName)
                                If sTemp <> "" Then
                                    sTemp = sQuoteStrings & sTemp & sQuoteStrings
                                End If
                                strDataLine &= sTemp & strDelimiter
                                'LAR 04/29/2003 - end
                            Next myCol
                            'removing trailing delimiter
                            strDataLine = Left(strDataLine, Len(strDataLine) - 1)
                            'write the row to the file
                            'WriteFile(strDataLine & vbCr)
                            'WriteFile(strDataLine & vbLf)
                            WriteFile(strDataLine)
                            strDataLine = ""
                        End If
                    Next myRow
                Next thisTable
                If m_sFooter <> Nothing Then 'dont output a line feed if the footer is empty
                    WriteFile(m_sFooter)
                End If
            Case "xml"
                'this is not fully implemented. If a customer wants xml output
                'we probably want to revisit this section and add some formatting
                'flexibility. As written, it creates a nice vanilla xml file
                'with all the data in it.
                Dim writer As New System.IO.StreamWriter(m_sOutputFileName)
                Dim xmlSerial As New XmlSerializer(dsData.GetType())
                xmlSerial.Serialize(writer, dsData)
                writer.Close()
            Case "fixed"
                'this is for fixed width output. Each col must be defined in the 
                'definition file, and it must be RIGHT. This routine just follows
                'instructions.
                'WriteFile(GetValueFromFile("Output", "Header"))
                If m_sHeader <> Nothing Then 'dont output a line feed if the header is empty
                    WriteFile(m_sHeader)
                End If
                ' For each row, print the values of each column.
                'Dim xmlElement As Xml.XmlElement
                'Dim sType, sWidth As String
                'Dim i As Integer
                Dim thisTable As DataTable
                For Each thisTable In dsData.Tables
                    ' For each row, print the values of each column.
                    Dim myRow As DataRow
                    For Each myRow In thisTable.Rows
                        If myRow.RowState <> DataRowState.Deleted Then
                            Dim myCol As DataColumn
                            Dim iColNum As Integer = 0
                            strDataLine = ""
                            For Each myCol In thisTable.Columns
                                strDataLine &= FormatDataField(myRow(myCol), "Root//col" & CStr(iColNum + 1), "fixed")
                                iColNum += 1
                            Next myCol
                            WriteFile(strDataLine)
                        End If
                    Next myRow
                Next
                If m_sFooter <> Nothing Then 'dont output a line feed if the footer is empty
                    WriteFile(m_sFooter)
                End If
            Case "sql_insert"
                'LAR 10/14/2003 - added this logic; in this case we are going to connect to 
                'another db and put the data directly into a table there rather than write it to file
                'note: for this to work, everything has to be exact: 
                'every column must be included (no colname list is included in the insert)
                'the order must be exactly as in table
                'note also that this, as coded, will treat each value as a string, and bracket it with quotes
                'If a data list is to include numeric etc values, this will have to be extended
                Dim bRet As Boolean
                'Dim oUtility As New DataExtractClasses.clsUtilityFunctions()
                'bRet = InsertData()
                'If Not bRet Then

                'End If
                Dim tblName As String = GetValueFromFile("q1", "table")
                Dim myRow As DataRow
                Dim sTemp As String
                WriteLog("Building Insert statements.", HIGH)
                For Each myRow In dsData.Tables(0).Rows
                    If myRow.RowState <> DataRowState.Deleted Then
                        Dim myCol As DataColumn
                        'Dim iColNum As Integer = 0
                        strDataLine = ""
                        'loop thru the data row and build an insert string
                        For Each myCol In dsData.Tables(0).Columns
                            'strDataLine &= FormatDataField(myRow(myCol), "Root//col" & CStr(iColNum + 1))
                            'iColNum += 1
                            sTemp = ""
                            'check for apostrophes and double them if necessary
                            If Not IsDBNull(myRow(myCol)) Then
                                sTemp = CStr(myRow(myCol)).Replace("'", "''")
                            Else
                                sTemp = ""
                            End If
                            'note the quotes, each val is assumed to be text
                            If strDataLine = "" Then
                                strDataLine &= "'" & sTemp & "'"
                            Else
                                strDataLine &= ", '" & sTemp & "'"
                            End If
                        Next myCol
                    End If
                    strDataLine = "Insert into " & tblName & " values (" & strDataLine & ")"
                    'log the insert for debugging
                    WriteLog(strDataLine, HIGH)
                    'creaet a dummy recordset just to satisfy the fn arg list...
                    Dim dsDummy As System.Data.DataSet
                    'execute the insert
                    bRet = RunSQL(dsDummy, strDataLine, "ExecuteOnly")
                Next myRow
        End Select


    End Function

    'Private Function InsertData()

    'End Function

    Private Function Initialize(ByRef sFileName As String) As Boolean

        'PID 2006/04/19 
        'Added variables to accommodate BMW reverse file feed
        Dim bCboolFileCounter As Boolean
        Dim iFileCounter As Integer
        Dim sFileCounter As String
        Dim xmlElement As Xml.XmlElement

        Initialize = True
        m_sInputFileName = sFileName
        'create the document
        m_xmlDoc.Load(m_sInputFileName)
        m_lRecordCount = 0
        m_iLogLevel = 10
        Dim sDir As String = GetValueFromFile("Output", "FileDir")
        'PID 2006/04/19 
        'Added parameter for file counter to accommodate BMW Reverse Feed
        'File counter gets padded with zero to handle 3 and 4 digits
        'Update file counter in BMW xml file (BMWMC STD File Extract.xml)
        If GetValueFromFile("Output", "FileCounter") Is Nothing Then
            bCboolFileCounter = False
        Else
            bCboolFileCounter = True
            iFileCounter = GetValueFromFile("Output", "FileCounter") + 1
            xmlElement = m_xmlDoc.SelectSingleNode("Root//Output")
            Select Case iFileCounter
                Case Is < 1000
                    sFileCounter = "0" + CStr(iFileCounter)
                    xmlElement.SetAttribute("FileCounter", sFileCounter)
                Case Is >= 1000
                    xmlElement.SetAttribute("FileCounter", CStr(iFileCounter))
            End Select
        End If
        If sDir <> "" Then
            If Len(Dir(sDir, vbDirectory)) = 0 Then
                MkDir(sDir)
            End If
            If Right(sDir, 1) <> "\" Then sDir &= "\"
        End If
        m_sOutputFileName = sDir & GetValueFromFile("Output", "FileName")
        sDir = GetValueFromFile("Output", "logdir")
        If sDir <> "" Then
            If Len(Dir(sDir, vbDirectory)) = 0 Then
                MkDir(sDir)
            End If
            If Right(sDir, 1) <> "\" Then sDir &= "\"
        End If
        m_sLogFileName = sDir & GetValueFromFile("Output", "logfile")
        'if the recycle flag is on, delete the old log before this run, otherwise we append to it
        If GetValueFromFile("Output", "RecycleLog") = "true" Then
            If File.Exists(m_sLogFileName) Then
                File.Delete(m_sLogFileName)
            End If
        End If
        m_iLogLevel = GetValueFromFile("Output", "LogLevel")
        If m_sLogFileName = "" Then
            'can't log at all, set level to 10 to prevent attempts
            m_iLogLevel = 10
        End If

    End Function

    Private Sub Class_Initialize_Renamed()


    End Sub

    Public Sub New()
        MyBase.New()
        Class_Initialize_Renamed()
    End Sub

    Private Sub Class_Terminate_Renamed()

    End Sub

    Protected Overrides Sub Finalize()
        Class_Terminate_Renamed()
        MyBase.Finalize()
    End Sub

    Private Function WriteFile(ByRef strInput As String) As Object

        FileOpen(1, m_sOutputFileName, OpenMode.Append)
        PrintLine(1, strInput)
        FileClose(1)

    End Function

    Private Function WriteLog(ByRef strInput As String, ByVal iLevel As Integer, Optional ByVal SuccessFlag As Integer = 1)

        If iLevel >= m_iLogLevel Then
            FileOpen(1, m_sLogFileName, OpenMode.Append)
            PrintLine(1, CStr(Now) & " - " & strInput)
            FileClose(1)
        End If

        strDBLog &= SuccessFlag & "#~" & DateTime.Now & "-" & strInput & "||"

    End Function

    Private Function FilterData(ByRef dsData As System.Data.DataSet, ByVal sQueryName As String) As Boolean
        'allow the user to set up a filter criterion in the xml file
        'ex: <Filter ActualDaysPaid="0"/> will remove all rows from the dataset 
        'where the ActualDaysPaid column contains 0
        'LAR 09/29/2003 - reworked the fn to keep track of the 
        'items for deletion and then delete them en mass, rather than in the identification loop,
        'which was causing problems.
        Dim xmlElement As Xml.XmlElement
        Dim sName, sValue As String
        Dim bFound As Boolean
        Dim iRowCounter As Integer = 0
        Dim iDelete() As Integer
        ReDim iDelete(-1)
        Dim bNot As Boolean
        'create a dataview on the original table
        Dim dvDataView As New DataView(dsData.Tables(0))
        Dim iAttribute As Integer

        FilterData = True


        xmlElement = m_xmlDoc.SelectSingleNode("Root//" & sQueryName & "//Filter")
        If TypeName(xmlElement) <> "Nothing" Then
            If xmlElement.HasAttributes Then
                WriteLog("Filtering data.", HIGH)
                'loop thru all attributes
                'name is a colname, value is the data valu to be filtered out
                For iAttribute = 0 To xmlElement.Attributes.Count - 1
                    sName = xmlElement.Attributes.Item(iAttribute).Name
                    sValue = xmlElement.Attributes.Item(iAttribute).Value
                    bNot = False
                    If InStr(sValue, "!") > 0 Then
                        bNot = True
                        sValue = Replace(sValue, "!", "")
                    End If
                    'special cases...
                    Select Case sName
                        Case "Duplicates"
                            Dim bRet = FilterDuplicates(dsData, sValue)
                        Case Else
                            'straight filter on sName = sValue
                            'if the column exists
                            If dsData.Tables(0).Columns.Contains(sName) Then
                                'delete any row that has the col with the val
                                Dim drv As DataRowView
                                For Each drv In dvDataView
                                    If Not IsDBNull(drv(sName)) Then
                                        If bNot Then
                                            If drv(sName) <> sValue Then
                                                bFound = True
                                                'save off the index of the row
                                                ReDim Preserve iDelete(UBound(iDelete) + 1)
                                                iDelete(UBound(iDelete)) = iRowCounter
                                            End If
                                        Else
                                            If drv(sName) = sValue Then
                                                bFound = True
                                                'save off the index of the row
                                                ReDim Preserve iDelete(UBound(iDelete) + 1)
                                                iDelete(UBound(iDelete)) = iRowCounter
                                            End If
                                        End If
                                    Else
                                        bFound = True
                                        'save off the index of the row
                                        ReDim Preserve iDelete(UBound(iDelete) + 1)
                                        iDelete(UBound(iDelete)) = iRowCounter
                                    End If
                                    iRowCounter += 1
                                Next
                                'now take any found rows out of the dataset
                                Dim i As Integer = 0
                                If bFound Then
                                    Array.Sort(iDelete)
                                    'reverse the sort so we remove from the bottom first
                                    Array.Reverse(iDelete)
                                    For i = 0 To (iDelete.GetLength(0) - 1)
                                        dvDataView.Delete(iDelete(i))
                                        m_lRecordCount -= 1
                                    Next
                                    dsData.AcceptChanges()
                                    ReDim iDelete(-1)
                                    bFound = False
                                    iRowCounter = 0
                                End If
                            End If
                    End Select
                Next
            End If
        End If

        '************NOT IMPLEMENTED
        'The idea behind this is to let the definition file set out a column
        'that duplicates should be bulked up on, and begin/end params established.
        'For example (and this is what is hard-coded below), if claims are being pulled
        'from 4.0, they will be coming from the s_absence_segment table, and there will
        'be one row per segment, with all other data (name, etc) duplicated.
        'We only want 1 row per period, with the start date of the earliest
        'segment and the end date of the last. We want to bulk up on the 
        'absence_segment_group_number, since that groups consecutive dates.
        'So what we would do is sort by the grp num, and loop thru the rows,
        'keeping only the first, with its start date, looping until the last one, 
        'taking its end date and setting it as the end date of the kept row,
        'and deleting all intervening rows. That way we end up with one row with all
        'demographic data, and a start and end date for the consecutive period.
        'I never genericized it, or pursued it further since all claim feeds defined
        'use the fineos db for the claim data.
        'xmlElement = m_xmlDoc.SelectSingleNode("Root//Group")
        'If TypeName(xmlElement) <> "Nothing" Then
        '    If xmlElement.HasAttributes Then
        '        Dim iHold, iIndex, iLeave, iSave As Integer
        '        Dim iGroup As Integer
        '        Dim sTemp, sName, sValue As String
        '        Dim dtStart As Date
        '        Dim bJustDeleted As Boolean
        '        iIndex = 0
        '        'iLeave = dsData.Tables(0).Rows(0).Item("leave_id")
        '        'For i = 0 To xmlElement.Attributes.Count - 1
        '        'sName = xmlElement.Attributes.Item(i).Name
        '        'sValue = xmlElement.Attributes.Item(i).Value
        '        For iIndex = 0 To dsData.Tables(0).Rows.Count - 1
        '            'if the leave id is the same as the prior row, set its end date into the prior row,
        '            'then delete this row. Keep rolling the latest end date up into the keeper row.
        '            'If dsData.Tables(0).Rows(iIndex).Item("leave_id") = iLeave Then
        '            If dsData.Tables(0).Rows(iIndex).Item("ABSENCE_SEGMENT_GROUP_NUMBER") = iGroup Then
        '                If Not bJustDeleted Then
        '                    iSave = iIndex - 1
        '                Else
        '                    'iSave = iIndex - 1
        '                    'iHold = iIndex
        '                End If
        '                dsData.Tables(0).Rows(iSave).Item("absence_segment_end") = dsData.Tables(0).Rows(iIndex).Item("absence_segment_end")
        '                dsData.Tables(0).Rows(iIndex).Delete()
        '                bJustDeleted = True
        '                'iIndex -= 1
        '            Else
        '                'iLeave = dsData.Tables(0).Rows(iIndex).Item("leave_id")
        '                iGroup = dsData.Tables(0).Rows(iIndex).Item("ABSENCE_SEGMENT_GROUP_NUMBER")
        '                bJustDeleted = False
        '            End If
        '        Next
        '        'Next
        '    End If
        'End If
    End Function

    Private Function MapData(ByRef dsData As System.Data.DataSet) As Boolean
        '***THIS FN DOESN'T WORK AS WRITTEN. EITHER FIX IT OR DO NOT CALL IT!!
        Dim sNodeName As String
        Dim iDepth As Integer

        MapData = True

        Dim reader As XmlNodeReader = Nothing
        'Load the XmlNodeReader 
        reader = New XmlNodeReader(m_xmlDoc)

        Try
            While reader.Read()
                If reader.NodeType = XmlNodeType.Element Then
                    If reader.Name = "Mapping" Then
                        'save off the depth of the mapping node
                        iDepth = reader.Depth
                        'go to the next node, which will be the first mapping sub-node
                        reader.Read()
                        Do While reader.Depth <> iDepth
                            sNodeName = reader.Name
                            If reader.HasAttributes Then
                                Dim i, iIndex As Integer
                                iIndex = 0
                                For i = 0 To reader.AttributeCount - 1
                                    reader.MoveToAttribute(i)
                                    For iIndex = 0 To dsData.Tables(0).Rows.Count - 1
                                        If dsData.Tables(0).Rows(iIndex).Item(sNodeName) = reader.Value Then
                                            'the problem with this is that the datatypes don't match. Can I change the datatype on the item?
                                            dsData.Tables(0).Rows(iIndex).Item(sNodeName) = CStr(reader.Name)
                                        End If
                                    Next
                                Next i
                                'Return the reader to the element.
                                reader.MoveToElement()
                            End If
                            reader.Read()
                        Loop
                    End If
                End If
            End While

        Finally
            If Not (reader Is Nothing) Then
                reader.Close()
            End If
        End Try

    End Function

    Function PadString(ByVal sInput As String, ByVal iLength As Integer, ByVal sSide As String) As String
        'this function pads a passed string with extra spaces. sSide tells it which side of the 
        'string to put the extras on (generally strings are padded right, numbers left)
        Dim sOutput As String

        sOutput = sInput
        If iLength = 0 Then
            If Len(sOutput) = 0 Then
                sOutput &= " "
            Else
                sOutput = sOutput
            End If
            PadString = sOutput
            Exit Function
        End If

        If Len(sOutput) > iLength Then
            '   protect against infinite loops
            sOutput = Left(sOutput, iLength)
        End If

        Do Until Len(sOutput) = iLength
            If sSide = "R" Then
                sOutput &= " "
            Else
                sOutput = " " & sOutput
            End If
        Loop

        PadString = sOutput

    End Function

    Private Function PadNumeric(ByVal dblInput As Double, ByVal dblPrecision As Double) As String
        'in this function we are getting a double and need to format it per the 
        'passed precision, ie if we get 296.2 and precision is 7.2 we need to 
        'build a format string of "0000000.00" and output "0000296.20"
        Dim sFormat, sTemp() As String
        Dim iTemp, iCount As Integer

        sTemp = Split(CStr(dblPrecision), ".")
        iTemp = sTemp(0)    'number of leading 0s
        For iCount = 1 To iTemp
            sFormat &= "0"
        Next
        'if there is a decimal in the precision string, go on to do trailing 0s
        If UBound(sTemp) > 0 Then
            sFormat &= "."
            iTemp = sTemp(1)    'number of trailing 0s
            For iCount = 1 To iTemp
                sFormat &= "0"
            Next
        End If
        PadNumeric = Format(dblInput, sFormat)

    End Function

    Private Function AddProviders(ByRef dsData As System.Data.DataSet) As Boolean
        'adding the providers is pretty tricky, so I'm doing a less generic process than I would like.
        'This fn will be called as an append subquery, but a lot of the work is custom.
        'At least we can use a lot of the other functions, just calling from here
        'instead of thru the main function.
        AddProviders = True
        Dim sSQL As String
        Dim sI As String
        Dim iCount As Integer = 0
        'save off the original number of columns.
        Dim iOrigColCount As Integer = dsData.Tables(0).Columns.Count
        'add space to the table for 5 providers...
        Dim sInc As String, sApp As String
        For iCount = 1 To 5
            sInc = "Provider" & CStr(iCount)
            sApp = sInc & "LastName," & sInc & "FirstName," & sInc & "Initial," & sInc & "Add1," & sInc & "Add2," & sInc & "City," & sInc & "State," & sInc & "Zip," & sInc & "Phone," & sInc & "Fax," & sInc & "Specialty"
            Dim bRet As Boolean = AppendColumns(dsData.Tables(0), sApp)
        Next
        'loop thru the passed dataset
        If dsData.Tables(0).Rows.Count > 0 Then
            'create and fill a dataset using the provider query
            For iCount = 0 To dsData.Tables(0).Rows.Count - 1
                Dim dsProviders As New System.Data.DataSet
                'dsProviders.Clear()
                sI = dsData.Tables(0).Rows(iCount)("i")
                'This query gives us all providers for a given toccase.i
                sSQL = "SELECT s_tocperson.UNIQUEID as providerid, s_tocperson.LASTNAME, s_tocperson.FIRSTNAMES, " & _
                "s_tocperson.INITIALS, s_tocpostaladdress.address1, s_tocpostaladdress.address2, " & _
                "s_tocpostaladdress.address4, s_tocpostaladdress.address6, " & _
                "s_tocpostaladdress.postcode, '' as worktelephoneno, '' as fax, to_char(s_tocperson.SPECIALITYID) as SPECIALITYID " & _
                "FROM s_tocperson, s_tocpartyaddressusage, s_tocpostaladdress " & _
                "WHERE (    (s_tocpartyaddressusage.i_ocprty_usages = s_tocperson.i) " & _
                "AND (s_tocpartyaddressusage.i_ocpostad_usages = s_tocpostaladdress.i) ) " & _
                "AND (s_tocperson.i IN ( " & _
                "SELECT S_TOCPARTYCASEROLE.I_OCPRTY_PARTYCASEROLE FROM S_TOCPARTYCASEROLE WHERE " & _
                "S_TOCPARTYCASEROLE.I_OCCASE_ROLES = (" & sI & ") AND S_TOCPARTYCASEROLE.ROLE IN (4480007, 448008) ) ) " & _
                "AND (s_tocpartyaddressusage.usage = 1088002)"
                RunSQL(dsProviders, sSQL, "")
                If dsProviders.Tables(0).Rows.Count > 0 Then
                    'fill in the blanks with subqueries
                    If Not RunSubQueries(dsProviders, "AddProviders") Then
                        'error
                        WriteLog("RunSubQueries failed on AddProviders. Extract aborted.", LOW, 2)
                        EmailConfirmation(True)
                        AddProviders = False
                        Exit Function
                    End If
                    'strip various columns
                    If Not StripColumns(dsProviders, "q1//SubQueries//AddProviders") Then
                        'error
                        WriteLog("StripColumns failed on AddProviders. Extract aborted.", LOW, 2)
                        EmailConfirmation(True)
                        AddProviders = False
                        Exit Function
                    End If
                    'flatten the results
                    Dim objUtility As New DataExtractClasses.clsUtilityFunctions
                    objUtility.FlattenDataset(dsProviders, 5)
                    'now dsProviders has 1 row with 55 cols in it. We already appended those 
                    'cols to the main dataset, so now copy dsProviders's data into the main row 
                    Dim iLoop As Integer
                    Dim iCol As Integer = iOrigColCount
                    'start setting data at col at iOrigColCount and move forward from there
                    For iLoop = 0 To dsProviders.Tables(0).Columns.Count - 1
                        dsData.Tables(0).Rows(iCount).Item(iCol) = dsProviders.Tables(0).Rows(0).Item(iLoop)
                        iCol += 1
                    Next
                End If
            Next
        End If

    End Function

    Public Function FilterDuplicates(ByRef dsData As System.Data.DataSet, ByVal sColName As String) As Boolean
        'this function will take the dataset and remove any columns where a value in a 
        'passed column name is duplicated.
        'ie if sColName is "claimid" then the dataset will be sorted by claimid and only the
        'first row with a certain claimid will be kep, and others with the same claimid 
        'will be removed.

        'create a dataview on the original table
        Dim dvDataView As New DataView(dsData.Tables(0))
        'sort it by sColName so we can find based on it
        dvDataView.Sort = sColName

        Dim drv As DataRowView
        Dim iCount As Integer = 0
        Dim sHold As String = ""
        Dim iDelete() As Integer
        ReDim iDelete(-1)

        'go thru row by row
        For Each drv In dvDataView
            If Not drv.Row.RowState = DataRowState.Detached Then
                Try
                    If Not IsDBNull(drv(sColName)) Then
                        'if we are on a new value, save it and go on to next row
                        If sHold <> CStr(drv(sColName)) Then
                            'save off value
                            sHold = CStr(drv(sColName))
                        Else
                            'otherwise, we have a dupe, mark for deletion
                            ReDim Preserve iDelete(UBound(iDelete) + 1)
                            iDelete(UBound(iDelete)) = iCount
                        End If
                    End If
                Catch e As Exception
                    'do nothing: 
                End Try
            End If
            iCount += 1
        Next

        'now delete all marked rows 
        Array.Sort(iDelete)
        Array.Reverse(iDelete)
        For iCount = 0 To (iDelete.GetLength(0) - 1)
            dvDataView.Delete(iDelete(iCount))
        Next
        dsData.AcceptChanges()

        Return True

    End Function

    Public Function SortData(ByRef dsData As System.Data.DataSet) As Boolean
        'sort the data by the defined criterion, if there is one

        'can't see a way to sort a data table, so make a dataview out of it and copy it to a new table
        Dim dvTemp As DataView = New DataView(m_dsData.Tables(0))
        Dim strSort As String = GetValueFromFile("Output", "Sort")
        Dim drv As DataRowView

        If strSort <> "" Then
            'Try
            'sort the dataview on that column
            dvTemp.Sort = strSort
            'clone a new table, copy the sorted rows into it
            Dim dtClone As DataTable = dvTemp.Table.Clone()
            For Each drv In dvTemp
                dtClone.ImportRow(drv.Row)
            Next
            'now drop the old table and replace it with the new.
            dsData.Tables.Remove(dsData.Tables(0))
            dsData.Tables.Add(dtClone)
            dsData.AcceptChanges()
            'Catch objException As Exception
            '    LogError(objException, "SortColumns")
            '    SortData = False
            '    Exit Function
            'End Try
        End If

        SortData = True

    End Function


    'changes for RADAR-13330 New function is written to write the metadata about log to database
    'using support.dll
    Private Function DBLogStart(ByVal JobName As String, ByVal StartTime As String, ByVal LastEditedBy As String) As Boolean

        Dim dsTemp As DataSet
        Dim sSQL As String = "pk_feed_logging.proc_feed_log"
        Dim sParamsInput, sQueryName As String

        'JobName = GetValueFromFile("JobName", "name")
        If (JobName = "" Or JobName = "Nothing") Then
            DBLogStart = False
            WriteLog("Job Name Not Specified. DBLogStart Failed.", HIGH, 2)
            Exit Function
        End If

        sParamsInput = Replace(JobName, ",", "|") & "," & StartTime & "," & LastEditedBy
        sQueryName = ""
        Dim XmlElement, XmlChild As Xml.XmlElement
        Dim iChild As Integer
        XmlElement = m_xmlDoc.SelectSingleNode("Root//SQL")
        If TypeName(XmlElement) <> Nothing And (XmlElement.HasChildNodes) Then
            For iChild = 0 To XmlElement.ChildNodes.Count - 1
                XmlChild = XmlElement.ChildNodes(iChild)
                If TypeName(XmlChild) <> "Nothing" Then
                    sQueryName = XmlChild.Name
                End If
            Next
        End If
        Try
            DBLogStart = RunSQL(dsTemp, sSQL, sParamsInput, sQueryName, 1)
        Catch ex As Exception
            DBLogStart = False
        End Try
    End Function

    'changes for RADAR-13330 New function is written to write the log to database
    'using support.dll
    Private Function DBLogEnd(ByVal JobName As String, ByVal EndTime As String, ByVal SuccessFlag As String, ByVal LastEditedBy As String, ByVal DBFlag As Boolean) As Boolean
        If DBFlag = True Then
            'Dim JobName As String = GetValueFromFile("JobName", "name")
            Dim sSql As String = "pk_feed_logging.proc_feed_log_detail"
            Dim sParamsInput As String
            Dim dsTemp As DataSet

            If (JobName = "" Or JobName = Nothing) Then
                DBLogEnd = False
                Exit Function
            End If

            sParamsInput = Replace(JobName, ",", "|") & "," & Replace(Replace(strDBLog, ",", " "), "'", "''") & "," & EndTime & "," & SuccessFlag & "," & LastEditedBy

            Dim sQueryName As String = ""
            Dim XmlElement, XmlChild As Xml.XmlElement
            Dim iChild As Integer
            XmlElement = m_xmlDoc.SelectSingleNode("Root//SQL")
            If TypeName(XmlElement) <> "Nothing" And (XmlElement.HasChildNodes) Then
                For iChild = 0 To XmlElement.ChildNodes.Count - 1
                    XmlChild = XmlElement.ChildNodes(iChild)
                    If TypeName(XmlChild) <> "Nothing" Then
                        sQueryName = XmlChild.Name
                    End If
                Next
            End If
            Try
                DBLogEnd = RunSQL(dsTemp, sSql, sParamsInput, sQueryName, 1)
            Catch ex As Exception
                DBLogEnd = False
                Exit Function
            End Try
        Else
            DBLogEnd = False
        End If
    End Function


    'Changes for RADAR-13330 Rewriting RUNSQL which will use support.dll
    'Support.dll doesnt provide connection to SQL Server and Datarep.So for these database older version of RunSQL(RunSQLOledb) is used.
    'Database logging is implemented
    Private Function RunSQL(ByRef dsData As DataSet, ByVal sSQL As String, ByVal sParamsInput As String, Optional ByVal sQueryName As String = "", Optional ByVal iDBLog As Int16 = 0) As Boolean

        Dim sParams(), sUDLFile As String
        Dim i, index As Integer
        Dim daObj As wkab.Support.DataAccess
        Dim sReturnDataSet As String
        Dim dt, dtTemp As DataTable
        Dim bExecuteOnly As Boolean = False
        Dim iTimeoutValue As Integer
        If sQueryName = "" Then
            RunSQL = False
            WriteLog("Query Name is NULL.RunSQL failed.Extract Aborted", HIGH, 2)
            Exit Function
        Else
            sUDLFile = GetValueFromFile(sQueryName, "udl")
            sReturnDataSet = GetValueFromFile(sQueryName, "returndataset")
            'Providing facility to change the timeout value from the xml file itself
            'in case no value is provided in the xml defualting it to 500
            iTimeoutValue = CInt(GetValueFromFile(sQueryName, "timeout"))
            If iTimeoutValue = 0 Then
                iTimeoutValue = 500
            End If
            If sUDLFile = "" Or sUDLFile = Nothing Then
                RunSQL = False
                WriteLog("Connection Failed for RunSQL.Extract Aborted", HIGH, 2)
                Exit Function
            End If

            sUDLFile = sUDLFile.ToUpper()

            If (iDBLog = 0) Then
                If (sUDLFile.Contains("DQPROD.UDL") Or sUDLFile.Contains("DR02.UDL") Or sUDLFile.Contains("WKABRPTPROD.UDL") Or sUDLFile.Contains("WKABRPTDEV.UDL")) Or sUDLFile.Contains("WKABSTGC.UDL") Then
                    RunSQL = RunSQLOLEDB(dsData, sSQL, sParamsInput, sQueryName)
                    Exit Function
                ElseIf (sUDLFile = "AETHPROD" Or sUDLFile.Contains("WKABOLEDB.UDL")) Then
                    sUDLFile = "AETHPROD"
                ElseIf (sUDLFile = "AETHSTG1" Or sUDLFile.Contains("WKABOLEDB_STG1.UDL")) Then
                    sUDLFile = "AETHSTG1"
                ElseIf (sUDLFile = "AETHDEV2" Or sUDLFile.Contains("WKABOLEDB_DEV2.UDL")) Then
                    sUDLFile = "AETHDEV2"
                ElseIf (sUDLFile = "AETHDEV1" Or sUDLFile.Contains("WKABOLEDB_DEV1.UDL")) Then
                    sUDLFile = "AETHDEV1"
                ElseIf (sUDLFile = "AETHDEV3" Or sUDLFile.Contains("WKABOLEDB_DEV3.UDL")) Then
                    sUDLFile = "AETHDEV3"
                ElseIf (sUDLFile = "AETHSTG2" Or sUDLFile.Contains("WKABOLEDB_STG2.UDL")) Then
                    sUDLFile = "AETHSTG2"
                ElseIf (sUDLFile = "AETHQA1" Or sUDLFile.Contains("WKABOLEDB_QA1.UDL")) Then
                    sUDLFile = "AETHQA1"
                ElseIf (sUDLFile = "AETHQA2" Or sUDLFile.Contains("WKABOLEDB_QA2.UDL")) Then
                    sUDLFile = "AETHQA2"
                ElseIf (sUDLFile = "AETHQA3" Or sUDLFile.Contains("WKABOLEDB_QA3.UDL")) Then
                    sUDLFile = "AETHQA3"
                ElseIf (sUDLFile = "AETHSTRS") Then
                    sUDLFile = "AETHSTRS"
                ElseIf (sUDLFile = "AETHTRG1") Then
                    sUDLFile = "AETHTRG1"
                ElseIf (sUDLFile = "AETHTRG2") Then
                    sUDLFile = "AETHTRG2"
                Else
                    RunSQL = False
                    WriteLog("Connection Failed for RunSQL.Extract Aborted", HIGH, 2)
                    Exit Function
                End If
            Else
                If (sUDLFile.Contains("DQPROD.UDL") Or sUDLFile.Contains("DR02.UDL") Or sUDLFile.Contains("WKABRPTPROD.UDL") Or sUDLFile.Contains("WKABRPTDEV.udl")) Then
                    sUDLFile = "AETHPROD"
                ElseIf (sUDLFile = "AETHPROD" Or sUDLFile.Contains("WKABOLEDB.UDL")) Then
                    sUDLFile = "AETHPROD"
                ElseIf (sUDLFile = "AETHSTG1" Or sUDLFile.Contains("WKABOLEDB_STG1.UDL")) Then
                    sUDLFile = "AETHSTG1"
                ElseIf (sUDLFile = "AETHDEV2" Or sUDLFile.Contains("WKABOLEDB_DEV2.UDL")) Then
                    sUDLFile = "AETHDEV2"
                ElseIf (sUDLFile = "AETHDEV1" Or sUDLFile.Contains("WKABOLEDB_DEV1.UDL")) Then
                    sUDLFile = "AETHDEV1"
                ElseIf (sUDLFile = "AETHDEV3" Or sUDLFile.Contains("WKABOLEDB_DEV3.UDL")) Then
                    sUDLFile = "AETHDEV3"
                ElseIf (sUDLFile = "AETHSTG2" Or sUDLFile.Contains("WKABOLEDB_STG2.UDL")) Then
                    sUDLFile = "AETHSTG2"
                ElseIf (sUDLFile = "AETHQA1" Or sUDLFile.Contains("WKABOLEDB_QA1.UDL")) Then
                    sUDLFile = "AETHQA1"
                ElseIf (sUDLFile = "AETHQA2" Or sUDLFile.Contains("WKABOLEDB_QA2.UDL")) Then
                    sUDLFile = "AETHQA2"
                ElseIf (sUDLFile = "AETHQA3" Or sUDLFile.Contains("WKABOLEDB_QA3.UDL")) Then
                    sUDLFile = "AETHQA3"
                ElseIf (sUDLFile = "AETHSTRS") Then
                    sUDLFile = "AETHSTRS"
                ElseIf (sUDLFile = "AETHTRG1") Then
                    sUDLFile = "AETHTRG1"
                ElseIf (sUDLFile = "AETHTRG2") Then
                    sUDLFile = "AETHTRG2"
                Else
                    RunSQL = False
                    WriteLog("Connection Failed for logging comments into the database", HIGH, 2)
                    Exit Function
                End If
            End If

            If (sParamsInput = "ExecuteOnly") Then
                sParamsInput = ""
                bExecuteOnly = True
            End If

            'Splits the input argument
            sParams = Split(sParamsInput, ",")
            index = sParams.Length
            daObj = New wkab.Support.DataAccess(sUDLFile)
            'New change for changing the default value of 230 harcoded in Support.dll
            'as some of the feeds might take more than 230 sec to be generated
            daObj.CommandTimeOutValueChange = iTimeoutValue

            If sParamsInput <> "" Then
                For i = 0 To index - 1
                    daObj.AddParameter(sParams(i))
                Next
            End If

            If UCase(sSQL).Contains("PK_FEED_LOGGING") Or UCase(sReturnDataSet) = "FALSE" Or bExecuteOnly = True Then
                daObj.ExecuteSP(sSQL)
            ElseIf sReturnDataSet = Nothing Or sReturnDataSet = "" Or UCase(sReturnDataSet) = "TRUE" Then
                dt = daObj.ExecuteQueryRefCursor(sSQL)
                dtTemp = dt.Copy()
                dsData.Tables.Add(dtTemp)
            Else
                RunSQL = False
                WriteLog("Connection Failed for RunSQL.Extract Aborted", HIGH, 2)
                Exit Function
            End If
            RunSQL = True
        End If
    End Function

End Class